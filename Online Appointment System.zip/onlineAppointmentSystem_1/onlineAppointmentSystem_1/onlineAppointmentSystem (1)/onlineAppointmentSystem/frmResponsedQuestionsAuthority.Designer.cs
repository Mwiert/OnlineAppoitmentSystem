﻿
namespace onlineAppointmentSystem
{
    partial class frmResponsedQuestionsAuthority
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgbResponsedQuestions = new System.Windows.Forms.DataGridView();
            this.lblinfo = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgbResponsedQuestions)).BeginInit();
            this.SuspendLayout();
            // 
            // dgbResponsedQuestions
            // 
            this.dgbResponsedQuestions.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgbResponsedQuestions.BackgroundColor = System.Drawing.Color.Azure;
            this.dgbResponsedQuestions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgbResponsedQuestions.Location = new System.Drawing.Point(12, 108);
            this.dgbResponsedQuestions.Name = "dgbResponsedQuestions";
            this.dgbResponsedQuestions.Size = new System.Drawing.Size(777, 349);
            this.dgbResponsedQuestions.TabIndex = 0;
            // 
            // lblinfo
            // 
            this.lblinfo.AutoSize = true;
            this.lblinfo.Font = new System.Drawing.Font("Century Gothic", 14F);
            this.lblinfo.Location = new System.Drawing.Point(274, 32);
            this.lblinfo.Name = "lblinfo";
            this.lblinfo.Size = new System.Drawing.Size(222, 22);
            this.lblinfo.TabIndex = 1;
            this.lblinfo.Text = "RESPONSED QUESTIONS";
            // 
            // frmResponsedQuestionsAuthority
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(801, 469);
            this.Controls.Add(this.lblinfo);
            this.Controls.Add(this.dgbResponsedQuestions);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmResponsedQuestionsAuthority";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmResponsedQuestionsAuthory";
            this.Load += new System.EventHandler(this.frmResponsedQuestionsAuthority_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgbResponsedQuestions)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgbResponsedQuestions;
        private System.Windows.Forms.Label lblinfo;
    }
}