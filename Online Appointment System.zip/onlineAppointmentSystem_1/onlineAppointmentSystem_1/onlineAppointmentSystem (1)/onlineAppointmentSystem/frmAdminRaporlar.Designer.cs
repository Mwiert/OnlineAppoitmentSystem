﻿
namespace onlineAppointmentSystem
{
    partial class frmAdminRaporlar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvAdminRapor = new System.Windows.Forms.DataGridView();
            this.btnDeny = new System.Windows.Forms.Button();
            this.btnApprove = new System.Windows.Forms.Button();
            this.btnWait = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAdminRapor)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvAdminRapor
            // 
            this.dgvAdminRapor.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAdminRapor.Location = new System.Drawing.Point(12, 124);
            this.dgvAdminRapor.Name = "dgvAdminRapor";
            this.dgvAdminRapor.Size = new System.Drawing.Size(553, 305);
            this.dgvAdminRapor.TabIndex = 0;
            // 
            // btnDeny
            // 
            this.btnDeny.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnDeny.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.btnDeny.Location = new System.Drawing.Point(12, 32);
            this.btnDeny.Name = "btnDeny";
            this.btnDeny.Size = new System.Drawing.Size(154, 43);
            this.btnDeny.TabIndex = 2;
            this.btnDeny.Text = "Denied Reports";
            this.btnDeny.UseVisualStyleBackColor = false;
            this.btnDeny.Click += new System.EventHandler(this.btnDeny_Click);
            // 
            // btnApprove
            // 
            this.btnApprove.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnApprove.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.btnApprove.Location = new System.Drawing.Point(192, 32);
            this.btnApprove.Name = "btnApprove";
            this.btnApprove.Size = new System.Drawing.Size(166, 43);
            this.btnApprove.TabIndex = 3;
            this.btnApprove.Text = "Approved Reports";
            this.btnApprove.UseVisualStyleBackColor = false;
            this.btnApprove.Click += new System.EventHandler(this.btnApprove_Click);
            // 
            // btnWait
            // 
            this.btnWait.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnWait.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.btnWait.Location = new System.Drawing.Point(389, 32);
            this.btnWait.Name = "btnWait";
            this.btnWait.Size = new System.Drawing.Size(154, 43);
            this.btnWait.TabIndex = 4;
            this.btnWait.Text = "Waiting Reports";
            this.btnWait.UseVisualStyleBackColor = false;
            this.btnWait.Click += new System.EventHandler(this.btnWait_Click);
            // 
            // frmAdminRaporlar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(577, 460);
            this.Controls.Add(this.btnWait);
            this.Controls.Add(this.btnApprove);
            this.Controls.Add(this.btnDeny);
            this.Controls.Add(this.dgvAdminRapor);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmAdminRaporlar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmAdminRaporlar";
            ((System.ComponentModel.ISupportInitialize)(this.dgvAdminRapor)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvAdminRapor;
        private System.Windows.Forms.Button btnDeny;
        private System.Windows.Forms.Button btnApprove;
        private System.Windows.Forms.Button btnWait;
    }
}