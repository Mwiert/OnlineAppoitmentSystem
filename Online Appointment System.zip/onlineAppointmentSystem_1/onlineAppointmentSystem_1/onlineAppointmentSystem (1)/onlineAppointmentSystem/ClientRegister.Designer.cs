﻿
namespace onlineAppointmentSystem
{
    partial class ClientRegister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ClientRegister));
            this.topPnlRegister = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.minimizedClick = new System.Windows.Forms.PictureBox();
            this.btnAutRgstBack = new System.Windows.Forms.Button();
            this.closeBottonRegister = new System.Windows.Forms.PictureBox();
            this.loginAppLogo = new System.Windows.Forms.PictureBox();
            this.pnlRgstrName = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.pnlRgstrUsername = new System.Windows.Forms.Panel();
            this.pnlRgstrEmail = new System.Windows.Forms.Panel();
            this.pnlRgstrNumber = new System.Windows.Forms.Panel();
            this.pnlRgstrSurname = new System.Windows.Forms.Panel();
            this.txtRegisterUsername = new System.Windows.Forms.TextBox();
            this.mstxtNumber = new System.Windows.Forms.MaskedTextBox();
            this.txtRegisterPassword = new System.Windows.Forms.TextBox();
            this.pnlRgstrPassword = new System.Windows.Forms.Panel();
            this.btnRgstrRegister = new System.Windows.Forms.Button();
            this.txtRegisterName = new System.Windows.Forms.TextBox();
            this.txtRegisterSurname = new System.Windows.Forms.TextBox();
            this.txtRegisterEmail = new System.Windows.Forms.TextBox();
            this.pnlRegisterUsers = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rchtxtBxAdress = new System.Windows.Forms.RichTextBox();
            this.topPnlRegister.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.minimizedClick)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.closeBottonRegister)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginAppLogo)).BeginInit();
            this.pnlRgstrName.SuspendLayout();
            this.pnlRegisterUsers.SuspendLayout();
            this.SuspendLayout();
            // 
            // topPnlRegister
            // 
            this.topPnlRegister.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.topPnlRegister.BackColor = System.Drawing.SystemColors.HotTrack;
            this.topPnlRegister.Controls.Add(this.label1);
            this.topPnlRegister.Controls.Add(this.minimizedClick);
            this.topPnlRegister.Controls.Add(this.btnAutRgstBack);
            this.topPnlRegister.Controls.Add(this.closeBottonRegister);
            this.topPnlRegister.Location = new System.Drawing.Point(0, 0);
            this.topPnlRegister.Name = "topPnlRegister";
            this.topPnlRegister.Size = new System.Drawing.Size(446, 42);
            this.topPnlRegister.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(-1, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(19, 13);
            this.label1.TabIndex = 16;
            this.label1.Text = "<<";
            // 
            // minimizedClick
            // 
            this.minimizedClick.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.minimizedClick.Image = ((System.Drawing.Image)(resources.GetObject("minimizedClick.Image")));
            this.minimizedClick.Location = new System.Drawing.Point(366, 3);
            this.minimizedClick.Name = "minimizedClick";
            this.minimizedClick.Size = new System.Drawing.Size(39, 36);
            this.minimizedClick.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.minimizedClick.TabIndex = 24;
            this.minimizedClick.TabStop = false;
            this.minimizedClick.Click += new System.EventHandler(this.minimizedClick_Click);
            // 
            // btnAutRgstBack
            // 
            this.btnAutRgstBack.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnAutRgstBack.BackColor = System.Drawing.SystemColors.MenuText;
            this.btnAutRgstBack.FlatAppearance.BorderSize = 0;
            this.btnAutRgstBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAutRgstBack.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnAutRgstBack.ForeColor = System.Drawing.SystemColors.Info;
            this.btnAutRgstBack.Location = new System.Drawing.Point(21, 6);
            this.btnAutRgstBack.Name = "btnAutRgstBack";
            this.btnAutRgstBack.Size = new System.Drawing.Size(63, 30);
            this.btnAutRgstBack.TabIndex = 17;
            this.btnAutRgstBack.Text = "BACK";
            this.btnAutRgstBack.UseVisualStyleBackColor = false;
            this.btnAutRgstBack.Click += new System.EventHandler(this.btnAutRgstBack_Click);
            // 
            // closeBottonRegister
            // 
            this.closeBottonRegister.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.closeBottonRegister.Image = ((System.Drawing.Image)(resources.GetObject("closeBottonRegister.Image")));
            this.closeBottonRegister.Location = new System.Drawing.Point(405, 3);
            this.closeBottonRegister.Name = "closeBottonRegister";
            this.closeBottonRegister.Size = new System.Drawing.Size(39, 36);
            this.closeBottonRegister.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.closeBottonRegister.TabIndex = 0;
            this.closeBottonRegister.TabStop = false;
            this.closeBottonRegister.Click += new System.EventHandler(this.closeBottonRegister_Click);
            // 
            // loginAppLogo
            // 
            this.loginAppLogo.Image = ((System.Drawing.Image)(resources.GetObject("loginAppLogo.Image")));
            this.loginAppLogo.Location = new System.Drawing.Point(138, 65);
            this.loginAppLogo.Name = "loginAppLogo";
            this.loginAppLogo.Size = new System.Drawing.Size(189, 153);
            this.loginAppLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.loginAppLogo.TabIndex = 4;
            this.loginAppLogo.TabStop = false;
            // 
            // pnlRgstrName
            // 
            this.pnlRgstrName.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pnlRgstrName.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pnlRgstrName.Controls.Add(this.panel6);
            this.pnlRgstrName.Controls.Add(this.panel8);
            this.pnlRgstrName.Location = new System.Drawing.Point(15, 46);
            this.pnlRgstrName.Name = "pnlRgstrName";
            this.pnlRgstrName.Size = new System.Drawing.Size(124, 5);
            this.pnlRgstrName.TabIndex = 6;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel6.Location = new System.Drawing.Point(-81, 61);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(277, 5);
            this.panel6.TabIndex = 11;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel8.Location = new System.Drawing.Point(-81, -61);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(277, 5);
            this.panel8.TabIndex = 9;
            // 
            // pnlRgstrUsername
            // 
            this.pnlRgstrUsername.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pnlRgstrUsername.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pnlRgstrUsername.Location = new System.Drawing.Point(42, 107);
            this.pnlRgstrUsername.Name = "pnlRgstrUsername";
            this.pnlRgstrUsername.Size = new System.Drawing.Size(233, 5);
            this.pnlRgstrUsername.TabIndex = 7;
            // 
            // pnlRgstrEmail
            // 
            this.pnlRgstrEmail.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pnlRgstrEmail.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pnlRgstrEmail.Location = new System.Drawing.Point(42, 168);
            this.pnlRgstrEmail.Name = "pnlRgstrEmail";
            this.pnlRgstrEmail.Size = new System.Drawing.Size(233, 5);
            this.pnlRgstrEmail.TabIndex = 8;
            // 
            // pnlRgstrNumber
            // 
            this.pnlRgstrNumber.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pnlRgstrNumber.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pnlRgstrNumber.Location = new System.Drawing.Point(42, 223);
            this.pnlRgstrNumber.Name = "pnlRgstrNumber";
            this.pnlRgstrNumber.Size = new System.Drawing.Size(234, 5);
            this.pnlRgstrNumber.TabIndex = 9;
            // 
            // pnlRgstrSurname
            // 
            this.pnlRgstrSurname.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pnlRgstrSurname.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pnlRgstrSurname.Location = new System.Drawing.Point(167, 46);
            this.pnlRgstrSurname.Name = "pnlRgstrSurname";
            this.pnlRgstrSurname.Size = new System.Drawing.Size(125, 5);
            this.pnlRgstrSurname.TabIndex = 10;
            // 
            // txtRegisterUsername
            // 
            this.txtRegisterUsername.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtRegisterUsername.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRegisterUsername.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtRegisterUsername.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtRegisterUsername.Location = new System.Drawing.Point(43, 75);
            this.txtRegisterUsername.Name = "txtRegisterUsername";
            this.txtRegisterUsername.Size = new System.Drawing.Size(233, 26);
            this.txtRegisterUsername.TabIndex = 3;
            this.txtRegisterUsername.Text = "Username";
            this.txtRegisterUsername.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtRegisterUsername.Click += new System.EventHandler(this.txtRegisterUsername_Click);
            // 
            // mstxtNumber
            // 
            this.mstxtNumber.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.mstxtNumber.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.mstxtNumber.Location = new System.Drawing.Point(39, 186);
            this.mstxtNumber.Mask = "(999) 000-0000";
            this.mstxtNumber.Name = "mstxtNumber";
            this.mstxtNumber.Size = new System.Drawing.Size(234, 31);
            this.mstxtNumber.TabIndex = 5;
            this.mstxtNumber.Text = "5555555555";
            this.mstxtNumber.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.mstxtNumber_MaskInputRejected);
            this.mstxtNumber.Click += new System.EventHandler(this.mstxtNumber_Click);
            // 
            // txtRegisterPassword
            // 
            this.txtRegisterPassword.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtRegisterPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRegisterPassword.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtRegisterPassword.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtRegisterPassword.Location = new System.Drawing.Point(39, 360);
            this.txtRegisterPassword.Name = "txtRegisterPassword";
            this.txtRegisterPassword.Size = new System.Drawing.Size(233, 26);
            this.txtRegisterPassword.TabIndex = 7;
            this.txtRegisterPassword.Text = "Password";
            this.txtRegisterPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtRegisterPassword.Click += new System.EventHandler(this.txtRegisterPassword_Click);
            this.txtRegisterPassword.TextChanged += new System.EventHandler(this.txtRegisterPassword_TextChanged);
            // 
            // pnlRgstrPassword
            // 
            this.pnlRgstrPassword.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pnlRgstrPassword.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pnlRgstrPassword.Location = new System.Drawing.Point(38, 392);
            this.pnlRgstrPassword.Name = "pnlRgstrPassword";
            this.pnlRgstrPassword.Size = new System.Drawing.Size(234, 5);
            this.pnlRgstrPassword.TabIndex = 10;
            // 
            // btnRgstrRegister
            // 
            this.btnRgstrRegister.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnRgstrRegister.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnRgstrRegister.FlatAppearance.BorderSize = 0;
            this.btnRgstrRegister.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRgstrRegister.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnRgstrRegister.ForeColor = System.Drawing.SystemColors.Info;
            this.btnRgstrRegister.Location = new System.Drawing.Point(72, 403);
            this.btnRgstrRegister.Name = "btnRgstrRegister";
            this.btnRgstrRegister.Size = new System.Drawing.Size(150, 33);
            this.btnRgstrRegister.TabIndex = 8;
            this.btnRgstrRegister.Text = "REGISTER";
            this.btnRgstrRegister.UseVisualStyleBackColor = false;
            this.btnRgstrRegister.Click += new System.EventHandler(this.btnRgstrRegister_Click);
            // 
            // txtRegisterName
            // 
            this.txtRegisterName.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtRegisterName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRegisterName.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtRegisterName.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtRegisterName.Location = new System.Drawing.Point(15, 14);
            this.txtRegisterName.Name = "txtRegisterName";
            this.txtRegisterName.Size = new System.Drawing.Size(124, 26);
            this.txtRegisterName.TabIndex = 1;
            this.txtRegisterName.Text = "Name";
            this.txtRegisterName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtRegisterName.Click += new System.EventHandler(this.txtRegisterName_Click);
            // 
            // txtRegisterSurname
            // 
            this.txtRegisterSurname.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtRegisterSurname.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRegisterSurname.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtRegisterSurname.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtRegisterSurname.Location = new System.Drawing.Point(167, 14);
            this.txtRegisterSurname.Name = "txtRegisterSurname";
            this.txtRegisterSurname.Size = new System.Drawing.Size(125, 26);
            this.txtRegisterSurname.TabIndex = 2;
            this.txtRegisterSurname.Text = "Surname";
            this.txtRegisterSurname.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtRegisterSurname.Click += new System.EventHandler(this.txtRegisterSurname_Click);
            // 
            // txtRegisterEmail
            // 
            this.txtRegisterEmail.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtRegisterEmail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRegisterEmail.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtRegisterEmail.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtRegisterEmail.Location = new System.Drawing.Point(42, 136);
            this.txtRegisterEmail.Name = "txtRegisterEmail";
            this.txtRegisterEmail.Size = new System.Drawing.Size(233, 26);
            this.txtRegisterEmail.TabIndex = 4;
            this.txtRegisterEmail.Text = "Email";
            this.txtRegisterEmail.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtRegisterEmail.Click += new System.EventHandler(this.txtRegisterEmail_Click);
            // 
            // pnlRegisterUsers
            // 
            this.pnlRegisterUsers.Controls.Add(this.panel1);
            this.pnlRegisterUsers.Controls.Add(this.rchtxtBxAdress);
            this.pnlRegisterUsers.Controls.Add(this.txtRegisterSurname);
            this.pnlRegisterUsers.Controls.Add(this.txtRegisterEmail);
            this.pnlRegisterUsers.Controls.Add(this.pnlRgstrName);
            this.pnlRegisterUsers.Controls.Add(this.pnlRgstrNumber);
            this.pnlRegisterUsers.Controls.Add(this.txtRegisterName);
            this.pnlRegisterUsers.Controls.Add(this.pnlRgstrUsername);
            this.pnlRegisterUsers.Controls.Add(this.btnRgstrRegister);
            this.pnlRegisterUsers.Controls.Add(this.pnlRgstrEmail);
            this.pnlRegisterUsers.Controls.Add(this.pnlRgstrPassword);
            this.pnlRegisterUsers.Controls.Add(this.pnlRgstrSurname);
            this.pnlRegisterUsers.Controls.Add(this.txtRegisterPassword);
            this.pnlRegisterUsers.Controls.Add(this.txtRegisterUsername);
            this.pnlRegisterUsers.Controls.Add(this.mstxtNumber);
            this.pnlRegisterUsers.Location = new System.Drawing.Point(77, 241);
            this.pnlRegisterUsers.Name = "pnlRegisterUsers";
            this.pnlRegisterUsers.Size = new System.Drawing.Size(302, 450);
            this.pnlRegisterUsers.TabIndex = 11;
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel1.Location = new System.Drawing.Point(41, 336);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(234, 5);
            this.panel1.TabIndex = 12;
            // 
            // rchtxtBxAdress
            // 
            this.rchtxtBxAdress.Location = new System.Drawing.Point(39, 234);
            this.rchtxtBxAdress.Name = "rchtxtBxAdress";
            this.rchtxtBxAdress.Size = new System.Drawing.Size(237, 96);
            this.rchtxtBxAdress.TabIndex = 6;
            this.rchtxtBxAdress.Text = "Please write your adress";
            this.rchtxtBxAdress.Click += new System.EventHandler(this.rchtxtBxAdress_Click);
            // 
            // ClientRegister
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(446, 703);
            this.Controls.Add(this.pnlRegisterUsers);
            this.Controls.Add(this.loginAppLogo);
            this.Controls.Add(this.topPnlRegister);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ClientRegister";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Register";
            this.topPnlRegister.ResumeLayout(false);
            this.topPnlRegister.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.minimizedClick)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.closeBottonRegister)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginAppLogo)).EndInit();
            this.pnlRgstrName.ResumeLayout(false);
            this.pnlRegisterUsers.ResumeLayout(false);
            this.pnlRegisterUsers.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel topPnlRegister;
        private System.Windows.Forms.PictureBox closeBottonRegister;
        private System.Windows.Forms.PictureBox loginAppLogo;
        private System.Windows.Forms.Panel pnlRgstrName;
        private System.Windows.Forms.Panel pnlRgstrUsername;
        private System.Windows.Forms.Panel pnlRgstrEmail;
        private System.Windows.Forms.Panel pnlRgstrNumber;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel pnlRgstrSurname;
        private System.Windows.Forms.TextBox txtRegisterUsername;
        private System.Windows.Forms.MaskedTextBox mstxtNumber;
        private System.Windows.Forms.TextBox txtRegisterPassword;
        private System.Windows.Forms.Panel pnlRgstrPassword;
        private System.Windows.Forms.Button btnRgstrRegister;
        private System.Windows.Forms.PictureBox minimizedClick;
        private System.Windows.Forms.TextBox txtRegisterName;
        private System.Windows.Forms.TextBox txtRegisterSurname;
        private System.Windows.Forms.TextBox txtRegisterEmail;
        private System.Windows.Forms.Panel pnlRegisterUsers;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RichTextBox rchtxtBxAdress;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAutRgstBack;
    }
}