﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace onlineAppointmentSystem
{
    public partial class ClientRegister : Form
    {
        public ClientRegister()
        {
            InitializeComponent();
        }

        private void closeBottonRegister_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void minimizedClick_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        private void txtRegisterName_TextChanged(object sender, EventArgs e)
        {
            txtRegisterName.Clear();
        }

        private void txtRegisterSurname_TextChanged(object sender, EventArgs e)
        {
            txtRegisterSurname.Clear();
        }
        private void txtRegisterEmail_TextChanged(object sender, EventArgs e)
        {
            txtRegisterEmail.Clear();
        }

        private void txtRegisterPassword_TextChanged(object sender, EventArgs e)
        {
            txtRegisterPassword.PasswordChar = '*' ;
            txtRegisterPassword.MaxLength= 30;

        }
        private void txtRegisterSurname_Click(object sender, EventArgs e)
        {
            txtRegisterSurname.Clear();
        }

        private void txtRegisterUsername_Click(object sender, EventArgs e)
        {
            txtRegisterUsername.Clear();
        }

        private void txtRegisterPassword_Click(object sender, EventArgs e)
        {
            txtRegisterPassword.Clear();
        }

        private void mstxtNumber_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            mstxtNumber.Clear();
        }
        private void rchtxtBxAdress_Click(object sender, EventArgs e)
        {
            rchtxtBxAdress.Clear();
        }

        private void btnAutRgstBack_Click(object sender, EventArgs e)
        {
            ChooseForm chsFrmBack = new ChooseForm();
            this.Hide();
            chsFrmBack.Show();
        }
        private readonly DBEntityNormalUsers readonlyClients = new DBEntityNormalUsers();
        private void ClientAdd(string clientName,string clientSurname, string clientUsername,string clientEmail,string clientPhoneNumber,string clientPassword,string clientAdress)
        {
            NormalUsers clientAdd = new NormalUsers()
            {
                ClientName = clientName,
                ClientSurname = clientSurname,
                ClientUsername = clientUsername,
                ClientEmail= clientEmail,
                ClientPhoneNumber= clientPhoneNumber,
                ClientPassword=clientPassword,
                ClientAdress = clientAdress
            };
            readonlyClients.ClientAdd(clientAdd);
        }
        private void btnRgstrRegister_Click(object sender, EventArgs e)
        {
            try
            {
                ClientAdd(txtRegisterName.Text, txtRegisterSurname.Text, txtRegisterUsername.Text, txtRegisterEmail.Text, mstxtNumber.Text, txtRegisterPassword.Text, rchtxtBxAdress.Text);
                MessageBox.Show("OPERATION SUCCESFULL.DIRECTING TO OPENING PAGE.");
                Opening clientDirect = new Opening();
                this.Hide();
                clientDirect.Show();
            }
            catch (Exception ex )
            {
                MessageBox.Show("OPERATION FAILED" + ex.Message);
            }
        }

        private void txtRegisterName_Click(object sender, EventArgs e)
        {
            txtRegisterName.Clear();
        }

        private void txtRegisterEmail_Click(object sender, EventArgs e)
        {
            txtRegisterEmail.Clear();
        }

        private void mstxtNumber_Click(object sender, EventArgs e)
        {
            mstxtNumber.Clear();
        }
    }
}
