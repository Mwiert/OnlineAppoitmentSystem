﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace onlineAppointmentSystem
{
    public partial class frmOpenedAppointmentDays : Form
    {
        public frmOpenedAppointmentDays()
        {
            InitializeComponent();
        }
        private void CurrentDatesList()
        {
            DBEntityWorkplaceAuthority dBEntityWorkplaceAuthority = new DBEntityWorkplaceAuthority();
            dBEntityWorkplaceAuthority.ListDatesForReports(dgvOPADT);
        }
        private void frmOpenedAppointmentDays_Load(object sender, EventArgs e)
        {
            CurrentDatesList();
        }
    }
}
