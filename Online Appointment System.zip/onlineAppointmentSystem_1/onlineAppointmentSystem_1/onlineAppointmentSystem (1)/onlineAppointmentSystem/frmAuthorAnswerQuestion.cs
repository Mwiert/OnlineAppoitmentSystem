﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace onlineAppointmentSystem
{
    public partial class frmAuthorAnswerQuestion : Form
    {
        public frmAuthorAnswerQuestion()
        {
            InitializeComponent();
        }
        private void QuestionList()
        {
            string Asnwered = "WAITING";
            DBEntityQuestionAnswer questionAnswer = new DBEntityQuestionAnswer();
            questionAnswer.QuestionList(dgvQuestions, Asnwered);
        }
        private void frmAuthorAnswerQuestion_Load(object sender, EventArgs e)
        {
            QuestionList();
        }
        private void dgvQuestions_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            QuestionAnswer questionAnswer = new QuestionAnswer();
            questionAnswer.SelectedRow = dgvQuestions.SelectedCells[0].RowIndex;
            

            questionAnswer.QuestionidDgv = dgvQuestions.Rows[questionAnswer.SelectedRow].Cells[0].Value.ToString();
            questionAnswer.QAHeadline = dgvQuestions.Rows[questionAnswer.SelectedRow].Cells[1].Value.ToString();
            questionAnswer.QAContent = dgvQuestions.Rows[questionAnswer.SelectedRow].Cells[2].Value.ToString();

            rctxtBxQstnFull.Text = questionAnswer.QAContent;
            txtHeadline.Text = questionAnswer.QAHeadline;
            txtQuestionid.Text = questionAnswer.QuestionidDgv;
        }
        private void btnSendAnswer_Click(object sender, EventArgs e)
        {
            try
            {
                QuestionAnswer questionAnswer = new QuestionAnswer()
                {
                    AnswrAuthor = rctxtBxQstnFull.Text,
                    QuestionStatus = "RESPONSED",
                    QuestionidDgv = txtQuestionid.Text
                };
                DBEntityQuestionAnswer dBEntityQuestionAnswer = new DBEntityQuestionAnswer();
                dBEntityQuestionAnswer.AuthorSendAswer(questionAnswer);
                MessageBox.Show("Your Answer Sent Succesfully");
                QuestionList(); /////////////// sonra kaldırılacak
            }
            catch (Exception ex)
            {
                MessageBox.Show("Operation Failed." + ex.Message);
            }
        }
    }
}
