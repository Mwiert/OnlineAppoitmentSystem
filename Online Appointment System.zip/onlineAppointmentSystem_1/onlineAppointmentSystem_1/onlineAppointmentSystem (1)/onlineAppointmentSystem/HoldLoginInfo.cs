﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace onlineAppointmentSystem
{
    class HoldLoginInfo
    {
        public string HoldUsernameInfo { get; set; } 
    }
}
