﻿
namespace onlineAppointmentSystem
{
    partial class frmOpenedAppointmentDays
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmOpenedAppointmentDays));
            this.dgvOPADT = new System.Windows.Forms.DataGridView();
            this.loginAppLogo = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOPADT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginAppLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvOPADT
            // 
            this.dgvOPADT.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvOPADT.BackgroundColor = System.Drawing.Color.LightCyan;
            this.dgvOPADT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOPADT.Location = new System.Drawing.Point(91, 141);
            this.dgvOPADT.Name = "dgvOPADT";
            this.dgvOPADT.Size = new System.Drawing.Size(233, 297);
            this.dgvOPADT.TabIndex = 0;
            // 
            // loginAppLogo
            // 
            this.loginAppLogo.Image = ((System.Drawing.Image)(resources.GetObject("loginAppLogo.Image")));
            this.loginAppLogo.Location = new System.Drawing.Point(112, 12);
            this.loginAppLogo.Name = "loginAppLogo";
            this.loginAppLogo.Size = new System.Drawing.Size(189, 123);
            this.loginAppLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.loginAppLogo.TabIndex = 12;
            this.loginAppLogo.TabStop = false;
            // 
            // frmOpenedAppointmentDays
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(423, 450);
            this.Controls.Add(this.loginAppLogo);
            this.Controls.Add(this.dgvOPADT);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmOpenedAppointmentDays";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmOpenedAppointmentDays";
            this.Load += new System.EventHandler(this.frmOpenedAppointmentDays_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvOPADT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginAppLogo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvOPADT;
        private System.Windows.Forms.PictureBox loginAppLogo;
    }
}