﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace onlineAppointmentSystem
{
    public partial class frmQuestionReports : Form
    {
        public frmQuestionReports()
        {
            InitializeComponent();
        }
        private void QuestionsList()
        {
            DBEntityQuestionAnswer dBEntityQuestionAnswer = new DBEntityQuestionAnswer();
            dBEntityQuestionAnswer.QuestionListForAdmin(dgvLıstOfQuestions);
            dgvLıstOfQuestions.Refresh();
        }
        private void WaitingQuestionList()
        {
            string Asnwered = "WAITING";
            DBEntityQuestionAnswer questionAnswer = new DBEntityQuestionAnswer();
            questionAnswer.QuestionList(dgvLıstOfQuestions, Asnwered);
        }
        private void ResponsedQuestionList()
        {
            string Asnwered = "RESPONSED";
            DBEntityQuestionAnswer questionAnswer = new DBEntityQuestionAnswer();
            questionAnswer.QuestionList(dgvLıstOfQuestions, Asnwered);
        }
        private void btnAllList_Click(object sender, EventArgs e)
        {
            QuestionsList();
        }
        private void btnWaiting_Click(object sender, EventArgs e)
        {
            WaitingQuestionList();
        }
        private void btnResponsed_Click(object sender, EventArgs e)
        {
            ResponsedQuestionList();
        }
    }
}
