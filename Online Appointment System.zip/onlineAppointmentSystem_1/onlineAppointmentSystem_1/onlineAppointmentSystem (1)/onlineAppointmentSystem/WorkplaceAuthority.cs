﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace onlineAppointmentSystem
{
    public class WorkplaceAuthority
    {
        public string AuthorizedName { get; set; }
        public string AuthorizedSurname { get; set; }
        public string AuthorizedUsername { get; set; }
        public string AuthorizedPhoneNumber { get; set; }
        public string AuthorizedPassword { get; set; }
        public string AuthorizedWhereToWork { get; set; }
        public string AuthorizedEmail { get; set; }
        public DateTime AuthorizedDate { get; set; }
        public string Authorizedidentity { get; set; }
        public string AuthorizedAdress { get; set; }
        public string AuthorizedVerify { get; set; }
        public int Authorizedid { get; set; }
        public ComboBox ComboBoxForRegisterWorkplace { get; set; }
    }
}
