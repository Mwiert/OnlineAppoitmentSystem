﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace onlineAppointmentSystem
{
    public partial class frmResponsedQuestionsAuthority : Form
    {
        public frmResponsedQuestionsAuthority()
        {
            InitializeComponent();
        }
        private void ResponsedQuestionList()
        {
            string Asnwered = "RESPONSED";
            DBEntityQuestionAnswer questionAnswer = new DBEntityQuestionAnswer();
            questionAnswer.QuestionList(dgbResponsedQuestions, Asnwered);
        }
        private void frmResponsedQuestionsAuthority_Load(object sender, EventArgs e)
        {
            ResponsedQuestionList();
        }
    }
}
