﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Data;

namespace onlineAppointmentSystem
{
    class DBEntityNormalUsers : DBEntity
    {
        public void ClientAdd(NormalUsers client)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Insert Into tblClient (ClientName,ClientSurname,ClientUsername,ClientPhoneNumber,ClientEmail,ClientPassword,ClientAdress) values " +
                    "(@ClientName, @ClientSurname, @ClientUsername, @ClientPhoneNumber, @ClientEmail, @ClientPassword, @ClientAdress)",con);
                command.Parameters.AddWithValue("ClientName", client.ClientName);
                command.Parameters.AddWithValue("ClientSurname", client.ClientSurname);
                command.Parameters.AddWithValue("ClientEmail", client.ClientEmail);
                command.Parameters.AddWithValue("ClientUsername", client.ClientUsername);
                command.Parameters.AddWithValue("ClientPhoneNumber", client.ClientPhoneNumber);
                command.Parameters.AddWithValue("ClientPassword", client.ClientPassword);
                command.Parameters.AddWithValue("ClientAdress",client.ClientAdress);
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void UserList(DataGridView DgvQuestionList)
        {
            SqlConnection con = new SqlConnection(ConnStr);
            SqlDataAdapter da = new SqlDataAdapter("Select ClientName,ClientSurname,ClientUsername,ClientPhoneNumber,ClientEmail from TblClient", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            DgvQuestionList.DataSource = ds.Tables[0];
        }
        public bool LoginCheck(NormalUsers NormalUsers)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand cmd = new SqlCommand("SELECT ClientUsername, ClientPassword FROM TblClient WHERE ClientUsername = '" + NormalUsers.ClientUsername  +
                    "' AND ClientPassword = '" + NormalUsers.ClientPassword + "'", con);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
