﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace onlineAppointmentSystem
{
    public partial class frmWorkplaceAddRemoveDeleteUpdate : Form
    {
        public frmWorkplaceAddRemoveDeleteUpdate()
        {
            InitializeComponent();
        }
        private void WorkplaceList()
        {
            DBEntityWorkplace workpcList = new DBEntityWorkplace();
            dgViewWorkplace.DataSource = workpcList.WorkplaceList();
            dgViewWorkplace.Refresh();
        }
        private void addWorkplaceBtn_Click(object sender, EventArgs e)
        {
            try
            {
                Workplace workplace = new Workplace()
                {
                    WorkplaceName = isyeriad.Text,
                    WorkplaceAdress = isyeriadres.Text,
                    WorkplaceCommunication = isyericom.Text,
                    WorkplaceType = isyeritip.Text
                };
                DBEntityWorkplace dBEntityWorkplace = new DBEntityWorkplace();

                dBEntityWorkplace.WorkPlaceAdd(workplace);
                MessageBox.Show("Adding Successful.");
                WorkplaceList();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Operation Failed." + ex.Message);
            }
        }
        private void frmWorkplaceAddRemoveDeleteUpdate_Load(object sender, EventArgs e)
        {
            WorkplaceList();
        }

        private void btnListele_Click(object sender, EventArgs e)
        {
            WorkplaceList();
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            try
            {
                Workplace workplace = new Workplace();
                workplace.Workplaceid = Convert.ToInt32(deleteTxt.Text);

                DBEntityWorkplace dBEntityWorkplace = new DBEntityWorkplace();

                dBEntityWorkplace.WorkPlaceDelete(workplace);

                MessageBox.Show("Successfully Deleted.");

                WorkplaceList();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Operation Failed." + ex.Message);
            }
        }

        private void btnguncelle_Click(object sender, EventArgs e)
        {
            try
            {
                Workplace workplace = new Workplace()
                {
                    WorkplaceName = isyeriad.Text,
                    WorkplaceAdress = isyeriadres.Text,
                    WorkplaceCommunication = isyericom.Text,
                    WorkplaceType = isyeritip.Text,
                    Workplaceid = Convert.ToInt32(txtbxid.Text)
                };
                DBEntityWorkplace dBEntityWorkplace = new DBEntityWorkplace();

                dBEntityWorkplace.WorkPlaceUpdate(workplace);

                MessageBox.Show("Update Successful.");
                WorkplaceList();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Operation Failed." + ex.Message);
            }
        }

        private void btnAra_Click(object sender, EventArgs e)
        {
            DBEntityWorkplace WrkPlcSearch = new DBEntityWorkplace();
            dgViewWorkplace.DataSource = WrkPlcSearch.WorkplaceSearch(txtbxSearchonDG.Text);
        }
    }
}
