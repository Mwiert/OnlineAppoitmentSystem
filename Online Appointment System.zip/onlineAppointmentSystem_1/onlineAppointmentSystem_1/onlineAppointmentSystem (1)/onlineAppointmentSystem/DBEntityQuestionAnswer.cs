﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace onlineAppointmentSystem
{
    class DBEntityQuestionAnswer : DBEntity
    {
        public void QAnsverAdd(QuestionAnswer SrcvpAdd)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Insert into tblSoruCevap (QAHeadline,QAContent,QAtoWhom,Questionid)" +
                    "values(@SoruCevapBaşlığı,@Soruİçeriği,@SorulanKurum,@Questionid)", con);
                command.Parameters.AddWithValue("SoruCevapBaşlığı", SrcvpAdd.QAHeadline);
                command.Parameters.AddWithValue("Soruİçeriği", SrcvpAdd.QAContent);
                command.Parameters.AddWithValue("SorulanKurum", SrcvpAdd.QAtoWhom);
                command.Parameters.AddWithValue("Questionid", SrcvpAdd.Questionid);
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void QuestionList(DataGridView DgvQuestionList, string questionAnswer)
        {
            SqlConnection con = new SqlConnection(ConnStr);
            SqlDataAdapter da = new SqlDataAdapter("Select Questionid,QAHeadline,QAContent,AnswerStatus from tblSoruCevap where AnswerStatus='" + questionAnswer + "'", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            DgvQuestionList.DataSource = ds.Tables[0];
        }
        public void AuthorSendAswer(QuestionAnswer AutSendAnswer)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Update tblSoruCevap SET AnswrAuthor=@answerAut , AnswerStatus=@answerStatus where Questionid=@questionid", con);
                command.Parameters.AddWithValue("@answerAut", AutSendAnswer.AnswrAuthor);
                command.Parameters.AddWithValue("@answerStatus", AutSendAnswer.QuestionStatus);
                command.Parameters.AddWithValue("@questionid", AutSendAnswer.QuestionidDgv);
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public DataTable NormalUserAnswered(QuestionAnswer questionAnswer)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Select AnswrAuthor from tblSoruCevap where Questionid LIKE '%'+@Searchid+'%' ", con);
                command.Parameters.AddWithValue("@Searchid", questionAnswer.QuestionidDgv);
                SqlDataAdapter adp = new SqlDataAdapter(command);
                DataTable srcTable = new DataTable();
                adp.Fill(srcTable);
                return srcTable;
            }
            catch { return null; }
        }
        public void QuestionListForAdmin(DataGridView DgvQuestionList)
        {
            SqlConnection con = new SqlConnection(ConnStr);
            SqlDataAdapter da = new SqlDataAdapter("Select Questionid,QAHeadline,QAContent,AnswerStatus from tblSoruCevap", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            DgvQuestionList.DataSource = ds.Tables[0];
        }
    }
}
