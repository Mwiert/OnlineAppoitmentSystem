﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Mail;

namespace onlineAppointmentSystem
{
    public partial class frmEmailVerify : Form
    {
        public frmEmailVerify()
        {
            InitializeComponent();
        }
        int number;
        Random rnd = new Random();
        private void btnVerysend_Click(object sender, EventArgs e)
        {
            try
            {
                number = rnd.Next(10000, 90000);
                MailMessage msg = new MailMessage();
                SmtpClient client = new SmtpClient();

                client.Credentials = new System.Net.NetworkCredential("bakircayverfybot35@gmail.com", "nypbakircay35");
                client.Port = 587;
                client.Host = "smtp.gmail.com";
                client.EnableSsl = true;

                msg.To.Add(txtWriteEmail.Text);
                msg.From = new MailAddress("bakircayverfybot35@gmail.com", "nypbakircay35");
                msg.Subject = "Security Code";
                msg.Body = number.ToString();

                client.Send(msg);

                MessageBox.Show("MAIL HAS SENT!");
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        private void btnVerfyCode_Click(object sender, EventArgs e)
        {
            if (txtEmailCode.Text == number.ToString())
            {
                MessageBox.Show("Verification Code Correct!!\nYou Will Directed to the Authority Page");
                frmWorkplaceAuthority frmWorkplaceAuthority = new frmWorkplaceAuthority();
                frmWorkplaceAuthority.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("VERIFICATION CODE INCORRECT!");
            }
        }
    }
}
