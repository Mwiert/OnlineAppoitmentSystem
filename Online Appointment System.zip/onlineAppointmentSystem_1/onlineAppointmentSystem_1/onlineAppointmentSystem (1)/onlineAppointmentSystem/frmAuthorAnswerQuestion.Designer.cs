﻿
namespace onlineAppointmentSystem
{
    partial class frmAuthorAnswerQuestion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pnlAuthorAns = new System.Windows.Forms.Panel();
            this.lblinfo = new System.Windows.Forms.Label();
            this.btnSendAnswer = new System.Windows.Forms.Button();
            this.txtHeadline = new System.Windows.Forms.TextBox();
            this.txtQstnId = new System.Windows.Forms.Button();
            this.txtAnswer = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.txtQuestionid = new System.Windows.Forms.TextBox();
            this.rctxtBxQstnFull = new System.Windows.Forms.RichTextBox();
            this.txtshowQstn = new System.Windows.Forms.Button();
            this.dgvQuestions = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.pnlAuthorAns.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuestions)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlAuthorAns
            // 
            this.pnlAuthorAns.BackColor = System.Drawing.Color.Azure;
            this.pnlAuthorAns.Controls.Add(this.lblinfo);
            this.pnlAuthorAns.Controls.Add(this.btnSendAnswer);
            this.pnlAuthorAns.Controls.Add(this.txtHeadline);
            this.pnlAuthorAns.Controls.Add(this.txtQstnId);
            this.pnlAuthorAns.Controls.Add(this.txtAnswer);
            this.pnlAuthorAns.Controls.Add(this.richTextBox1);
            this.pnlAuthorAns.Controls.Add(this.txtQuestionid);
            this.pnlAuthorAns.Controls.Add(this.rctxtBxQstnFull);
            this.pnlAuthorAns.Controls.Add(this.txtshowQstn);
            this.pnlAuthorAns.Controls.Add(this.dgvQuestions);
            this.pnlAuthorAns.Location = new System.Drawing.Point(12, 12);
            this.pnlAuthorAns.Name = "pnlAuthorAns";
            this.pnlAuthorAns.Size = new System.Drawing.Size(1056, 481);
            this.pnlAuthorAns.TabIndex = 0;
            // 
            // lblinfo
            // 
            this.lblinfo.AutoSize = true;
            this.lblinfo.Font = new System.Drawing.Font("Century Gothic", 13F);
            this.lblinfo.Location = new System.Drawing.Point(662, 84);
            this.lblinfo.Name = "lblinfo";
            this.lblinfo.Size = new System.Drawing.Size(394, 21);
            this.lblinfo.TabIndex = 9;
            this.lblinfo.Text = "PRESS TO QUESTION YOU WANT TO ANSWER";
            // 
            // btnSendAnswer
            // 
            this.btnSendAnswer.BackColor = System.Drawing.Color.LightCyan;
            this.btnSendAnswer.Font = new System.Drawing.Font("Century Gothic", 15.75F);
            this.btnSendAnswer.Location = new System.Drawing.Point(179, 424);
            this.btnSendAnswer.Name = "btnSendAnswer";
            this.btnSendAnswer.Size = new System.Drawing.Size(318, 47);
            this.btnSendAnswer.TabIndex = 8;
            this.btnSendAnswer.TabStop = false;
            this.btnSendAnswer.Text = "SEND ANSWER";
            this.btnSendAnswer.UseVisualStyleBackColor = false;
            this.btnSendAnswer.Click += new System.EventHandler(this.btnSendAnswer_Click);
            // 
            // txtHeadline
            // 
            this.txtHeadline.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtHeadline.Location = new System.Drawing.Point(218, 84);
            this.txtHeadline.Name = "txtHeadline";
            this.txtHeadline.Size = new System.Drawing.Size(258, 26);
            this.txtHeadline.TabIndex = 7;
            this.txtHeadline.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtQstnId
            // 
            this.txtQstnId.BackColor = System.Drawing.Color.LightCyan;
            this.txtQstnId.Font = new System.Drawing.Font("Century Gothic", 15.75F);
            this.txtQstnId.Location = new System.Drawing.Point(62, 8);
            this.txtQstnId.Name = "txtQstnId";
            this.txtQstnId.Size = new System.Drawing.Size(184, 47);
            this.txtQstnId.TabIndex = 6;
            this.txtQstnId.TabStop = false;
            this.txtQstnId.Text = "Question ID";
            this.txtQstnId.UseVisualStyleBackColor = false;
            // 
            // txtAnswer
            // 
            this.txtAnswer.BackColor = System.Drawing.Color.LightCyan;
            this.txtAnswer.Font = new System.Drawing.Font("Century Gothic", 15.75F);
            this.txtAnswer.Location = new System.Drawing.Point(136, 218);
            this.txtAnswer.Name = "txtAnswer";
            this.txtAnswer.Size = new System.Drawing.Size(398, 47);
            this.txtAnswer.TabIndex = 5;
            this.txtAnswer.TabStop = false;
            this.txtAnswer.Text = "WRITE YOUR MESSAGE DOWN HERE";
            this.txtAnswer.UseVisualStyleBackColor = false;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.richTextBox1.Location = new System.Drawing.Point(3, 271);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(672, 147);
            this.richTextBox1.TabIndex = 4;
            this.richTextBox1.Text = "";
            // 
            // txtQuestionid
            // 
            this.txtQuestionid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtQuestionid.Location = new System.Drawing.Point(295, 20);
            this.txtQuestionid.Name = "txtQuestionid";
            this.txtQuestionid.Size = new System.Drawing.Size(100, 26);
            this.txtQuestionid.TabIndex = 3;
            // 
            // rctxtBxQstnFull
            // 
            this.rctxtBxQstnFull.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rctxtBxQstnFull.Location = new System.Drawing.Point(3, 116);
            this.rctxtBxQstnFull.Name = "rctxtBxQstnFull";
            this.rctxtBxQstnFull.Size = new System.Drawing.Size(669, 96);
            this.rctxtBxQstnFull.TabIndex = 2;
            this.rctxtBxQstnFull.Text = "";
            // 
            // txtshowQstn
            // 
            this.txtshowQstn.BackColor = System.Drawing.Color.LightCyan;
            this.txtshowQstn.Font = new System.Drawing.Font("Century Gothic", 15.75F);
            this.txtshowQstn.Location = new System.Drawing.Point(701, 20);
            this.txtshowQstn.Name = "txtshowQstn";
            this.txtshowQstn.Size = new System.Drawing.Size(318, 47);
            this.txtshowQstn.TabIndex = 1;
            this.txtshowQstn.TabStop = false;
            this.txtshowQstn.Text = "QUESTIONS";
            this.txtshowQstn.UseVisualStyleBackColor = false;
            // 
            // dgvQuestions
            // 
            this.dgvQuestions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvQuestions.Location = new System.Drawing.Point(681, 116);
            this.dgvQuestions.Name = "dgvQuestions";
            this.dgvQuestions.Size = new System.Drawing.Size(362, 352);
            this.dgvQuestions.TabIndex = 0;
            this.dgvQuestions.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvQuestions_CellClick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // frmAuthorAnswerQuestion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1080, 505);
            this.Controls.Add(this.pnlAuthorAns);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmAuthorAnswerQuestion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmAuthorAnswerQuestion";
            this.Load += new System.EventHandler(this.frmAuthorAnswerQuestion_Load);
            this.pnlAuthorAns.ResumeLayout(false);
            this.pnlAuthorAns.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuestions)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlAuthorAns;
        private System.Windows.Forms.Button txtQstnId;
        private System.Windows.Forms.Button txtAnswer;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.TextBox txtQuestionid;
        private System.Windows.Forms.RichTextBox rctxtBxQstnFull;
        private System.Windows.Forms.Button txtshowQstn;
        private System.Windows.Forms.DataGridView dgvQuestions;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.TextBox txtHeadline;
        private System.Windows.Forms.Button btnSendAnswer;
        private System.Windows.Forms.Label lblinfo;
    }
}