﻿
namespace onlineAppointmentSystem
{
    partial class frmEmailVerify
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEmailVerify));
            this.lblEmailinfo = new System.Windows.Forms.Label();
            this.txtWriteEmail = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.loginAppLogo = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblEmailCode = new System.Windows.Forms.Label();
            this.txtEmailCode = new System.Windows.Forms.TextBox();
            this.btnVerysend = new System.Windows.Forms.Button();
            this.btnVerfyCode = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.loginAppLogo)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblEmailinfo
            // 
            this.lblEmailinfo.AutoSize = true;
            this.lblEmailinfo.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.lblEmailinfo.Location = new System.Drawing.Point(160, 20);
            this.lblEmailinfo.Name = "lblEmailinfo";
            this.lblEmailinfo.Size = new System.Drawing.Size(193, 21);
            this.lblEmailinfo.TabIndex = 0;
            this.lblEmailinfo.Text = "Please Write Your E-mail";
            // 
            // txtWriteEmail
            // 
            this.txtWriteEmail.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.txtWriteEmail.Location = new System.Drawing.Point(145, 62);
            this.txtWriteEmail.Name = "txtWriteEmail";
            this.txtWriteEmail.Size = new System.Drawing.Size(244, 27);
            this.txtWriteEmail.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnVerysend);
            this.panel1.Controls.Add(this.lblEmailinfo);
            this.panel1.Controls.Add(this.txtWriteEmail);
            this.panel1.Location = new System.Drawing.Point(50, 109);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(557, 157);
            this.panel1.TabIndex = 2;
            // 
            // loginAppLogo
            // 
            this.loginAppLogo.Image = ((System.Drawing.Image)(resources.GetObject("loginAppLogo.Image")));
            this.loginAppLogo.Location = new System.Drawing.Point(239, 12);
            this.loginAppLogo.Name = "loginAppLogo";
            this.loginAppLogo.Size = new System.Drawing.Size(179, 94);
            this.loginAppLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.loginAppLogo.TabIndex = 38;
            this.loginAppLogo.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnVerfyCode);
            this.panel2.Controls.Add(this.lblEmailCode);
            this.panel2.Controls.Add(this.txtEmailCode);
            this.panel2.Location = new System.Drawing.Point(50, 272);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(557, 157);
            this.panel2.TabIndex = 39;
            // 
            // lblEmailCode
            // 
            this.lblEmailCode.AutoSize = true;
            this.lblEmailCode.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.lblEmailCode.Location = new System.Drawing.Point(102, 14);
            this.lblEmailCode.Name = "lblEmailCode";
            this.lblEmailCode.Size = new System.Drawing.Size(345, 21);
            this.lblEmailCode.TabIndex = 0;
            this.lblEmailCode.Text = "Please Write The Code You Get From E-mail";
            // 
            // txtEmailCode
            // 
            this.txtEmailCode.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.txtEmailCode.Location = new System.Drawing.Point(145, 60);
            this.txtEmailCode.Name = "txtEmailCode";
            this.txtEmailCode.Size = new System.Drawing.Size(244, 27);
            this.txtEmailCode.TabIndex = 1;
            // 
            // btnVerysend
            // 
            this.btnVerysend.BackColor = System.Drawing.Color.LightCyan;
            this.btnVerysend.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.btnVerysend.Location = new System.Drawing.Point(175, 95);
            this.btnVerysend.Name = "btnVerysend";
            this.btnVerysend.Size = new System.Drawing.Size(188, 53);
            this.btnVerysend.TabIndex = 2;
            this.btnVerysend.Text = "SEND VERIFICATION CODE";
            this.btnVerysend.UseVisualStyleBackColor = false;
            this.btnVerysend.Click += new System.EventHandler(this.btnVerysend_Click);
            // 
            // btnVerfyCode
            // 
            this.btnVerfyCode.BackColor = System.Drawing.Color.LightCyan;
            this.btnVerfyCode.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.btnVerfyCode.Location = new System.Drawing.Point(176, 91);
            this.btnVerfyCode.Name = "btnVerfyCode";
            this.btnVerfyCode.Size = new System.Drawing.Size(188, 53);
            this.btnVerfyCode.TabIndex = 3;
            this.btnVerfyCode.Text = "CONFIRM CODE";
            this.btnVerfyCode.UseVisualStyleBackColor = false;
            this.btnVerfyCode.Click += new System.EventHandler(this.btnVerfyCode_Click);
            // 
            // frmEmailVerify
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(682, 441);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.loginAppLogo);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmEmailVerify";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmEmailVerify";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.loginAppLogo)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblEmailinfo;
        private System.Windows.Forms.TextBox txtWriteEmail;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnVerysend;
        private System.Windows.Forms.PictureBox loginAppLogo;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnVerfyCode;
        private System.Windows.Forms.Label lblEmailCode;
        private System.Windows.Forms.TextBox txtEmailCode;
    }
}