﻿
namespace onlineAppointmentSystem
{
    partial class AuthorRegister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AuthorRegister));
            this.rchtxtBxAdressAut = new System.Windows.Forms.RichTextBox();
            this.pnlRegisterUsers = new System.Windows.Forms.Panel();
            this.cmbxWorkplaceList = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.DTimeAuthor = new System.Windows.Forms.DateTimePicker();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtRegisterIdentityAut = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtRegisterSurnameAut = new System.Windows.Forms.TextBox();
            this.txtRegisterEmailAut = new System.Windows.Forms.TextBox();
            this.pnlRgstrName = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.pnlRgstrNumber = new System.Windows.Forms.Panel();
            this.txtRegisterNameAut = new System.Windows.Forms.TextBox();
            this.pnlRgstrUsername = new System.Windows.Forms.Panel();
            this.btnRgstrRegisterAut = new System.Windows.Forms.Button();
            this.pnlRgstrEmail = new System.Windows.Forms.Panel();
            this.pnlRgstrPassword = new System.Windows.Forms.Panel();
            this.pnlRgstrSurname = new System.Windows.Forms.Panel();
            this.txtRegisterPasswordAut = new System.Windows.Forms.TextBox();
            this.txtRegisterUsernameAut = new System.Windows.Forms.TextBox();
            this.mstxtNumberAut = new System.Windows.Forms.MaskedTextBox();
            this.loginAppLogoAut = new System.Windows.Forms.PictureBox();
            this.minimizedClickAut = new System.Windows.Forms.PictureBox();
            this.closeBottonRegisterAut = new System.Windows.Forms.PictureBox();
            this.topPnlRegister = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAutRgstBack = new System.Windows.Forms.Button();
            this.lblAdress = new System.Windows.Forms.Label();
            this.pnlRegisterUsers.SuspendLayout();
            this.pnlRgstrName.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.loginAppLogoAut)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.minimizedClickAut)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.closeBottonRegisterAut)).BeginInit();
            this.topPnlRegister.SuspendLayout();
            this.SuspendLayout();
            // 
            // rchtxtBxAdressAut
            // 
            this.rchtxtBxAdressAut.Location = new System.Drawing.Point(37, 440);
            this.rchtxtBxAdressAut.Name = "rchtxtBxAdressAut";
            this.rchtxtBxAdressAut.Size = new System.Drawing.Size(237, 78);
            this.rchtxtBxAdressAut.TabIndex = 9;
            this.rchtxtBxAdressAut.Text = "";
            this.rchtxtBxAdressAut.Click += new System.EventHandler(this.rchtxtBxAdressAut_Click);
            // 
            // pnlRegisterUsers
            // 
            this.pnlRegisterUsers.Controls.Add(this.lblAdress);
            this.pnlRegisterUsers.Controls.Add(this.cmbxWorkplaceList);
            this.pnlRegisterUsers.Controls.Add(this.label2);
            this.pnlRegisterUsers.Controls.Add(this.DTimeAuthor);
            this.pnlRegisterUsers.Controls.Add(this.panel4);
            this.pnlRegisterUsers.Controls.Add(this.txtRegisterIdentityAut);
            this.pnlRegisterUsers.Controls.Add(this.panel2);
            this.pnlRegisterUsers.Controls.Add(this.panel3);
            this.pnlRegisterUsers.Controls.Add(this.panel1);
            this.pnlRegisterUsers.Controls.Add(this.rchtxtBxAdressAut);
            this.pnlRegisterUsers.Controls.Add(this.txtRegisterSurnameAut);
            this.pnlRegisterUsers.Controls.Add(this.txtRegisterEmailAut);
            this.pnlRegisterUsers.Controls.Add(this.pnlRgstrName);
            this.pnlRegisterUsers.Controls.Add(this.pnlRgstrNumber);
            this.pnlRegisterUsers.Controls.Add(this.txtRegisterNameAut);
            this.pnlRegisterUsers.Controls.Add(this.pnlRgstrUsername);
            this.pnlRegisterUsers.Controls.Add(this.btnRgstrRegisterAut);
            this.pnlRegisterUsers.Controls.Add(this.pnlRgstrEmail);
            this.pnlRegisterUsers.Controls.Add(this.pnlRgstrPassword);
            this.pnlRegisterUsers.Controls.Add(this.pnlRgstrSurname);
            this.pnlRegisterUsers.Controls.Add(this.txtRegisterPasswordAut);
            this.pnlRegisterUsers.Controls.Add(this.txtRegisterUsernameAut);
            this.pnlRegisterUsers.Controls.Add(this.mstxtNumberAut);
            this.pnlRegisterUsers.Location = new System.Drawing.Point(51, 218);
            this.pnlRegisterUsers.Name = "pnlRegisterUsers";
            this.pnlRegisterUsers.Size = new System.Drawing.Size(302, 630);
            this.pnlRegisterUsers.TabIndex = 14;
            // 
            // cmbxWorkplaceList
            // 
            this.cmbxWorkplaceList.Font = new System.Drawing.Font("Century Gothic", 13F);
            this.cmbxWorkplaceList.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.cmbxWorkplaceList.FormattingEnabled = true;
            this.cmbxWorkplaceList.Location = new System.Drawing.Point(37, 316);
            this.cmbxWorkplaceList.MaxDropDownItems = 7;
            this.cmbxWorkplaceList.Name = "cmbxWorkplaceList";
            this.cmbxWorkplaceList.Size = new System.Drawing.Size(233, 29);
            this.cmbxWorkplaceList.TabIndex = 20;
            this.cmbxWorkplaceList.Text = "Choose Workplace";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 8.25F);
            this.label2.Location = new System.Drawing.Point(85, 242);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(138, 16);
            this.label2.TabIndex = 19;
            this.label2.Text = "Doğum Tarihinizi belirtiniz";
            // 
            // DTimeAuthor
            // 
            this.DTimeAuthor.Location = new System.Drawing.Point(37, 264);
            this.DTimeAuthor.MaxDate = new System.DateTime(2100, 12, 31, 0, 0, 0, 0);
            this.DTimeAuthor.Name = "DTimeAuthor";
            this.DTimeAuthor.Size = new System.Drawing.Size(233, 20);
            this.DTimeAuthor.TabIndex = 6;
            this.DTimeAuthor.Value = new System.DateTime(2021, 1, 11, 2, 30, 38, 0);
            // 
            // panel4
            // 
            this.panel4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel4.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel4.Location = new System.Drawing.Point(39, 290);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(233, 5);
            this.panel4.TabIndex = 17;
            // 
            // txtRegisterIdentityAut
            // 
            this.txtRegisterIdentityAut.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtRegisterIdentityAut.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRegisterIdentityAut.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtRegisterIdentityAut.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtRegisterIdentityAut.Location = new System.Drawing.Point(37, 194);
            this.txtRegisterIdentityAut.Name = "txtRegisterIdentityAut";
            this.txtRegisterIdentityAut.Size = new System.Drawing.Size(233, 26);
            this.txtRegisterIdentityAut.TabIndex = 5;
            this.txtRegisterIdentityAut.Text = "Identity Number";
            this.txtRegisterIdentityAut.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtRegisterIdentityAut.Click += new System.EventHandler(this.txtRegisterIdentityAut_Click);
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel2.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel2.Location = new System.Drawing.Point(37, 226);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(233, 5);
            this.panel2.TabIndex = 15;
            // 
            // panel3
            // 
            this.panel3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel3.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel3.Location = new System.Drawing.Point(37, 360);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(233, 5);
            this.panel3.TabIndex = 16;
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel1.Location = new System.Drawing.Point(39, 524);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(234, 5);
            this.panel1.TabIndex = 12;
            // 
            // txtRegisterSurnameAut
            // 
            this.txtRegisterSurnameAut.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtRegisterSurnameAut.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRegisterSurnameAut.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtRegisterSurnameAut.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtRegisterSurnameAut.Location = new System.Drawing.Point(167, 14);
            this.txtRegisterSurnameAut.Name = "txtRegisterSurnameAut";
            this.txtRegisterSurnameAut.Size = new System.Drawing.Size(125, 26);
            this.txtRegisterSurnameAut.TabIndex = 2;
            this.txtRegisterSurnameAut.Text = "Surname";
            this.txtRegisterSurnameAut.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtRegisterSurnameAut.Click += new System.EventHandler(this.txtRegisterSurnameAut_Click);
            // 
            // txtRegisterEmailAut
            // 
            this.txtRegisterEmailAut.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtRegisterEmailAut.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRegisterEmailAut.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtRegisterEmailAut.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtRegisterEmailAut.Location = new System.Drawing.Point(42, 136);
            this.txtRegisterEmailAut.Name = "txtRegisterEmailAut";
            this.txtRegisterEmailAut.Size = new System.Drawing.Size(233, 26);
            this.txtRegisterEmailAut.TabIndex = 4;
            this.txtRegisterEmailAut.Text = "Email";
            this.txtRegisterEmailAut.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtRegisterEmailAut.Click += new System.EventHandler(this.txtRegisterEmailAut_Click);
            // 
            // pnlRgstrName
            // 
            this.pnlRgstrName.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pnlRgstrName.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pnlRgstrName.Controls.Add(this.panel6);
            this.pnlRgstrName.Controls.Add(this.panel8);
            this.pnlRgstrName.Location = new System.Drawing.Point(15, 46);
            this.pnlRgstrName.Name = "pnlRgstrName";
            this.pnlRgstrName.Size = new System.Drawing.Size(124, 5);
            this.pnlRgstrName.TabIndex = 6;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel6.Location = new System.Drawing.Point(-81, 61);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(277, 5);
            this.panel6.TabIndex = 11;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel8.Location = new System.Drawing.Point(-81, -61);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(277, 5);
            this.panel8.TabIndex = 9;
            // 
            // pnlRgstrNumber
            // 
            this.pnlRgstrNumber.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pnlRgstrNumber.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pnlRgstrNumber.Location = new System.Drawing.Point(40, 411);
            this.pnlRgstrNumber.Name = "pnlRgstrNumber";
            this.pnlRgstrNumber.Size = new System.Drawing.Size(234, 5);
            this.pnlRgstrNumber.TabIndex = 9;
            // 
            // txtRegisterNameAut
            // 
            this.txtRegisterNameAut.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtRegisterNameAut.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRegisterNameAut.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtRegisterNameAut.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtRegisterNameAut.Location = new System.Drawing.Point(15, 14);
            this.txtRegisterNameAut.Name = "txtRegisterNameAut";
            this.txtRegisterNameAut.Size = new System.Drawing.Size(124, 26);
            this.txtRegisterNameAut.TabIndex = 1;
            this.txtRegisterNameAut.Text = "Name";
            this.txtRegisterNameAut.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtRegisterNameAut.Click += new System.EventHandler(this.txtRegisterNameAut_Click);
            // 
            // pnlRgstrUsername
            // 
            this.pnlRgstrUsername.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pnlRgstrUsername.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pnlRgstrUsername.Location = new System.Drawing.Point(42, 107);
            this.pnlRgstrUsername.Name = "pnlRgstrUsername";
            this.pnlRgstrUsername.Size = new System.Drawing.Size(233, 5);
            this.pnlRgstrUsername.TabIndex = 7;
            // 
            // btnRgstrRegisterAut
            // 
            this.btnRgstrRegisterAut.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnRgstrRegisterAut.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnRgstrRegisterAut.FlatAppearance.BorderSize = 0;
            this.btnRgstrRegisterAut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRgstrRegisterAut.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnRgstrRegisterAut.ForeColor = System.Drawing.SystemColors.Info;
            this.btnRgstrRegisterAut.Location = new System.Drawing.Point(73, 593);
            this.btnRgstrRegisterAut.Name = "btnRgstrRegisterAut";
            this.btnRgstrRegisterAut.Size = new System.Drawing.Size(150, 33);
            this.btnRgstrRegisterAut.TabIndex = 11;
            this.btnRgstrRegisterAut.Text = "REGISTER";
            this.btnRgstrRegisterAut.UseVisualStyleBackColor = false;
            this.btnRgstrRegisterAut.Click += new System.EventHandler(this.btnRgstrRegisterAut_Click);
            // 
            // pnlRgstrEmail
            // 
            this.pnlRgstrEmail.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pnlRgstrEmail.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pnlRgstrEmail.Location = new System.Drawing.Point(42, 168);
            this.pnlRgstrEmail.Name = "pnlRgstrEmail";
            this.pnlRgstrEmail.Size = new System.Drawing.Size(233, 5);
            this.pnlRgstrEmail.TabIndex = 8;
            // 
            // pnlRgstrPassword
            // 
            this.pnlRgstrPassword.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pnlRgstrPassword.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pnlRgstrPassword.Location = new System.Drawing.Point(37, 578);
            this.pnlRgstrPassword.Name = "pnlRgstrPassword";
            this.pnlRgstrPassword.Size = new System.Drawing.Size(234, 5);
            this.pnlRgstrPassword.TabIndex = 10;
            // 
            // pnlRgstrSurname
            // 
            this.pnlRgstrSurname.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pnlRgstrSurname.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pnlRgstrSurname.Location = new System.Drawing.Point(167, 46);
            this.pnlRgstrSurname.Name = "pnlRgstrSurname";
            this.pnlRgstrSurname.Size = new System.Drawing.Size(125, 5);
            this.pnlRgstrSurname.TabIndex = 10;
            // 
            // txtRegisterPasswordAut
            // 
            this.txtRegisterPasswordAut.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtRegisterPasswordAut.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRegisterPasswordAut.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtRegisterPasswordAut.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtRegisterPasswordAut.Location = new System.Drawing.Point(38, 546);
            this.txtRegisterPasswordAut.Name = "txtRegisterPasswordAut";
            this.txtRegisterPasswordAut.Size = new System.Drawing.Size(233, 26);
            this.txtRegisterPasswordAut.TabIndex = 10;
            this.txtRegisterPasswordAut.Text = "Password";
            this.txtRegisterPasswordAut.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtRegisterPasswordAut.TextChanged += new System.EventHandler(this.txtRegisterPasswordAut_TextChanged);
            // 
            // txtRegisterUsernameAut
            // 
            this.txtRegisterUsernameAut.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtRegisterUsernameAut.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRegisterUsernameAut.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtRegisterUsernameAut.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtRegisterUsernameAut.Location = new System.Drawing.Point(43, 75);
            this.txtRegisterUsernameAut.Name = "txtRegisterUsernameAut";
            this.txtRegisterUsernameAut.Size = new System.Drawing.Size(233, 26);
            this.txtRegisterUsernameAut.TabIndex = 3;
            this.txtRegisterUsernameAut.Text = "Username";
            this.txtRegisterUsernameAut.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtRegisterUsernameAut.Click += new System.EventHandler(this.txtRegisterUsernameAut_Click);
            // 
            // mstxtNumberAut
            // 
            this.mstxtNumberAut.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.mstxtNumberAut.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.mstxtNumberAut.Location = new System.Drawing.Point(37, 374);
            this.mstxtNumberAut.Mask = "(999) 000-0000";
            this.mstxtNumberAut.Name = "mstxtNumberAut";
            this.mstxtNumberAut.Size = new System.Drawing.Size(234, 31);
            this.mstxtNumberAut.TabIndex = 8;
            this.mstxtNumberAut.Text = "5555555555";
            this.mstxtNumberAut.Click += new System.EventHandler(this.mstxtNumberAut_Click);
            // 
            // loginAppLogoAut
            // 
            this.loginAppLogoAut.Image = ((System.Drawing.Image)(resources.GetObject("loginAppLogoAut.Image")));
            this.loginAppLogoAut.Location = new System.Drawing.Point(114, 59);
            this.loginAppLogoAut.Name = "loginAppLogoAut";
            this.loginAppLogoAut.Size = new System.Drawing.Size(189, 153);
            this.loginAppLogoAut.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.loginAppLogoAut.TabIndex = 13;
            this.loginAppLogoAut.TabStop = false;
            // 
            // minimizedClickAut
            // 
            this.minimizedClickAut.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.minimizedClickAut.Image = ((System.Drawing.Image)(resources.GetObject("minimizedClickAut.Image")));
            this.minimizedClickAut.Location = new System.Drawing.Point(344, 3);
            this.minimizedClickAut.Name = "minimizedClickAut";
            this.minimizedClickAut.Size = new System.Drawing.Size(39, 36);
            this.minimizedClickAut.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.minimizedClickAut.TabIndex = 24;
            this.minimizedClickAut.TabStop = false;
            this.minimizedClickAut.Click += new System.EventHandler(this.minimizedClickAut_Click);
            // 
            // closeBottonRegisterAut
            // 
            this.closeBottonRegisterAut.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.closeBottonRegisterAut.Image = ((System.Drawing.Image)(resources.GetObject("closeBottonRegisterAut.Image")));
            this.closeBottonRegisterAut.Location = new System.Drawing.Point(383, 3);
            this.closeBottonRegisterAut.Name = "closeBottonRegisterAut";
            this.closeBottonRegisterAut.Size = new System.Drawing.Size(39, 36);
            this.closeBottonRegisterAut.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.closeBottonRegisterAut.TabIndex = 0;
            this.closeBottonRegisterAut.TabStop = false;
            this.closeBottonRegisterAut.Click += new System.EventHandler(this.closeBottonRegisterAut_Click);
            // 
            // topPnlRegister
            // 
            this.topPnlRegister.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.topPnlRegister.BackColor = System.Drawing.SystemColors.HotTrack;
            this.topPnlRegister.Controls.Add(this.label1);
            this.topPnlRegister.Controls.Add(this.btnAutRgstBack);
            this.topPnlRegister.Controls.Add(this.minimizedClickAut);
            this.topPnlRegister.Controls.Add(this.closeBottonRegisterAut);
            this.topPnlRegister.Location = new System.Drawing.Point(-1, 0);
            this.topPnlRegister.Name = "topPnlRegister";
            this.topPnlRegister.Size = new System.Drawing.Size(424, 42);
            this.topPnlRegister.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(0, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(19, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "<<";
            // 
            // btnAutRgstBack
            // 
            this.btnAutRgstBack.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnAutRgstBack.BackColor = System.Drawing.SystemColors.MenuText;
            this.btnAutRgstBack.FlatAppearance.BorderSize = 0;
            this.btnAutRgstBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAutRgstBack.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnAutRgstBack.ForeColor = System.Drawing.SystemColors.Info;
            this.btnAutRgstBack.Location = new System.Drawing.Point(20, 7);
            this.btnAutRgstBack.Name = "btnAutRgstBack";
            this.btnAutRgstBack.Size = new System.Drawing.Size(63, 30);
            this.btnAutRgstBack.TabIndex = 15;
            this.btnAutRgstBack.Text = "BACK";
            this.btnAutRgstBack.UseVisualStyleBackColor = false;
            this.btnAutRgstBack.Click += new System.EventHandler(this.btnAutRgstBack_Click);
            // 
            // lblAdress
            // 
            this.lblAdress.AutoSize = true;
            this.lblAdress.Font = new System.Drawing.Font("Century Gothic", 10F);
            this.lblAdress.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblAdress.Location = new System.Drawing.Point(42, 419);
            this.lblAdress.Name = "lblAdress";
            this.lblAdress.Size = new System.Drawing.Size(124, 19);
            this.lblAdress.TabIndex = 21;
            this.lblAdress.Text = "Write Your Adress";
            // 
            // AuthorRegister
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(423, 860);
            this.Controls.Add(this.pnlRegisterUsers);
            this.Controls.Add(this.loginAppLogoAut);
            this.Controls.Add(this.topPnlRegister);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AuthorRegister";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AuthorRegister";
            this.Load += new System.EventHandler(this.AuthorRegister_Load);
            this.pnlRegisterUsers.ResumeLayout(false);
            this.pnlRegisterUsers.PerformLayout();
            this.pnlRgstrName.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.loginAppLogoAut)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.minimizedClickAut)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.closeBottonRegisterAut)).EndInit();
            this.topPnlRegister.ResumeLayout(false);
            this.topPnlRegister.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtBxAdressAut;
        private System.Windows.Forms.Panel pnlRegisterUsers;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtRegisterSurnameAut;
        private System.Windows.Forms.TextBox txtRegisterEmailAut;
        private System.Windows.Forms.Panel pnlRgstrName;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel pnlRgstrNumber;
        private System.Windows.Forms.TextBox txtRegisterNameAut;
        private System.Windows.Forms.Panel pnlRgstrUsername;
        private System.Windows.Forms.Button btnRgstrRegisterAut;
        private System.Windows.Forms.Panel pnlRgstrEmail;
        private System.Windows.Forms.Panel pnlRgstrPassword;
        private System.Windows.Forms.Panel pnlRgstrSurname;
        private System.Windows.Forms.TextBox txtRegisterPasswordAut;
        private System.Windows.Forms.TextBox txtRegisterUsernameAut;
        private System.Windows.Forms.MaskedTextBox mstxtNumberAut;
        private System.Windows.Forms.PictureBox loginAppLogoAut;
        private System.Windows.Forms.PictureBox minimizedClickAut;
        private System.Windows.Forms.PictureBox closeBottonRegisterAut;
        private System.Windows.Forms.Panel topPnlRegister;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAutRgstBack;
        private System.Windows.Forms.TextBox txtRegisterIdentityAut;
        private System.Windows.Forms.DateTimePicker DTimeAuthor;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ComboBox cmbxWorkplaceList;
        private System.Windows.Forms.Label lblAdress;
    }
}