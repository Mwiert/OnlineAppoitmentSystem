﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace onlineAppointmentSystem
{
    public partial class frmNormalUser : Form
    {
        public frmNormalUser()
        {
            InitializeComponent();
        }
        private void SrcWorkplaces_Click(object sender, EventArgs e)
        {
            if (this.MdiChildren.Count() == 0)
            {
                frmSearchWorkplaces frmSearchWorkplaces = new frmSearchWorkplaces();
                frmSearchWorkplaces.MdiParent = this;
                frmSearchWorkplaces.Show();
            }
            else
            {
                MessageBox.Show("YOU CAN ONLY OPEN 1 PAGE AT THE SAME TIME");
            }
            
        }

        private void sorularınızıİletinToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.MdiChildren.Count() == 0)
            {
                frmAskQuestion frmAskQuestion = new frmAskQuestion();
                frmAskQuestion.MdiParent = this;
                frmAskQuestion.Show();
            }
            else
            {
                MessageBox.Show("YOU CAN ONLY OPEN 1 PAGE AT THE SAME TIME");
            }
            
        }
        private void requestAppointmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.MdiChildren.Count() == 0)
            {
                frmGetAppointment frmGetAppointment = new frmGetAppointment();
                frmGetAppointment.MdiParent = this;
                frmGetAppointment.Show();
            }
            else
            {
                MessageBox.Show("YOU CAN ONLY OPEN 1 PAGE AT THE SAME TIME");
            }
            
        }

        private void checkAskedQuestionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.MdiChildren.Count() == 0)
            {
                frmCheckAnsweredQuestions CheckAnsweredQuestions = new frmCheckAnsweredQuestions();
                CheckAnsweredQuestions.MdiParent = this;
                CheckAnsweredQuestions.Show();
            }
            else
            {
                MessageBox.Show("YOU CAN ONLY OPEN 1 PAGE AT THE SAME TIME");
            }
           
        }
    }
}
