﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace onlineAppointmentSystem
{
    class QuestionAnswer
    {
        public string QAHeadline { get; set; }
        public string QAContent { get; set; }
        public string QAtoWhom { get; set; }
        public string AnswrAuthor { get; set; }
        public int Questionid { get; set; }
        public int SelectedRow { get; set; }
        public string QuestionidDgv { get; set; }
        public string QuestionStatus { get; set; }
    }
}
