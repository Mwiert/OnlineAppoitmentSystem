﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace onlineAppointmentSystem
{
    public partial class ChooseForm : Form
    {
        public ChooseForm()
        {
            InitializeComponent();
        }

        private void UserRgstr_Click(object sender, EventArgs e)
        {
            ClientRegister rgstr = new ClientRegister();
            this.Hide();
            rgstr.Show();
        }

        private void minimizedClick_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void closeBottonRegister_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void AuthorRgstr_Click(object sender, EventArgs e)
        {
            AuthorRegister authorRegister = new AuthorRegister();
            this.Hide();
            authorRegister.Show();
        }

        private void btnAutRgstBack_Click(object sender, EventArgs e)
        {
            Opening chsFrmBack = new Opening();
            this.Hide();
            chsFrmBack.Show();
        }
    }
}
