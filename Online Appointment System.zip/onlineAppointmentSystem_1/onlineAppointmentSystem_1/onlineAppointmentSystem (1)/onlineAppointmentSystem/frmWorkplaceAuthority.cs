﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace onlineAppointmentSystem
{
    public partial class frmWorkplaceAuthority : Form
    {
        public frmWorkplaceAuthority()
        {
            InitializeComponent();
        }
        private void answerQuestionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.MdiChildren.Count() == 0)
            {
                frmAuthorAnswerQuestion frmAuthorAnswerQuestion = new frmAuthorAnswerQuestion();
                frmAuthorAnswerQuestion.MdiParent = this;
                frmAuthorAnswerQuestion.Show();
            }
            else
            {
                MessageBox.Show("YOU CAN ONLY OPEN 1 PAGE AT THE SAME TIME");
            }
            
        }
        private void rESPONSEDQUESTIONSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.MdiChildren.Count() == 0)
            {
                frmResponsedQuestionsAuthority frmResponsedQuestionsAuthority = new frmResponsedQuestionsAuthority();
                frmResponsedQuestionsAuthority.MdiParent = this;
                frmResponsedQuestionsAuthority.Show();
            }
            else
            {
                MessageBox.Show("YOU CAN ONLY OPEN 1 PAGE AT THE SAME TIME");
            }
        }

        private void controlAppoitmentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.MdiChildren.Count() == 0)
            {
                frmControlAppointments frmControlAppointments = new frmControlAppointments();
                frmControlAppointments.MdiParent = this;
                frmControlAppointments.Show();
            }
            else
            {
                MessageBox.Show("YOU CAN ONLY OPEN 1 PAGE AT THE SAME TIME");
            }
        }
        private void openedAppointmentDatesToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmOpenedAppointmentDays frmOpenedAppointmentDays = new frmOpenedAppointmentDays();
            frmOpenedAppointmentDays.MdiParent = this;
            frmOpenedAppointmentDays.Show();
        }

        private void currentAppointmentStatusToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCurrentAppointmentStatus frmOpenedAppointmetsDatesReport = new frmCurrentAppointmentStatus();
            frmOpenedAppointmetsDatesReport.MdiParent = this;
            frmOpenedAppointmetsDatesReport.Show();
        }
    }
}
