﻿namespace onlineAppointmentSystem
{
    partial class frmNormalUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.işlemlerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SrcWorkplaces = new System.Windows.Forms.ToolStripMenuItem();
            this.RqstTaksBar = new System.Windows.Forms.ToolStripMenuItem();
            this.requestAppointmentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bizeUlaşınToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sorularınızıİletinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iletişimeGeçinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.checkAskedQuestionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.işlemlerToolStripMenuItem,
            this.RqstTaksBar,
            this.bizeUlaşınToolStripMenuItem,
            this.checkAskedQuestionsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1077, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // işlemlerToolStripMenuItem
            // 
            this.işlemlerToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SrcWorkplaces});
            this.işlemlerToolStripMenuItem.Name = "işlemlerToolStripMenuItem";
            this.işlemlerToolStripMenuItem.Size = new System.Drawing.Size(105, 20);
            this.işlemlerToolStripMenuItem.Text = "Workplace Tasks";
            // 
            // SrcWorkplaces
            // 
            this.SrcWorkplaces.Name = "SrcWorkplaces";
            this.SrcWorkplaces.Size = new System.Drawing.Size(180, 22);
            this.SrcWorkplaces.Text = "Search Workplaces";
            this.SrcWorkplaces.Click += new System.EventHandler(this.SrcWorkplaces_Click);
            // 
            // RqstTaksBar
            // 
            this.RqstTaksBar.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.requestAppointmentToolStripMenuItem});
            this.RqstTaksBar.Name = "RqstTaksBar";
            this.RqstTaksBar.Size = new System.Drawing.Size(113, 20);
            this.RqstTaksBar.Text = "Appoitment Tasks";
            // 
            // requestAppointmentToolStripMenuItem
            // 
            this.requestAppointmentToolStripMenuItem.Name = "requestAppointmentToolStripMenuItem";
            this.requestAppointmentToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.requestAppointmentToolStripMenuItem.Text = "Request An Appoitment";
            this.requestAppointmentToolStripMenuItem.Click += new System.EventHandler(this.requestAppointmentToolStripMenuItem_Click);
            // 
            // bizeUlaşınToolStripMenuItem
            // 
            this.bizeUlaşınToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sorularınızıİletinToolStripMenuItem,
            this.iletişimeGeçinToolStripMenuItem});
            this.bizeUlaşınToolStripMenuItem.Name = "bizeUlaşınToolStripMenuItem";
            this.bizeUlaşınToolStripMenuItem.Size = new System.Drawing.Size(76, 20);
            this.bizeUlaşınToolStripMenuItem.Text = "Contact us";
            // 
            // sorularınızıİletinToolStripMenuItem
            // 
            this.sorularınızıİletinToolStripMenuItem.Name = "sorularınızıİletinToolStripMenuItem";
            this.sorularınızıİletinToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.sorularınızıİletinToolStripMenuItem.Text = "Ask Question";
            this.sorularınızıİletinToolStripMenuItem.Click += new System.EventHandler(this.sorularınızıİletinToolStripMenuItem_Click);
            // 
            // iletişimeGeçinToolStripMenuItem
            // 
            this.iletişimeGeçinToolStripMenuItem.Name = "iletişimeGeçinToolStripMenuItem";
            this.iletişimeGeçinToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.iletişimeGeçinToolStripMenuItem.Text = "Find Us";
            // 
            // checkAskedQuestionsToolStripMenuItem
            // 
            this.checkAskedQuestionsToolStripMenuItem.Name = "checkAskedQuestionsToolStripMenuItem";
            this.checkAskedQuestionsToolStripMenuItem.Size = new System.Drawing.Size(143, 20);
            this.checkAskedQuestionsToolStripMenuItem.Text = "Check Asked Questions";
            this.checkAskedQuestionsToolStripMenuItem.Click += new System.EventHandler(this.checkAskedQuestionsToolStripMenuItem_Click);
            // 
            // frmNormalUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1077, 815);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmNormalUser";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmNormalUser";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem işlemlerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SrcWorkplaces;
        private System.Windows.Forms.ToolStripMenuItem RqstTaksBar;
        private System.Windows.Forms.ToolStripMenuItem requestAppointmentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bizeUlaşınToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sorularınızıİletinToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iletişimeGeçinToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem checkAskedQuestionsToolStripMenuItem;
    }
}