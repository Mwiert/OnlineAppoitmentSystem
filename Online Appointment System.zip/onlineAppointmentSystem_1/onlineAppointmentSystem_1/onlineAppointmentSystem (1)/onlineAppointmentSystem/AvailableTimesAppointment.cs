﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace onlineAppointmentSystem
{
    class AvailableTimesAppointment
    {
        public string time8_9 { get; set; }
        public string time9_10 { get; set; }
        public string time10_11 { get; set; }
        public string time11_12 { get; set; }
        public string time13_14 { get; set; }
        public string time14_15 { get; set; }
        public string time15_16 { get; set; }
        public string time16_17 { get; set; }
        public DateTime AppointmentDatetime { get; set; }
    }
}
