﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace onlineAppointmentSystem
{
    public partial class AuthorRegister : Form
    {
        public AuthorRegister()
        {
            InitializeComponent();
        }

        private void closeBottonRegisterAut_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void minimizedClickAut_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnAutRgstBack_Click(object sender, EventArgs e)
        {
            ChooseForm chsFrmBack = new ChooseForm();
            this.Hide();
            chsFrmBack.Show();
        }

        private void txtRegisterNameAut_TextChanged(object sender, EventArgs e)
        {
            txtRegisterNameAut.Clear();
        }

        private void txtRegisterPasswordAut_TextChanged(object sender, EventArgs e)
        {
            txtRegisterPasswordAut.PasswordChar = '*';
            txtRegisterPasswordAut.MaxLength = 30;
        }

        private void txtRegisterNameAut_Click(object sender, EventArgs e)
        {
            txtRegisterNameAut.Clear();
        }

        private void txtRegisterIdentityAut_Click(object sender, EventArgs e)
        {
            txtRegisterIdentityAut.Clear();
        }

        private readonly DBEntityWorkplaceAuthority readonlyAuthors = new DBEntityWorkplaceAuthority();
        private void AuthorAdd(WorkplaceAuthority workplaceAuthority)
        {
            WorkplaceAuthority authoradd = new WorkplaceAuthority()
            {
            AuthorizedName = txtRegisterNameAut.Text,
            AuthorizedSurname = txtRegisterSurnameAut.Text,
            AuthorizedUsername = txtRegisterUsernameAut.Text,
            AuthorizedEmail = txtRegisterEmailAut.Text,
            Authorizedidentity = txtRegisterIdentityAut.Text,
            AuthorizedDate = DTimeAuthor.Value,
            AuthorizedWhereToWork = cmbxWorkplaceList.Text,
            AuthorizedAdress = rchtxtBxAdressAut.Text,
            AuthorizedPassword = txtRegisterPasswordAut.Text,
            AuthorizedPhoneNumber = mstxtNumberAut.Text,
            };
            readonlyAuthors.AuthorAdd(authoradd);
        }
        private void btnRgstrRegisterAut_Click(object sender, EventArgs e)
        {
            if (txtRegisterIdentityAut.Text.Length != 11)
            {
                MessageBox.Show("Identity Number Must be 11 Digits");
                txtRegisterIdentityAut.Clear();
            }
            else if (cmbxWorkplaceList.SelectedIndex < 0)
            {
                MessageBox.Show("PLEASE SELECT A WORKPLACE");
            }
            else
            {
                try
                {
                    DBEntityWorkplaceAuthority dBEntityWorkplaceAuthority = new DBEntityWorkplaceAuthority();
                    WorkplaceAuthority workplaceAuthority = new WorkplaceAuthority();
                    AuthorAdd(workplaceAuthority);
                    frmEmailVerify frmEmailVerify = new frmEmailVerify();
                    frmEmailVerify.Show();
                    this.Hide();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("OPERATION FAILED" + ex.Message);
                }
            }
            
        }
        private void mstxtNumberAut_Click(object sender, EventArgs e)
        {
            mstxtNumberAut.Clear();
        }
        private void rchtxtBxAdressAut_Click(object sender, EventArgs e)
        {
            rchtxtBxAdressAut.Clear();
        }

        private void AuthorRegister_Load(object sender, EventArgs e)
        {
            WorkplaceAuthority rgstrSystemWp = new WorkplaceAuthority()
            {
                ComboBoxForRegisterWorkplace = cmbxWorkplaceList
            };
            DBEntityWorkplaceAuthority wrklistSystem = new DBEntityWorkplaceAuthority();
            wrklistSystem.ListWorkplaces(rgstrSystemWp);
        }

        private void txtRegisterSurnameAut_Click(object sender, EventArgs e)
        {
            txtRegisterSurnameAut.Clear();
        }

        private void txtRegisterUsernameAut_Click(object sender, EventArgs e)
        {
            txtRegisterUsernameAut.Clear();
        }

        private void txtRegisterEmailAut_Click(object sender, EventArgs e)
        {
            txtRegisterEmailAut.Clear();
        }
    }
}
