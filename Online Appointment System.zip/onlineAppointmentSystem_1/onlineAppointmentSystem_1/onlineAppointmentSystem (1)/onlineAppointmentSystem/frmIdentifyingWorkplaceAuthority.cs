﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace onlineAppointmentSystem
{
    public partial class frmIdentifyingWorkplaceAuthority : Form
    {
        public frmIdentifyingWorkplaceAuthority()
        {
            InitializeComponent();
        }
        private void AuthorListNonVerify()
        {
            string OnayWord = "WAITING";
            DBEntityWorkplaceAuthority AutListNoVerfy = new DBEntityWorkplaceAuthority();
            dgvYetkiliOnay.DataSource = AutListNoVerfy.AuthorNonVerify(OnayWord);
            dgvYetkiliOnay.Refresh();
        }
        private void Notverify_Click(object sender, EventArgs e)
        {
            AuthorListNonVerify();
        }
        private void AuthorListVerified()
        {
            string OnayWord = "APPROVED";
            DBEntityWorkplaceAuthority AutListNoVerfy = new DBEntityWorkplaceAuthority();
            dgvYetkiliOnay.DataSource = AutListNoVerfy.AuthorNonVerify(OnayWord);
            dgvYetkiliOnay.Refresh();
        }
        private void btnOnaylanmisgoster_Click(object sender, EventArgs e)
        {
            AuthorListVerified();
        }
        private void AuthorList()
        {
            DBEntityWorkplaceAuthority AutListNoVerfy = new DBEntityWorkplaceAuthority();
            dgvYetkiliOnay.DataSource = AutListNoVerfy.AuthorNonVerify("");
            dgvYetkiliOnay.Refresh();
        }
        private void btnYetkiliRegGoster_Click(object sender, EventArgs e)
        {
            AuthorList();
        }
        private void AuthorDenied()
        {
            string red = "DENIED";
            DBEntityWorkplaceAuthority AutListDenied = new DBEntityWorkplaceAuthority();
            dgvYetkiliOnay.DataSource = AutListDenied.AuthorNonVerify(red);
            dgvYetkiliOnay.Refresh();
        }
        private void AuthorAccept()
        {
            string onay = "APPROVED";
            DBEntityWorkplaceAuthority AutListDenied = new DBEntityWorkplaceAuthority();
            dgvYetkiliOnay.DataSource = AutListDenied.AuthorNonVerify(onay);
            dgvYetkiliOnay.Refresh();
        }

        private void btnReddet_Click(object sender, EventArgs e)
        {
            try
            {
                WorkplaceAuthority workplaceAuthority = new WorkplaceAuthority()
                {
                    AuthorizedVerify = "DENIED",
                    Authorizedid = Convert.ToInt32(autOnayid.Text)
                };

                DBEntityWorkplaceAuthority dBEntityWorkplaceAuthority = new DBEntityWorkplaceAuthority();

                dBEntityWorkplaceAuthority.AuthorStatusUpdate(workplaceAuthority);

                MessageBox.Show("Authorization Denied.");

                AuthorList();
            }
            catch (Exception ex)
            {

                MessageBox.Show("Operation Failed." + ex.Message);
            }
        }

        private void btnRed_Click(object sender, EventArgs e)
        {
            AuthorDenied();
        }

        private void btnOnayla_Click(object sender, EventArgs e)
        {
            try
            {
                WorkplaceAuthority workplaceAuthority = new WorkplaceAuthority()
                {
                    AuthorizedVerify = "APPROVED.",
                    Authorizedid = Convert.ToInt32(autOnayid.Text)
                };
                DBEntityWorkplaceAuthority dBEntityWorkplaceAuthority = new DBEntityWorkplaceAuthority();

                dBEntityWorkplaceAuthority.AuthorStatusUpdate(workplaceAuthority);

                MessageBox.Show("Authorization Approved..");
                AuthorList();
            }
            catch (Exception ex)
            {

                MessageBox.Show("Operation Failed." + ex.Message);
            }
        }
        private void btnOnayGoster_Click(object sender, EventArgs e)
        {
            AuthorAccept();
        }

        private void closeBottonRegister_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void minimizedClick_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
