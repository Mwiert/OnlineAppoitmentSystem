﻿namespace onlineAppointmentSystem
{
    partial class frmIdentifyingWorkplaceAuthority
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmIdentifyingWorkplaceAuthority));
            this.autOnayid = new System.Windows.Forms.TextBox();
            this.btnRed = new System.Windows.Forms.Button();
            this.btnOnayGoster = new System.Windows.Forms.Button();
            this.btnReddet = new System.Windows.Forms.Button();
            this.btnOnayla = new System.Windows.Forms.Button();
            this.lblSetidVerfy = new System.Windows.Forms.Label();
            this.btnYetkiliRegGoster = new System.Windows.Forms.Button();
            this.dgvYetkiliOnay = new System.Windows.Forms.DataGridView();
            this.Notverify = new System.Windows.Forms.Button();
            this.loginAppLogo = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvYetkiliOnay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginAppLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // autOnayid
            // 
            this.autOnayid.Font = new System.Drawing.Font("Century Gothic", 14.25F);
            this.autOnayid.Location = new System.Drawing.Point(272, 524);
            this.autOnayid.Name = "autOnayid";
            this.autOnayid.Size = new System.Drawing.Size(104, 31);
            this.autOnayid.TabIndex = 35;
            // 
            // btnRed
            // 
            this.btnRed.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnRed.Font = new System.Drawing.Font("Century Gothic", 14.25F);
            this.btnRed.Location = new System.Drawing.Point(373, 734);
            this.btnRed.Name = "btnRed";
            this.btnRed.Size = new System.Drawing.Size(137, 75);
            this.btnRed.TabIndex = 34;
            this.btnRed.Text = "LIST DENIED AUTHOR USERS";
            this.btnRed.UseVisualStyleBackColor = false;
            this.btnRed.Click += new System.EventHandler(this.btnRed_Click);
            // 
            // btnOnayGoster
            // 
            this.btnOnayGoster.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnOnayGoster.Font = new System.Drawing.Font("Century Gothic", 14.25F);
            this.btnOnayGoster.Location = new System.Drawing.Point(373, 633);
            this.btnOnayGoster.Name = "btnOnayGoster";
            this.btnOnayGoster.Size = new System.Drawing.Size(137, 80);
            this.btnOnayGoster.TabIndex = 33;
            this.btnOnayGoster.Text = "LIST APPROVED AUTHOR USERS";
            this.btnOnayGoster.UseVisualStyleBackColor = false;
            this.btnOnayGoster.Click += new System.EventHandler(this.btnOnayGoster_Click);
            // 
            // btnReddet
            // 
            this.btnReddet.BackColor = System.Drawing.Color.Red;
            this.btnReddet.Font = new System.Drawing.Font("Century Gothic", 14.25F);
            this.btnReddet.Location = new System.Drawing.Point(373, 563);
            this.btnReddet.Name = "btnReddet";
            this.btnReddet.Size = new System.Drawing.Size(137, 36);
            this.btnReddet.TabIndex = 32;
            this.btnReddet.Text = "DENY";
            this.btnReddet.UseVisualStyleBackColor = false;
            this.btnReddet.Click += new System.EventHandler(this.btnReddet_Click);
            // 
            // btnOnayla
            // 
            this.btnOnayla.BackColor = System.Drawing.Color.Green;
            this.btnOnayla.Font = new System.Drawing.Font("Century Gothic", 14.25F);
            this.btnOnayla.Location = new System.Drawing.Point(135, 563);
            this.btnOnayla.Name = "btnOnayla";
            this.btnOnayla.Size = new System.Drawing.Size(140, 36);
            this.btnOnayla.TabIndex = 31;
            this.btnOnayla.Text = "APPROVE";
            this.btnOnayla.UseVisualStyleBackColor = false;
            this.btnOnayla.Click += new System.EventHandler(this.btnOnayla_Click);
            // 
            // lblSetidVerfy
            // 
            this.lblSetidVerfy.AutoSize = true;
            this.lblSetidVerfy.Font = new System.Drawing.Font("Century Gothic", 14.25F);
            this.lblSetidVerfy.Location = new System.Drawing.Point(184, 487);
            this.lblSetidVerfy.Name = "lblSetidVerfy";
            this.lblSetidVerfy.Size = new System.Drawing.Size(305, 22);
            this.lblSetidVerfy.TabIndex = 30;
            this.lblSetidVerfy.Text = "Write ID To You Want To Change";
            // 
            // btnYetkiliRegGoster
            // 
            this.btnYetkiliRegGoster.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnYetkiliRegGoster.Font = new System.Drawing.Font("Century Gothic", 14.25F);
            this.btnYetkiliRegGoster.Location = new System.Drawing.Point(135, 633);
            this.btnYetkiliRegGoster.Name = "btnYetkiliRegGoster";
            this.btnYetkiliRegGoster.Size = new System.Drawing.Size(141, 80);
            this.btnYetkiliRegGoster.TabIndex = 29;
            this.btnYetkiliRegGoster.Text = "LIST ALL AUTHOR USERS";
            this.btnYetkiliRegGoster.UseVisualStyleBackColor = false;
            this.btnYetkiliRegGoster.Click += new System.EventHandler(this.btnYetkiliRegGoster_Click);
            // 
            // dgvYetkiliOnay
            // 
            this.dgvYetkiliOnay.BackgroundColor = System.Drawing.Color.Azure;
            this.dgvYetkiliOnay.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvYetkiliOnay.Location = new System.Drawing.Point(56, 156);
            this.dgvYetkiliOnay.Name = "dgvYetkiliOnay";
            this.dgvYetkiliOnay.Size = new System.Drawing.Size(533, 315);
            this.dgvYetkiliOnay.TabIndex = 28;
            // 
            // Notverify
            // 
            this.Notverify.BackColor = System.Drawing.SystemColors.HotTrack;
            this.Notverify.Font = new System.Drawing.Font("Century Gothic", 14.25F);
            this.Notverify.Location = new System.Drawing.Point(138, 734);
            this.Notverify.Name = "Notverify";
            this.Notverify.Size = new System.Drawing.Size(138, 75);
            this.Notverify.TabIndex = 27;
            this.Notverify.Text = "LIST WAITING AUTHOR USERS";
            this.Notverify.UseVisualStyleBackColor = false;
            this.Notverify.Click += new System.EventHandler(this.Notverify_Click);
            // 
            // loginAppLogo
            // 
            this.loginAppLogo.Image = ((System.Drawing.Image)(resources.GetObject("loginAppLogo.Image")));
            this.loginAppLogo.Location = new System.Drawing.Point(229, 47);
            this.loginAppLogo.Name = "loginAppLogo";
            this.loginAppLogo.Size = new System.Drawing.Size(179, 94);
            this.loginAppLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.loginAppLogo.TabIndex = 37;
            this.loginAppLogo.TabStop = false;
            // 
            // frmIdentifyingWorkplaceAuthority
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(643, 827);
            this.Controls.Add(this.loginAppLogo);
            this.Controls.Add(this.autOnayid);
            this.Controls.Add(this.btnRed);
            this.Controls.Add(this.btnOnayGoster);
            this.Controls.Add(this.btnReddet);
            this.Controls.Add(this.btnOnayla);
            this.Controls.Add(this.lblSetidVerfy);
            this.Controls.Add(this.btnYetkiliRegGoster);
            this.Controls.Add(this.dgvYetkiliOnay);
            this.Controls.Add(this.Notverify);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmIdentifyingWorkplaceAuthority";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmIdentifyingWorkplaceAuthority";
            ((System.ComponentModel.ISupportInitialize)(this.dgvYetkiliOnay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginAppLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox autOnayid;
        private System.Windows.Forms.Button btnRed;
        private System.Windows.Forms.Button btnOnayGoster;
        private System.Windows.Forms.Button btnReddet;
        private System.Windows.Forms.Button btnOnayla;
        private System.Windows.Forms.Label lblSetidVerfy;
        private System.Windows.Forms.Button btnYetkiliRegGoster;
        private System.Windows.Forms.DataGridView dgvYetkiliOnay;
        private System.Windows.Forms.Button Notverify;
        private System.Windows.Forms.PictureBox loginAppLogo;
    }
}