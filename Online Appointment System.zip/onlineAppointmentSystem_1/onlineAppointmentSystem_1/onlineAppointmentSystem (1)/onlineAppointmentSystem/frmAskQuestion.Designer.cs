﻿
namespace onlineAppointmentSystem
{
    partial class frmAskQuestion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAskQuestion));
            this.pnlBizeUlasin = new System.Windows.Forms.Panel();
            this.cmbxWorkplaceList = new System.Windows.Forms.ComboBox();
            this.btnSendMsg = new System.Windows.Forms.Button();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.txtContentContact = new System.Windows.Forms.TextBox();
            this.rtxtCUMessage = new System.Windows.Forms.RichTextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtSoruBasligi = new System.Windows.Forms.TextBox();
            this.pnlRgstrName = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txtQuestionId = new System.Windows.Forms.TextBox();
            this.loginAppLogo = new System.Windows.Forms.PictureBox();
            this.lblinfo = new System.Windows.Forms.Label();
            this.pnlBizeUlasin.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.pnlRgstrName.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.loginAppLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlBizeUlasin
            // 
            this.pnlBizeUlasin.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pnlBizeUlasin.Controls.Add(this.lblinfo);
            this.pnlBizeUlasin.Controls.Add(this.cmbxWorkplaceList);
            this.pnlBizeUlasin.Controls.Add(this.btnSendMsg);
            this.pnlBizeUlasin.Controls.Add(this.panel12);
            this.pnlBizeUlasin.Controls.Add(this.panel9);
            this.pnlBizeUlasin.Controls.Add(this.txtContentContact);
            this.pnlBizeUlasin.Controls.Add(this.rtxtCUMessage);
            this.pnlBizeUlasin.Controls.Add(this.panel4);
            this.pnlBizeUlasin.Controls.Add(this.panel1);
            this.pnlBizeUlasin.Controls.Add(this.txtSoruBasligi);
            this.pnlBizeUlasin.Controls.Add(this.pnlRgstrName);
            this.pnlBizeUlasin.Controls.Add(this.txtQuestionId);
            this.pnlBizeUlasin.Location = new System.Drawing.Point(31, 150);
            this.pnlBizeUlasin.Name = "pnlBizeUlasin";
            this.pnlBizeUlasin.Size = new System.Drawing.Size(723, 473);
            this.pnlBizeUlasin.TabIndex = 10;
            // 
            // cmbxWorkplaceList
            // 
            this.cmbxWorkplaceList.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.cmbxWorkplaceList.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.cmbxWorkplaceList.FormattingEnabled = true;
            this.cmbxWorkplaceList.ItemHeight = 21;
            this.cmbxWorkplaceList.Location = new System.Drawing.Point(194, 159);
            this.cmbxWorkplaceList.Name = "cmbxWorkplaceList";
            this.cmbxWorkplaceList.Size = new System.Drawing.Size(322, 29);
            this.cmbxWorkplaceList.TabIndex = 21;
            this.cmbxWorkplaceList.Text = "Choose Workplace";
            // 
            // btnSendMsg
            // 
            this.btnSendMsg.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnSendMsg.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnSendMsg.FlatAppearance.BorderSize = 0;
            this.btnSendMsg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSendMsg.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSendMsg.ForeColor = System.Drawing.SystemColors.Info;
            this.btnSendMsg.Location = new System.Drawing.Point(273, 435);
            this.btnSendMsg.Name = "btnSendMsg";
            this.btnSendMsg.Size = new System.Drawing.Size(150, 33);
            this.btnSendMsg.TabIndex = 4;
            this.btnSendMsg.Text = "SEND";
            this.btnSendMsg.UseVisualStyleBackColor = false;
            this.btnSendMsg.Click += new System.EventHandler(this.btnSendMsg_Click);
            // 
            // panel12
            // 
            this.panel12.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel12.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel12.Controls.Add(this.panel13);
            this.panel12.Controls.Add(this.panel14);
            this.panel12.Location = new System.Drawing.Point(194, 420);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(322, 5);
            this.panel12.TabIndex = 20;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel13.Location = new System.Drawing.Point(-81, 61);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(277, 5);
            this.panel13.TabIndex = 11;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel14.Location = new System.Drawing.Point(-81, -61);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(277, 5);
            this.panel14.TabIndex = 9;
            // 
            // panel9
            // 
            this.panel9.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel9.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel9.Controls.Add(this.panel10);
            this.panel9.Controls.Add(this.panel11);
            this.panel9.Location = new System.Drawing.Point(194, 247);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(322, 5);
            this.panel9.TabIndex = 19;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel10.Location = new System.Drawing.Point(-81, 61);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(277, 5);
            this.panel10.TabIndex = 11;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel11.Location = new System.Drawing.Point(-81, -61);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(277, 5);
            this.panel11.TabIndex = 9;
            // 
            // txtContentContact
            // 
            this.txtContentContact.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtContentContact.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtContentContact.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtContentContact.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtContentContact.Location = new System.Drawing.Point(194, 215);
            this.txtContentContact.Name = "txtContentContact";
            this.txtContentContact.Size = new System.Drawing.Size(322, 26);
            this.txtContentContact.TabIndex = 18;
            this.txtContentContact.TabStop = false;
            this.txtContentContact.Text = "Write Your Message";
            this.txtContentContact.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // rtxtCUMessage
            // 
            this.rtxtCUMessage.Location = new System.Drawing.Point(194, 258);
            this.rtxtCUMessage.Name = "rtxtCUMessage";
            this.rtxtCUMessage.Size = new System.Drawing.Size(322, 158);
            this.rtxtCUMessage.TabIndex = 3;
            this.rtxtCUMessage.Text = "";
            // 
            // panel4
            // 
            this.panel4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel4.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Controls.Add(this.panel7);
            this.panel4.Location = new System.Drawing.Point(194, 199);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(322, 5);
            this.panel4.TabIndex = 17;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel5.Location = new System.Drawing.Point(-81, 61);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(277, 5);
            this.panel5.TabIndex = 11;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel7.Location = new System.Drawing.Point(-81, -61);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(277, 5);
            this.panel7.TabIndex = 9;
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Location = new System.Drawing.Point(194, 133);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(322, 5);
            this.panel1.TabIndex = 15;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel2.Location = new System.Drawing.Point(-81, 61);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(277, 5);
            this.panel2.TabIndex = 11;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel3.Location = new System.Drawing.Point(-81, -61);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(277, 5);
            this.panel3.TabIndex = 9;
            // 
            // txtSoruBasligi
            // 
            this.txtSoruBasligi.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtSoruBasligi.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSoruBasligi.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtSoruBasligi.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtSoruBasligi.Location = new System.Drawing.Point(194, 101);
            this.txtSoruBasligi.Name = "txtSoruBasligi";
            this.txtSoruBasligi.Size = new System.Drawing.Size(322, 26);
            this.txtSoruBasligi.TabIndex = 1;
            this.txtSoruBasligi.Text = "Question Title";
            this.txtSoruBasligi.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pnlRgstrName
            // 
            this.pnlRgstrName.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pnlRgstrName.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pnlRgstrName.Controls.Add(this.panel6);
            this.pnlRgstrName.Controls.Add(this.panel8);
            this.pnlRgstrName.Location = new System.Drawing.Point(316, 72);
            this.pnlRgstrName.Name = "pnlRgstrName";
            this.pnlRgstrName.Size = new System.Drawing.Size(90, 5);
            this.pnlRgstrName.TabIndex = 13;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel6.Location = new System.Drawing.Point(-81, 61);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(277, 5);
            this.panel6.TabIndex = 11;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel8.Location = new System.Drawing.Point(-81, -61);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(277, 5);
            this.panel8.TabIndex = 9;
            // 
            // txtQuestionId
            // 
            this.txtQuestionId.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtQuestionId.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtQuestionId.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.txtQuestionId.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtQuestionId.Location = new System.Drawing.Point(316, 40);
            this.txtQuestionId.Name = "txtQuestionId";
            this.txtQuestionId.Size = new System.Drawing.Size(88, 20);
            this.txtQuestionId.TabIndex = 11;
            this.txtQuestionId.TabStop = false;
            this.txtQuestionId.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // loginAppLogo
            // 
            this.loginAppLogo.Image = ((System.Drawing.Image)(resources.GetObject("loginAppLogo.Image")));
            this.loginAppLogo.Location = new System.Drawing.Point(287, 12);
            this.loginAppLogo.Name = "loginAppLogo";
            this.loginAppLogo.Size = new System.Drawing.Size(189, 123);
            this.loginAppLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.loginAppLogo.TabIndex = 11;
            this.loginAppLogo.TabStop = false;
            // 
            // lblinfo
            // 
            this.lblinfo.AutoSize = true;
            this.lblinfo.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.lblinfo.ForeColor = System.Drawing.Color.Maroon;
            this.lblinfo.Location = new System.Drawing.Point(170, 7);
            this.lblinfo.Name = "lblinfo";
            this.lblinfo.Size = new System.Drawing.Size(374, 23);
            this.lblinfo.TabIndex = 12;
            this.lblinfo.Text = "PLEASE DO NOT LOST YOUR QUESTION ID";
            // 
            // frmAskQuestion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(785, 658);
            this.Controls.Add(this.loginAppLogo);
            this.Controls.Add(this.pnlBizeUlasin);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmAskQuestion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmAskQuestion";
            this.Load += new System.EventHandler(this.frmAskQuestion_Load);
            this.pnlBizeUlasin.ResumeLayout(false);
            this.pnlBizeUlasin.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.pnlRgstrName.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.loginAppLogo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlBizeUlasin;
        private System.Windows.Forms.Button btnSendMsg;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TextBox txtContentContact;
        private System.Windows.Forms.RichTextBox rtxtCUMessage;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtSoruBasligi;
        private System.Windows.Forms.Panel pnlRgstrName;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox txtQuestionId;
        private System.Windows.Forms.PictureBox loginAppLogo;
        private System.Windows.Forms.ComboBox cmbxWorkplaceList;
        private System.Windows.Forms.Label lblinfo;
    }
}