﻿
namespace onlineAppointmentSystem
{
    partial class frmSearchWorkplaces
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSearchWorkplaces));
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.txtSrcinfo = new System.Windows.Forms.Button();
            this.txtSrcForNameinfo = new System.Windows.Forms.Button();
            this.txtSrcForType = new System.Windows.Forms.TextBox();
            this.txtSrcForName = new System.Windows.Forms.TextBox();
            this.dgvWorkplaceShow = new System.Windows.Forms.DataGridView();
            this.loginAppLogo = new System.Windows.Forms.PictureBox();
            this.pnlBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvWorkplaceShow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginAppLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlBottom
            // 
            this.pnlBottom.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pnlBottom.Controls.Add(this.txtSrcinfo);
            this.pnlBottom.Controls.Add(this.txtSrcForNameinfo);
            this.pnlBottom.Controls.Add(this.txtSrcForType);
            this.pnlBottom.Controls.Add(this.txtSrcForName);
            this.pnlBottom.Controls.Add(this.dgvWorkplaceShow);
            this.pnlBottom.Location = new System.Drawing.Point(30, 154);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(723, 431);
            this.pnlBottom.TabIndex = 8;
            // 
            // txtSrcinfo
            // 
            this.txtSrcinfo.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtSrcinfo.BackColor = System.Drawing.SystemColors.HotTrack;
            this.txtSrcinfo.FlatAppearance.BorderSize = 0;
            this.txtSrcinfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.txtSrcinfo.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.txtSrcinfo.ForeColor = System.Drawing.SystemColors.Info;
            this.txtSrcinfo.Location = new System.Drawing.Point(440, 43);
            this.txtSrcinfo.Name = "txtSrcinfo";
            this.txtSrcinfo.Size = new System.Drawing.Size(153, 43);
            this.txtSrcinfo.TabIndex = 12;
            this.txtSrcinfo.Text = "Search For Type";
            this.txtSrcinfo.UseVisualStyleBackColor = false;
            // 
            // txtSrcForNameinfo
            // 
            this.txtSrcForNameinfo.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtSrcForNameinfo.BackColor = System.Drawing.SystemColors.HotTrack;
            this.txtSrcForNameinfo.FlatAppearance.BorderSize = 0;
            this.txtSrcForNameinfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.txtSrcForNameinfo.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.txtSrcForNameinfo.ForeColor = System.Drawing.SystemColors.Info;
            this.txtSrcForNameinfo.Location = new System.Drawing.Point(101, 40);
            this.txtSrcForNameinfo.Name = "txtSrcForNameinfo";
            this.txtSrcForNameinfo.Size = new System.Drawing.Size(153, 43);
            this.txtSrcForNameinfo.TabIndex = 11;
            this.txtSrcForNameinfo.Text = "Search For Name";
            this.txtSrcForNameinfo.UseVisualStyleBackColor = false;
            // 
            // txtSrcForType
            // 
            this.txtSrcForType.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.txtSrcForType.Location = new System.Drawing.Point(435, 100);
            this.txtSrcForType.Name = "txtSrcForType";
            this.txtSrcForType.Size = new System.Drawing.Size(163, 27);
            this.txtSrcForType.TabIndex = 2;
            this.txtSrcForType.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSrcForType_KeyPress);
            // 
            // txtSrcForName
            // 
            this.txtSrcForName.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.txtSrcForName.Location = new System.Drawing.Point(98, 100);
            this.txtSrcForName.Name = "txtSrcForName";
            this.txtSrcForName.Size = new System.Drawing.Size(163, 27);
            this.txtSrcForName.TabIndex = 1;
            this.txtSrcForName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSrcForName_KeyPress);
            // 
            // dgvWorkplaceShow
            // 
            this.dgvWorkplaceShow.AllowUserToOrderColumns = true;
            this.dgvWorkplaceShow.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvWorkplaceShow.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dgvWorkplaceShow.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvWorkplaceShow.Location = new System.Drawing.Point(14, 197);
            this.dgvWorkplaceShow.Name = "dgvWorkplaceShow";
            this.dgvWorkplaceShow.Size = new System.Drawing.Size(698, 214);
            this.dgvWorkplaceShow.TabIndex = 0;
            // 
            // loginAppLogo
            // 
            this.loginAppLogo.Image = ((System.Drawing.Image)(resources.GetObject("loginAppLogo.Image")));
            this.loginAppLogo.Location = new System.Drawing.Point(275, 12);
            this.loginAppLogo.Name = "loginAppLogo";
            this.loginAppLogo.Size = new System.Drawing.Size(189, 123);
            this.loginAppLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.loginAppLogo.TabIndex = 9;
            this.loginAppLogo.TabStop = false;
            // 
            // frmSearchWorkplaces
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(778, 609);
            this.Controls.Add(this.loginAppLogo);
            this.Controls.Add(this.pnlBottom);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmSearchWorkplaces";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmSearchWorkplaces";
            this.Load += new System.EventHandler(this.frmSearchWorkplaces_Load);
            this.pnlBottom.ResumeLayout(false);
            this.pnlBottom.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvWorkplaceShow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginAppLogo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.DataGridView dgvWorkplaceShow;
        private System.Windows.Forms.TextBox txtSrcForType;
        private System.Windows.Forms.TextBox txtSrcForName;
        private System.Windows.Forms.Button txtSrcinfo;
        private System.Windows.Forms.Button txtSrcForNameinfo;
        private System.Windows.Forms.PictureBox loginAppLogo;
    }
}