﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace onlineAppointmentSystem
{
    public partial class frmAskQuestion : Form
    {
        public frmAskQuestion()
        {
            InitializeComponent();
        }

        private void btnSendMsg_Click(object sender, EventArgs e)
        {           
            if (cmbxWorkplaceList.SelectedIndex < 0)
            {
                MessageBox.Show("PLEASE SELECT A WORKPLACE");
            }
            else
            {
                try
                {
                    QuestionAnswer questionAnswer = new QuestionAnswer()
                    {
                        QAHeadline = txtSoruBasligi.Text,
                        QAContent = rtxtCUMessage.Text,
                        QAtoWhom = cmbxWorkplaceList.Text,
                        Questionid = Convert.ToInt32(txtQuestionId.Text)
                    };
                    txtQuestionId.Text = questionAnswer.Questionid.ToString();
                    DBEntityQuestionAnswer dBEntityQuestionAnswer = new DBEntityQuestionAnswer();
                    dBEntityQuestionAnswer.QAnsverAdd(questionAnswer);
                    MessageBox.Show("YOUR MESSAGE SUCCESFULLY SENT");
                }
                catch (Exception ex)
                {

                    throw ex;
                }
            }
        }

        private void frmAskQuestion_Load(object sender, EventArgs e)
        {
            QuestionAnswer questionAnswer = new QuestionAnswer();
            Random random = new Random();
            questionAnswer.Questionid = random.Next(1,10000);
            txtQuestionId.Text = questionAnswer.Questionid.ToString();

            WorkplaceAuthority rgstrSystem = new WorkplaceAuthority()
            {
                ComboBoxForRegisterWorkplace = cmbxWorkplaceList
            };
            DBEntityWorkplaceAuthority wrklistSystem = new DBEntityWorkplaceAuthority();
            wrklistSystem.ListWorkplaces(rgstrSystem);
        }
    }
}
