﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace onlineAppointmentSystem
{
    public class Workplace 
    {
        public string WorkplaceName { get; set; }
        public string WorkplaceAdress { get; set; }
        public string WorkplaceCommunication { get; set; }
        public string WorkplaceType { get; set; }
        public int Workplaceid { get; set; }
    }
}
