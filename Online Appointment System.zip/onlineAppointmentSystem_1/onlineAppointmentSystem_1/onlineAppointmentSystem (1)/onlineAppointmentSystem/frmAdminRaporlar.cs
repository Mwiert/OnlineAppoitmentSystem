﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace onlineAppointmentSystem
{
    public partial class frmAdminRaporlar : Form
    {
        public frmAdminRaporlar()
        {
            InitializeComponent();
        }
        private void AuthorAccept()
        {
            string onay = "APPROVED";
            DBEntityWorkplaceAuthority AutListApp = new DBEntityWorkplaceAuthority();
            dgvAdminRapor.DataSource = AutListApp.AuthorNonVerify(onay);
            dgvAdminRapor.Refresh();
        }
        public void AuthorDenied()
        {
            string onay = "DENIED";
            DBEntityWorkplaceAuthority AutListDenied = new DBEntityWorkplaceAuthority();
            dgvAdminRapor.DataSource = AutListDenied.AuthorNonVerify(onay);
            dgvAdminRapor.Refresh();
        }
        public void WaitingForResponse()
        {
            string onay = "WAITING";
            DBEntityWorkplaceAuthority AutListWaiting = new DBEntityWorkplaceAuthority();
            dgvAdminRapor.DataSource = AutListWaiting.AuthorNonVerify(onay);
            dgvAdminRapor.Refresh();
        }
        private void btnDeny_Click(object sender, EventArgs e)
        {
            AuthorAccept();
        }

        private void btnApprove_Click(object sender, EventArgs e)
        {
            AuthorDenied();
        }

        private void btnWait_Click(object sender, EventArgs e)
        {
            WaitingForResponse();
        }
    }
}
