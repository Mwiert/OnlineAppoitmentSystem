﻿
namespace onlineAppointmentSystem
{
    partial class ChooseForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChooseForm));
            this.topPnlRegister = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAutRgstBack = new System.Windows.Forms.Button();
            this.minimizedClick = new System.Windows.Forms.PictureBox();
            this.closeBottonRegister = new System.Windows.Forms.PictureBox();
            this.loginAppLogo = new System.Windows.Forms.PictureBox();
            this.AuthorRgstr = new System.Windows.Forms.Button();
            this.UserRgstr = new System.Windows.Forms.Button();
            this.topPnlRegister.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.minimizedClick)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.closeBottonRegister)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginAppLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // topPnlRegister
            // 
            this.topPnlRegister.BackColor = System.Drawing.SystemColors.HotTrack;
            this.topPnlRegister.Controls.Add(this.label1);
            this.topPnlRegister.Controls.Add(this.btnAutRgstBack);
            this.topPnlRegister.Controls.Add(this.minimizedClick);
            this.topPnlRegister.Controls.Add(this.closeBottonRegister);
            this.topPnlRegister.Location = new System.Drawing.Point(0, -1);
            this.topPnlRegister.Name = "topPnlRegister";
            this.topPnlRegister.Size = new System.Drawing.Size(420, 43);
            this.topPnlRegister.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(-1, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(19, 13);
            this.label1.TabIndex = 25;
            this.label1.Text = "<<";
            // 
            // btnAutRgstBack
            // 
            this.btnAutRgstBack.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnAutRgstBack.BackColor = System.Drawing.SystemColors.MenuText;
            this.btnAutRgstBack.FlatAppearance.BorderSize = 0;
            this.btnAutRgstBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAutRgstBack.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnAutRgstBack.ForeColor = System.Drawing.SystemColors.Info;
            this.btnAutRgstBack.Location = new System.Drawing.Point(19, 8);
            this.btnAutRgstBack.Name = "btnAutRgstBack";
            this.btnAutRgstBack.Size = new System.Drawing.Size(63, 30);
            this.btnAutRgstBack.TabIndex = 26;
            this.btnAutRgstBack.Text = "BACK";
            this.btnAutRgstBack.UseVisualStyleBackColor = false;
            this.btnAutRgstBack.Click += new System.EventHandler(this.btnAutRgstBack_Click);
            // 
            // minimizedClick
            // 
            this.minimizedClick.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.minimizedClick.Image = ((System.Drawing.Image)(resources.GetObject("minimizedClick.Image")));
            this.minimizedClick.Location = new System.Drawing.Point(340, 3);
            this.minimizedClick.Name = "minimizedClick";
            this.minimizedClick.Size = new System.Drawing.Size(39, 36);
            this.minimizedClick.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.minimizedClick.TabIndex = 24;
            this.minimizedClick.TabStop = false;
            this.minimizedClick.Click += new System.EventHandler(this.minimizedClick_Click);
            // 
            // closeBottonRegister
            // 
            this.closeBottonRegister.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.closeBottonRegister.Image = ((System.Drawing.Image)(resources.GetObject("closeBottonRegister.Image")));
            this.closeBottonRegister.Location = new System.Drawing.Point(379, 3);
            this.closeBottonRegister.Name = "closeBottonRegister";
            this.closeBottonRegister.Size = new System.Drawing.Size(39, 36);
            this.closeBottonRegister.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.closeBottonRegister.TabIndex = 0;
            this.closeBottonRegister.TabStop = false;
            this.closeBottonRegister.Click += new System.EventHandler(this.closeBottonRegister_Click);
            // 
            // loginAppLogo
            // 
            this.loginAppLogo.Image = ((System.Drawing.Image)(resources.GetObject("loginAppLogo.Image")));
            this.loginAppLogo.Location = new System.Drawing.Point(110, 62);
            this.loginAppLogo.Name = "loginAppLogo";
            this.loginAppLogo.Size = new System.Drawing.Size(189, 153);
            this.loginAppLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.loginAppLogo.TabIndex = 5;
            this.loginAppLogo.TabStop = false;
            // 
            // AuthorRgstr
            // 
            this.AuthorRgstr.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.AuthorRgstr.BackColor = System.Drawing.SystemColors.HotTrack;
            this.AuthorRgstr.FlatAppearance.BorderSize = 0;
            this.AuthorRgstr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AuthorRgstr.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.AuthorRgstr.ForeColor = System.Drawing.SystemColors.Info;
            this.AuthorRgstr.Location = new System.Drawing.Point(12, 247);
            this.AuthorRgstr.Name = "AuthorRgstr";
            this.AuthorRgstr.Size = new System.Drawing.Size(187, 51);
            this.AuthorRgstr.TabIndex = 9;
            this.AuthorRgstr.Text = "AUTHOR REGISTER";
            this.AuthorRgstr.UseVisualStyleBackColor = false;
            this.AuthorRgstr.Click += new System.EventHandler(this.AuthorRgstr_Click);
            // 
            // UserRgstr
            // 
            this.UserRgstr.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.UserRgstr.BackColor = System.Drawing.SystemColors.HotTrack;
            this.UserRgstr.FlatAppearance.BorderSize = 0;
            this.UserRgstr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.UserRgstr.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.UserRgstr.ForeColor = System.Drawing.SystemColors.Info;
            this.UserRgstr.Location = new System.Drawing.Point(220, 247);
            this.UserRgstr.Name = "UserRgstr";
            this.UserRgstr.Size = new System.Drawing.Size(187, 51);
            this.UserRgstr.TabIndex = 10;
            this.UserRgstr.Text = "USER REGISTER";
            this.UserRgstr.UseVisualStyleBackColor = false;
            this.UserRgstr.Click += new System.EventHandler(this.UserRgstr_Click);
            // 
            // ChooseForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(419, 345);
            this.Controls.Add(this.UserRgstr);
            this.Controls.Add(this.AuthorRgstr);
            this.Controls.Add(this.loginAppLogo);
            this.Controls.Add(this.topPnlRegister);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ChooseForm";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ChooseForm";
            this.topPnlRegister.ResumeLayout(false);
            this.topPnlRegister.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.minimizedClick)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.closeBottonRegister)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginAppLogo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel topPnlRegister;
        private System.Windows.Forms.PictureBox minimizedClick;
        private System.Windows.Forms.PictureBox closeBottonRegister;
        private System.Windows.Forms.PictureBox loginAppLogo;
        private System.Windows.Forms.Button AuthorRgstr;
        private System.Windows.Forms.Button UserRgstr;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAutRgstBack;
    }
}