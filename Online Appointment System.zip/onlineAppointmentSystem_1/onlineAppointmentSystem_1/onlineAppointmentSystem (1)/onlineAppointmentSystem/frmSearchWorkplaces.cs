﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace onlineAppointmentSystem
{
    public partial class frmSearchWorkplaces : Form
    {
        public frmSearchWorkplaces()
        {
            InitializeComponent();
        }
        private void WorkplaceList()
        {
            DBEntityWorkplace dBEntityWorkplaceList = new DBEntityWorkplace();
            dgvWorkplaceShow.DataSource = dBEntityWorkplaceList.WorkplaceList();
            dgvWorkplaceShow.Refresh();
        }
        private void txtSrcForName_KeyPress(object sender, KeyPressEventArgs e)
        {
            DBEntityWorkplace dBEntityWorkplace = new DBEntityWorkplace();
            dgvWorkplaceShow.DataSource = dBEntityWorkplace.WorkplaceSearch(txtSrcForName.Text);
        }
        private void frmSearchWorkplaces_Load(object sender, EventArgs e)
        {
            WorkplaceList();
        }
        private void txtSrcForType_KeyPress(object sender, KeyPressEventArgs e)
        {
            DBEntityWorkplace dBEntityWorkplace = new DBEntityWorkplace();
            dgvWorkplaceShow.DataSource = dBEntityWorkplace.WorkplaceTypeSearch(txtSrcForType.Text);
        }
        private void closeBottonRegister_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void minimizedClick_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
