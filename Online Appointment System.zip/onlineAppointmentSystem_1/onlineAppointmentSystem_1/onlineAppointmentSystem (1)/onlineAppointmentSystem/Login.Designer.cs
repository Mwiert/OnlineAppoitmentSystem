﻿namespace onlineAppointmentSystem
{
    partial class Opening
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Opening));
            this.loginAppLogo = new System.Windows.Forms.PictureBox();
            this.topPnl = new System.Windows.Forms.Panel();
            this.minimizeClickMain = new System.Windows.Forms.PictureBox();
            this.closeBotton = new System.Windows.Forms.PictureBox();
            this.loginType = new System.Windows.Forms.ComboBox();
            this.userPic = new System.Windows.Forms.PictureBox();
            this.userDownPanel = new System.Windows.Forms.Panel();
            this.passwordDownPanel = new System.Windows.Forms.Panel();
            this.passwordPic = new System.Windows.Forms.PictureBox();
            this.loginUserTxtBx = new System.Windows.Forms.TextBox();
            this.loginPasswordTxtBx = new System.Windows.Forms.TextBox();
            this.passwordWiew = new System.Windows.Forms.CheckBox();
            this.loginBtn = new System.Windows.Forms.Button();
            this.orLbl = new System.Windows.Forms.Label();
            this.btnOpenRegister = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.loginAppLogo)).BeginInit();
            this.topPnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.minimizeClickMain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.closeBotton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordPic)).BeginInit();
            this.SuspendLayout();
            // 
            // loginAppLogo
            // 
            this.loginAppLogo.Image = ((System.Drawing.Image)(resources.GetObject("loginAppLogo.Image")));
            this.loginAppLogo.Location = new System.Drawing.Point(86, 71);
            this.loginAppLogo.Name = "loginAppLogo";
            this.loginAppLogo.Size = new System.Drawing.Size(189, 153);
            this.loginAppLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.loginAppLogo.TabIndex = 1;
            this.loginAppLogo.TabStop = false;
            // 
            // topPnl
            // 
            this.topPnl.BackColor = System.Drawing.SystemColors.HotTrack;
            this.topPnl.Controls.Add(this.minimizeClickMain);
            this.topPnl.Controls.Add(this.closeBotton);
            this.topPnl.Dock = System.Windows.Forms.DockStyle.Top;
            this.topPnl.Location = new System.Drawing.Point(0, 0);
            this.topPnl.Name = "topPnl";
            this.topPnl.Size = new System.Drawing.Size(388, 42);
            this.topPnl.TabIndex = 2;
            this.topPnl.MouseDown += new System.Windows.Forms.MouseEventHandler(this.topPnl_MouseDown);
            this.topPnl.MouseMove += new System.Windows.Forms.MouseEventHandler(this.topPnl_MouseMove);
            this.topPnl.MouseUp += new System.Windows.Forms.MouseEventHandler(this.topPnl_MouseUp);
            // 
            // minimizeClickMain
            // 
            this.minimizeClickMain.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.minimizeClickMain.Image = ((System.Drawing.Image)(resources.GetObject("minimizeClickMain.Image")));
            this.minimizeClickMain.Location = new System.Drawing.Point(318, 3);
            this.minimizeClickMain.Name = "minimizeClickMain";
            this.minimizeClickMain.Size = new System.Drawing.Size(32, 36);
            this.minimizeClickMain.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.minimizeClickMain.TabIndex = 17;
            this.minimizeClickMain.TabStop = false;
            this.minimizeClickMain.Click += new System.EventHandler(this.minimizeClickMain_Click);
            // 
            // closeBotton
            // 
            this.closeBotton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.closeBotton.Image = ((System.Drawing.Image)(resources.GetObject("closeBotton.Image")));
            this.closeBotton.Location = new System.Drawing.Point(351, 4);
            this.closeBotton.Name = "closeBotton";
            this.closeBotton.Size = new System.Drawing.Size(32, 36);
            this.closeBotton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.closeBotton.TabIndex = 0;
            this.closeBotton.TabStop = false;
            this.closeBotton.Click += new System.EventHandler(this.closeBotton_Click);
            // 
            // loginType
            // 
            this.loginType.BackColor = System.Drawing.SystemColors.Window;
            this.loginType.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.loginType.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.loginType.FormattingEnabled = true;
            this.loginType.Items.AddRange(new object[] {
            "Admin",
            "Workplace Authority",
            "Normal Users"});
            this.loginType.Location = new System.Drawing.Point(43, 262);
            this.loginType.Name = "loginType";
            this.loginType.Size = new System.Drawing.Size(277, 28);
            this.loginType.TabIndex = 1;
            this.loginType.Text = "--Select--";
            // 
            // userPic
            // 
            this.userPic.Image = ((System.Drawing.Image)(resources.GetObject("userPic.Image")));
            this.userPic.Location = new System.Drawing.Point(44, 329);
            this.userPic.Name = "userPic";
            this.userPic.Size = new System.Drawing.Size(38, 36);
            this.userPic.TabIndex = 4;
            this.userPic.TabStop = false;
            // 
            // userDownPanel
            // 
            this.userDownPanel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.userDownPanel.Location = new System.Drawing.Point(44, 372);
            this.userDownPanel.Name = "userDownPanel";
            this.userDownPanel.Size = new System.Drawing.Size(277, 5);
            this.userDownPanel.TabIndex = 5;
            // 
            // passwordDownPanel
            // 
            this.passwordDownPanel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.passwordDownPanel.Location = new System.Drawing.Point(44, 439);
            this.passwordDownPanel.Name = "passwordDownPanel";
            this.passwordDownPanel.Size = new System.Drawing.Size(277, 5);
            this.passwordDownPanel.TabIndex = 7;
            // 
            // passwordPic
            // 
            this.passwordPic.Image = ((System.Drawing.Image)(resources.GetObject("passwordPic.Image")));
            this.passwordPic.Location = new System.Drawing.Point(43, 396);
            this.passwordPic.Name = "passwordPic";
            this.passwordPic.Size = new System.Drawing.Size(38, 36);
            this.passwordPic.TabIndex = 6;
            this.passwordPic.TabStop = false;
            // 
            // loginUserTxtBx
            // 
            this.loginUserTxtBx.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.loginUserTxtBx.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.loginUserTxtBx.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.loginUserTxtBx.Location = new System.Drawing.Point(87, 340);
            this.loginUserTxtBx.Name = "loginUserTxtBx";
            this.loginUserTxtBx.Size = new System.Drawing.Size(233, 26);
            this.loginUserTxtBx.TabIndex = 2;
            this.loginUserTxtBx.Text = "Username";
            this.loginUserTxtBx.Click += new System.EventHandler(this.loginUserTxtBx_Click);
            // 
            // loginPasswordTxtBx
            // 
            this.loginPasswordTxtBx.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.loginPasswordTxtBx.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.loginPasswordTxtBx.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.loginPasswordTxtBx.Location = new System.Drawing.Point(87, 407);
            this.loginPasswordTxtBx.Name = "loginPasswordTxtBx";
            this.loginPasswordTxtBx.PasswordChar = '*';
            this.loginPasswordTxtBx.Size = new System.Drawing.Size(207, 26);
            this.loginPasswordTxtBx.TabIndex = 3;
            this.loginPasswordTxtBx.Text = "Password";
            this.loginPasswordTxtBx.Click += new System.EventHandler(this.loginPasswordTxtBx_Click);
            // 
            // passwordWiew
            // 
            this.passwordWiew.AutoSize = true;
            this.passwordWiew.BackColor = System.Drawing.SystemColors.Info;
            this.passwordWiew.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.passwordWiew.Image = ((System.Drawing.Image)(resources.GetObject("passwordWiew.Image")));
            this.passwordWiew.Location = new System.Drawing.Point(273, 401);
            this.passwordWiew.Name = "passwordWiew";
            this.passwordWiew.Size = new System.Drawing.Size(47, 32);
            this.passwordWiew.TabIndex = 4;
            this.passwordWiew.UseVisualStyleBackColor = false;
            this.passwordWiew.CheckedChanged += new System.EventHandler(this.passwordWiew_CheckedChanged);
            // 
            // loginBtn
            // 
            this.loginBtn.BackColor = System.Drawing.SystemColors.HotTrack;
            this.loginBtn.FlatAppearance.BorderSize = 0;
            this.loginBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loginBtn.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.loginBtn.ForeColor = System.Drawing.SystemColors.Info;
            this.loginBtn.Location = new System.Drawing.Point(110, 484);
            this.loginBtn.Name = "loginBtn";
            this.loginBtn.Size = new System.Drawing.Size(150, 33);
            this.loginBtn.TabIndex = 5;
            this.loginBtn.Text = "LOG IN";
            this.loginBtn.UseVisualStyleBackColor = false;
            this.loginBtn.Click += new System.EventHandler(this.loginBtn_Click);
            // 
            // orLbl
            // 
            this.orLbl.AutoSize = true;
            this.orLbl.BackColor = System.Drawing.SystemColors.Window;
            this.orLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.orLbl.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.orLbl.Location = new System.Drawing.Point(173, 531);
            this.orLbl.Name = "orLbl";
            this.orLbl.Size = new System.Drawing.Size(23, 20);
            this.orLbl.TabIndex = 16;
            this.orLbl.Text = "or";
            // 
            // btnOpenRegister
            // 
            this.btnOpenRegister.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnOpenRegister.FlatAppearance.BorderSize = 0;
            this.btnOpenRegister.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOpenRegister.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnOpenRegister.ForeColor = System.Drawing.SystemColors.Info;
            this.btnOpenRegister.Location = new System.Drawing.Point(110, 562);
            this.btnOpenRegister.Name = "btnOpenRegister";
            this.btnOpenRegister.Size = new System.Drawing.Size(150, 33);
            this.btnOpenRegister.TabIndex = 6;
            this.btnOpenRegister.Text = "REGISTER";
            this.btnOpenRegister.UseVisualStyleBackColor = false;
            this.btnOpenRegister.Click += new System.EventHandler(this.btnOpenRegister_Click);
            // 
            // Opening
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(388, 644);
            this.Controls.Add(this.btnOpenRegister);
            this.Controls.Add(this.orLbl);
            this.Controls.Add(this.loginBtn);
            this.Controls.Add(this.passwordWiew);
            this.Controls.Add(this.loginPasswordTxtBx);
            this.Controls.Add(this.loginUserTxtBx);
            this.Controls.Add(this.passwordDownPanel);
            this.Controls.Add(this.passwordPic);
            this.Controls.Add(this.userDownPanel);
            this.Controls.Add(this.userPic);
            this.Controls.Add(this.loginType);
            this.Controls.Add(this.topPnl);
            this.Controls.Add(this.loginAppLogo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Opening";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.loginAppLogo)).EndInit();
            this.topPnl.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.minimizeClickMain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.closeBotton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordPic)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox loginAppLogo;
        private System.Windows.Forms.Panel topPnl;
        private System.Windows.Forms.PictureBox closeBotton;
        private System.Windows.Forms.ComboBox loginType;
        private System.Windows.Forms.PictureBox userPic;
        private System.Windows.Forms.Panel userDownPanel;
        private System.Windows.Forms.Panel passwordDownPanel;
        private System.Windows.Forms.PictureBox passwordPic;
        private System.Windows.Forms.TextBox loginUserTxtBx;
        private System.Windows.Forms.TextBox loginPasswordTxtBx;
        private System.Windows.Forms.CheckBox passwordWiew;
        private System.Windows.Forms.Button loginBtn;
        private System.Windows.Forms.Label orLbl;
        private System.Windows.Forms.Button btnOpenRegister;
        private System.Windows.Forms.PictureBox minimizeClickMain;
    }
}

