﻿
namespace onlineAppointmentSystem
{
    partial class frmCheckAnsweredQuestions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtQsnid = new System.Windows.Forms.TextBox();
            this.dgvSearchQsn = new System.Windows.Forms.DataGridView();
            this.btnSearchQsnid = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSearchQsn)).BeginInit();
            this.SuspendLayout();
            // 
            // txtQsnid
            // 
            this.txtQsnid.Font = new System.Drawing.Font("Century Gothic", 14.25F);
            this.txtQsnid.Location = new System.Drawing.Point(255, 39);
            this.txtQsnid.Name = "txtQsnid";
            this.txtQsnid.Size = new System.Drawing.Size(100, 31);
            this.txtQsnid.TabIndex = 0;
            // 
            // dgvSearchQsn
            // 
            this.dgvSearchQsn.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvSearchQsn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSearchQsn.Location = new System.Drawing.Point(23, 107);
            this.dgvSearchQsn.Name = "dgvSearchQsn";
            this.dgvSearchQsn.Size = new System.Drawing.Size(693, 254);
            this.dgvSearchQsn.TabIndex = 1;
            // 
            // btnSearchQsnid
            // 
            this.btnSearchQsnid.BackColor = System.Drawing.Color.LightCyan;
            this.btnSearchQsnid.Location = new System.Drawing.Point(384, 29);
            this.btnSearchQsnid.Name = "btnSearchQsnid";
            this.btnSearchQsnid.Size = new System.Drawing.Size(135, 46);
            this.btnSearchQsnid.TabIndex = 2;
            this.btnSearchQsnid.Text = "Search By ID";
            this.btnSearchQsnid.UseVisualStyleBackColor = false;
            this.btnSearchQsnid.Click += new System.EventHandler(this.btnSearchQsnid_Click);
            // 
            // frmCheckAnsweredQuestions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(728, 373);
            this.Controls.Add(this.btnSearchQsnid);
            this.Controls.Add(this.dgvSearchQsn);
            this.Controls.Add(this.txtQsnid);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmCheckAnsweredQuestions";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmCheckAnsweredQuestions";
            ((System.ComponentModel.ISupportInitialize)(this.dgvSearchQsn)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtQsnid;
        private System.Windows.Forms.DataGridView dgvSearchQsn;
        private System.Windows.Forms.Button btnSearchQsnid;
    }
}