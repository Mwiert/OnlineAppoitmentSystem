﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace onlineAppointmentSystem
{
    public partial class frmControlAppointments : Form
    {
        public frmControlAppointments()
        {
            InitializeComponent();
        }
        private void AppList()
        {
            DBEntityAppoitmentSystem appoitmentSystem = new DBEntityAppoitmentSystem();
            dgvAllList.DataSource = appoitmentSystem.appoitmentSystemslist();
            dgvAllList.Refresh();
        }
        private void AddDayList()
        {
            DBEntityAppoitmentSystem appoitmentSystem = new DBEntityAppoitmentSystem();
            dgvDenyOrApprove.DataSource = appoitmentSystem.appoitmentSystemslist();
            dgvDenyOrApprove.Refresh();
        }
        private void ShowAvblTimes()
        {
            DBEntityAppoitmentSystem appoitmentSystem = new DBEntityAppoitmentSystem();
            string date = dtpdeneme.Value.ToString("yyyy-MM-dd");
            dgvDenyOrApprove.DataSource = appoitmentSystem.appoitmentSystemslist2(date);
            dgvDenyOrApprove.Refresh();
        }
        private void btnAppDateAdd_Click(object sender, EventArgs e)
        {
            ShowAvblTimes();
            if (dgvDenyOrApprove.Rows.Count==0)
            {
                AvailableTimesAppointment appoitmentSystem = new AvailableTimesAppointment
                {
                    AppointmentDatetime = dtpdeneme.Value.Date
                };
                DBEntityAppoitmentSystem dBEntityAppoitmentSystem = new DBEntityAppoitmentSystem();
                dBEntityAppoitmentSystem.ShowAppointment(appoitmentSystem);
                ShowAvblTimes();
            }
            else
            {
                MessageBox.Show("YOU CANNOT ADD AN EXISTING DAY");
                ShowAvblTimes();
            }
            AppList();
        }

        private void btnDeny_Click(object sender, EventArgs e)
        {
            DBEntityAppoitmentSystem dBEntityAppoitmentSystem = new DBEntityAppoitmentSystem();
            string date = dtpSelectWhichday.Value.ToString("yyyy-MM-dd");
            if (txtGetTime.Text == "time16_17")
            {  
                try
                {
                    AppSystemApproveorDeny appSystemApproveorDeny = new AppSystemApproveorDeny()
                    {
                        time16_17 = "REQUEST DENIED",
                    };
                    dBEntityAppoitmentSystem.UpdateDeny16_17(appSystemApproveorDeny, date);
                    MessageBox.Show("REQUEST SUCCESFULLY DENIED");
                }
                catch (Exception ex)
                {

                    throw ex;
                }
            }
            else if (txtGetTime.Text == "time8_9")
            {
                try
                {
                    AppSystemApproveorDeny appSystemApproveorDeny = new AppSystemApproveorDeny()
                    {
                        time8_9 ="REQUEST DENIED",
                    };
                    dBEntityAppoitmentSystem.UpdateDeny8_9(appSystemApproveorDeny, date);
                    MessageBox.Show("REQUEST SUCCESFULLY DENIED");
                }
                catch (Exception ex)
                {

                    throw ex ;
                }
            }
            else if (txtGetTime.Text == "time9_10") 
            {
                try
                {
                    AppSystemApproveorDeny appSystemApproveorDeny = new AppSystemApproveorDeny()
                    {
                        time9_10 = "REQUEST DENIED",
                    };
                    dBEntityAppoitmentSystem.UpdateDeny9_10(appSystemApproveorDeny, date);
                    MessageBox.Show("REQUEST SUCCESFULLY DENIED");
                }
                catch (Exception ex)
                {

                    throw ex;
                }
            }
            else if (txtGetTime.Text == "time10_11")
            {
                try
                {
                    AppSystemApproveorDeny appSystemApproveorDeny = new AppSystemApproveorDeny()
                    {
                        time10_11 = "REQUEST DENIED",
                    };
                    dBEntityAppoitmentSystem.UpdateDeny10_11(appSystemApproveorDeny, date);
                    MessageBox.Show("REQUEST SUCCESFULLY DENIED");
                }
                catch (Exception ex)
                {

                    throw ex;
                }
            }
            else if (txtGetTime.Text == "time11_12")
            {
                try
                {
                    AppSystemApproveorDeny appSystemApproveorDeny = new AppSystemApproveorDeny()
                    {
                        time11_12 = "REQUEST DENIED",
                    };
                    dBEntityAppoitmentSystem.UpdateDeny11_12(appSystemApproveorDeny, date);
                    MessageBox.Show("REQUEST SUCCESFULLY DENIED");
                }
                catch (Exception ex)
                {

                    throw ex;
                }
            }
            else if (txtGetTime.Text == "time13_14")
            {
                try
                {
                    AppSystemApproveorDeny appSystemApproveorDeny = new AppSystemApproveorDeny()
                    {
                        time13_14 = "REQUEST DENIED",
                    };
                    dBEntityAppoitmentSystem.UpdateDeny13_14(appSystemApproveorDeny, date);
                    MessageBox.Show("REQUEST SUCCESFULLY DENIED");
                }
                catch (Exception ex)
                {

                    throw ex;
                }
            }
            else if (txtGetTime.Text == "time14_15")
            {
                try
                {
                    AppSystemApproveorDeny appSystemApproveorDeny = new AppSystemApproveorDeny()
                    {
                        time14_15 = "REQUEST DENIED",
                    };
                    dBEntityAppoitmentSystem.UpdateDeny14_15(appSystemApproveorDeny, date);
                    MessageBox.Show("REQUEST SUCCESFULLY DENIED");
                }
                catch (Exception ex)
                {

                    throw ex;
                }
            }
            else if (txtGetTime.Text == "time15_16")
            {
                try
                {
                    AppSystemApproveorDeny appSystemApproveorDeny = new AppSystemApproveorDeny()
                    {
                        time15_16 = "REQUEST DENIED",
                    };
                    dBEntityAppoitmentSystem.UpdateDeny15_16(appSystemApproveorDeny, date);
                    MessageBox.Show("REQUEST SUCCESFULLY DENIED");
                }
                catch (Exception ex)
                {

                    throw ex;
                }
            }
            else
            {
                MessageBox.Show("ERROR");
            }
            RqstList();
        }

        private void btnListAll_Click(object sender, EventArgs e)
        {
            AppList();
        }
        private void RqstList()
        {
            string rqst = "REQUESTED";
            DBEntityAppoitmentSystem dBEntityAppoitmentSystem = new DBEntityAppoitmentSystem();
            dBEntityAppoitmentSystem.RequestedList(dgvApproveOrDeny, rqst);
            dgvApproveOrDeny.Refresh();
        }

        private void frmControlAppointments_Load(object sender, EventArgs e)
        {
            RqstList();
            AddDayList();
        }

        private void dtpSelectWhichday_CloseUp(object sender, EventArgs e)
        {
            string date = dtpSelectWhichday.Value.ToString("yyyy-MM-dd");
            txtSeeDate.Text = date;
        }

        private void btn8_9_Click(object sender, EventArgs e)
        {
            txtGetTime.Text = "time8_9";
        }

        private void btn9_10_Click(object sender, EventArgs e)
        {
            txtGetTime.Text = "time9_10";
        }

        private void btn10_11_Click(object sender, EventArgs e)
        {
            txtGetTime.Text = "time10_11";
        }

        private void btn11_12_Click(object sender, EventArgs e)
        {
            txtGetTime.Text = "time11_12";
        }

        private void btn13_14_Click(object sender, EventArgs e)
        {
            txtGetTime.Text = "time13_14";
        }

        private void btn14_15_Click(object sender, EventArgs e)
        {
            txtGetTime.Text = "time14_15";
        }

        private void btn15_16_Click(object sender, EventArgs e)
        {
            txtGetTime.Text = "time15_16";
        }

        private void btn16_17_Click(object sender, EventArgs e)
        {
            txtGetTime.Text = "time16_17";
        }

        private void btnApprove_Click(object sender, EventArgs e)
        {
            DBEntityAppoitmentSystem dBEntityAppoitmentSystem = new DBEntityAppoitmentSystem();
            string date = dtpSelectWhichday.Value.ToString("yyyy-MM-dd");
            if (txtGetTime.Text == "time16_17")
            {
                try
                {
                    AppSystemApproveorDeny appSystemApproveorDeny = new AppSystemApproveorDeny()
                    {
                        time16_17 = "REQUEST ACCEPTED",
                    };
                    dBEntityAppoitmentSystem.UpdateApprove16_17(appSystemApproveorDeny, date);
                    MessageBox.Show("REQUEST SUCCESFULLY ACCEPTED");
                }
                catch (Exception ex)
                {

                    throw ex;
                }
            }
            else if (txtGetTime.Text == "time8_9")
            {
                try
                {
                    AppSystemApproveorDeny appSystemApproveorDeny = new AppSystemApproveorDeny()
                    {
                        time8_9 = "REQUEST ACCEPTED",
                    };
                    dBEntityAppoitmentSystem.UpdateApprove8_9(appSystemApproveorDeny, date);
                    MessageBox.Show("REQUEST SUCCESFULLY ACCEPTED");
                }
                catch (Exception ex)
                {

                    throw ex;
                }
            }
            else if (txtGetTime.Text == "time9_10")
            {
                try
                {
                    AppSystemApproveorDeny appSystemApproveorDeny = new AppSystemApproveorDeny()
                    {
                        time9_10 = "REQUEST ACCEPTED",
                    };
                    dBEntityAppoitmentSystem.UpdateApprove9_10(appSystemApproveorDeny, date);
                    MessageBox.Show("REQUEST SUCCESFULLY ACCEPTED");
                }
                catch (Exception ex)
                {

                    throw ex;
                }
            }
            else if (txtGetTime.Text == "time10_11")
            {
                try
                {
                    AppSystemApproveorDeny appSystemApproveorDeny = new AppSystemApproveorDeny()
                    {
                        time10_11 = "REQUEST ACCEPTED",
                    };
                    dBEntityAppoitmentSystem.UpdateApprove10_11(appSystemApproveorDeny, date);
                    MessageBox.Show("REQUEST SUCCESFULLY ACCEPTED");
                }
                catch (Exception ex)
                {

                    throw ex;
                }
            }
            else if (txtGetTime.Text == "time11_12")
            {
                try
                {
                    AppSystemApproveorDeny appSystemApproveorDeny = new AppSystemApproveorDeny()
                    {
                        time11_12 = "REQUEST ACCEPTED",
                    };
                    dBEntityAppoitmentSystem.UpdateApprove11_12(appSystemApproveorDeny, date);
                    MessageBox.Show("REQUEST SUCCESFULLY ACCEPTED");
                }
                catch (Exception ex)
                {

                    throw ex;
                }
            }
            else if (txtGetTime.Text == "time13_14")
            {
                try
                {
                    AppSystemApproveorDeny appSystemApproveorDeny = new AppSystemApproveorDeny()
                    {
                        time13_14 = "REQUEST ACCEPTED",
                    };
                    dBEntityAppoitmentSystem.UpdateApprove13_14(appSystemApproveorDeny, date);
                    MessageBox.Show("REQUEST SUCCESFULLY ACCEPTED");
                }
                catch (Exception ex)
                {

                    throw ex;
                }
            }
            else if (txtGetTime.Text == "time14_15")
            {
                try
                {
                    AppSystemApproveorDeny appSystemApproveorDeny = new AppSystemApproveorDeny()
                    {
                        time14_15 = "REQUEST ACCEPTED",
                    };
                    dBEntityAppoitmentSystem.UpdateApprove14_15(appSystemApproveorDeny, date);
                    MessageBox.Show("REQUEST SUCCESFULLY ACCEPTED");
                }
                catch (Exception ex)
                {

                    throw ex;
                }
            }
            else if (txtGetTime.Text == "time15_16")
            {
                try
                {
                    AppSystemApproveorDeny appSystemApproveorDeny = new AppSystemApproveorDeny()
                    {
                        time15_16 = "REQUEST ACCEPTED",
                    };
                    dBEntityAppoitmentSystem.UpdateApprove15_16(appSystemApproveorDeny, date);
                    MessageBox.Show("REQUEST SUCCESFULLY ACCEPTED");
                }
                catch (Exception ex)
                {

                    throw ex;
                }
            }
            else
            {
                MessageBox.Show("ERROR");
            }
            RqstList();
        }
    }
}
