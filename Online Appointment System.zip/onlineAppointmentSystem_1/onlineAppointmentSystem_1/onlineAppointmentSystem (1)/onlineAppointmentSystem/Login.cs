﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace onlineAppointmentSystem
{
    public partial class Opening : Form
    {
        readonly Admin Admin = new Admin(); 
        public Opening()
        {
            InitializeComponent();
        }

        bool take;
        int mouseX, mouseY;

        private void topPnl_MouseUp(object sender, MouseEventArgs e)
        {
            take = false;
            mouseX = 0;
            mouseY= 0;
        }

        private void topPnl_MouseDown(object sender, MouseEventArgs e)
        {
            take = true;
            mouseX = Cursor.Position.X - this.Left;
            mouseY = Cursor.Position.Y - this.Top;
        }

        private void topPnl_MouseMove(object sender, MouseEventArgs e)
        {
            if (take == true )
            {
                this.Left = Cursor.Position.X - mouseX;
                this.Top = Cursor.Position.Y - mouseY;
            }
        }  
        
        private void closeBotton_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void passwordWiew_CheckedChanged(object sender, EventArgs e)
        {
            {             
                if (passwordWiew.Checked)
                {                   
                    loginPasswordTxtBx.PasswordChar = '\0';
                }
             
                else
                {
                    loginPasswordTxtBx.PasswordChar = '*';
                }
            }
        }

        private void minimizeClickMain_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnOpenRegister_Click(object sender, EventArgs e)
        {
            ChooseForm chooseformpls = new ChooseForm();
            this.Hide();
            chooseformpls.Show();
        }

        private void loginUserTxtBx_Click(object sender, EventArgs e)
        {
            loginUserTxtBx.Clear();
        }

        private void loginPasswordTxtBx_Click(object sender, EventArgs e)
        {
            loginPasswordTxtBx.Clear();
        }

        private void WrongLogin()
        {
            MessageBox.Show("Invalid Username Or Password.");
            loginUserTxtBx.Clear();
            loginPasswordTxtBx.Clear();
            loginUserTxtBx.Focus();
        }
        HoldLoginInfo loginInfo = new HoldLoginInfo();
        private void loginBtn_Click(object sender, EventArgs e)
        {
            NormalUsers NormalUsers = new NormalUsers
            {
                ClientUsername = loginUserTxtBx.Text,
                ClientPassword = loginPasswordTxtBx.Text
            };
            loginInfo.HoldUsernameInfo = loginUserTxtBx.Text;
            WorkplaceAuthority workplaceAuthority = new WorkplaceAuthority
            {
                AuthorizedUsername = loginUserTxtBx.Text,
                AuthorizedPassword = loginPasswordTxtBx.Text
            };

            DBEntityNormalUsers DBEntityNormalUsers = new DBEntityNormalUsers();
            DBEntityWorkplaceAuthority DBEntityWorkplaceAuthority = new DBEntityWorkplaceAuthority();

            if (loginType.SelectedIndex == 0)
            {                              
                if (Admin.AdminUsername == loginUserTxtBx.Text || Admin.AdminPass == loginPasswordTxtBx.Text)
                {
                    this.Hide();
                    frmAdmin frmLoginAdmin = new frmAdmin();                       
                    frmLoginAdmin.Show();

                }
                else
                {
                    WrongLogin();
                }
                
            }

            else if (loginType.SelectedIndex == 1)
            {
                if (DBEntityWorkplaceAuthority.LoginCheck(workplaceAuthority))
                {

                    this.Hide();
                    frmWorkplaceAuthority frmWorkplaceAuthority = new frmWorkplaceAuthority();
                    frmWorkplaceAuthority.Show();                    
                }
                else
                {
                    WrongLogin();
                }

            }

            else if (loginType.SelectedIndex == 2)
            { 
                if (DBEntityNormalUsers.LoginCheck(NormalUsers))
                {
                    this.Hide();
                    frmNormalUser frmNormalUser = new frmNormalUser();
                    frmNormalUser.Show();                   
                }
                else
                {
                    WrongLogin();
                }
            }
        }
    }
}
