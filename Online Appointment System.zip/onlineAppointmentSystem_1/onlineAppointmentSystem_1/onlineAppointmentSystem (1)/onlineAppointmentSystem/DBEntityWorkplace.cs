﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace onlineAppointmentSystem
{
    public class DBEntityWorkplace:DBEntity
    {
        public void WorkPlaceAdd(Workplace wrkplace)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Insert Into tblWorkplace (WorkplaceName,WorkplaceAdress,WorkplaceCommunication,WorkplaceType)" +
                    "values (@WorkplaceName,@WorkplaceAdress,@WorkplaceCommunication,@WorkplaceType)",con);
                command.Parameters.AddWithValue("WorkplaceName",wrkplace.WorkplaceName);
                command.Parameters.AddWithValue("WorkplaceAdress",wrkplace.WorkplaceAdress);
                command.Parameters.AddWithValue("WorkplaceCommunication",wrkplace.WorkplaceCommunication);
                command.Parameters.AddWithValue("WorkplaceType",wrkplace.WorkplaceType);
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }   
        public void WorkPlaceDelete(Workplace wrkPlc)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Delete from tblWorkPlace where Workplaceid=@wkplcid ", con);
                command.Parameters.AddWithValue("@wkplcid", wrkPlc.Workplaceid);
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception)
            {

                throw;
            }
        }
        public List<Workplace> WorkplaceList()
        {
            List<Workplace> wplaces = new List<Workplace>();
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Select *From tblWorkPlace", con);
                con.Open();
                using (var reader = command.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            var dbWorkPlaces = new Workplace()
                            {
                                WorkplaceName = reader.GetString(0),
                                WorkplaceAdress = reader.GetString(1),
                                WorkplaceCommunication = reader.GetString(2),
                                WorkplaceType = reader.GetString(3),
                                Workplaceid = reader.GetInt32(4)
                            };
                            wplaces.Add(dbWorkPlaces);
                        }
                    }
                }
                return wplaces;
            }
            catch (Exception ex)
            {
                throw ex;
            } 
        }
        public void WorkPlaceUpdate(Workplace wrkPlcUp)
        {
            SqlConnection con = new SqlConnection(ConnStr);
            SqlCommand command = new SqlCommand("Update  tblWorkPlace SET WorkplaceName = @wpName, WorkplaceAdress = @wpAdress, WorkplaceCommunication = @wpComm, WorkplaceType = @wpType where Workplaceid=@wpidup", con);
            command.Parameters.AddWithValue("@wpname",wrkPlcUp.WorkplaceName);
            command.Parameters.AddWithValue("@wpAdress",wrkPlcUp.WorkplaceAdress);
            command.Parameters.AddWithValue("@wpComm", wrkPlcUp.WorkplaceCommunication);
            command.Parameters.AddWithValue("@wpType", wrkPlcUp.WorkplaceType);
            command.Parameters.AddWithValue("@wpidup", wrkPlcUp.Workplaceid);
            con.Open();
            command.ExecuteNonQuery();  
        }
        public DataTable WorkplaceSearch(string wrkPlSrcName)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Select * from tblWorkPlace where WorkplaceName LIKE '%'+@SearchKey+'%' ", con);
                command.Parameters.AddWithValue("@SearchKey",wrkPlSrcName);
                SqlDataAdapter adp = new SqlDataAdapter(command);
                DataTable srcTable = new DataTable();
                adp.Fill(srcTable);
                return srcTable;
            }
            catch {return null; }
        }
        public DataTable WorkplaceTypeSearch(string wrkPlSrcName)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Select * from tblWorkPlace where WorkplaceType LIKE '%'+@SearchKey+'%' ", con);
                command.Parameters.AddWithValue("@SearchKey", wrkPlSrcName);
                SqlDataAdapter adp = new SqlDataAdapter(command);
                DataTable srcTable = new DataTable();
                adp.Fill(srcTable);
                return srcTable;
            }
            catch { return null; }
        }
    }
}
