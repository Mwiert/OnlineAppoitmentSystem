﻿
namespace onlineAppointmentSystem
{
    partial class frmGetAppointment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGetAppointment));
            this.loginAppLogo = new System.Windows.Forms.PictureBox();
            this.panel18 = new System.Windows.Forms.Panel();
            this.btnShowAppointment = new System.Windows.Forms.Button();
            this.lblinfo = new System.Windows.Forms.Label();
            this.dgvGetinfos = new System.Windows.Forms.DataGridView();
            this.lblinfoapp = new System.Windows.Forms.Label();
            this.btn14_15 = new System.Windows.Forms.Button();
            this.btn10_11 = new System.Windows.Forms.Button();
            this.btn13_14 = new System.Windows.Forms.Button();
            this.btn16_17 = new System.Windows.Forms.Button();
            this.btn15_16 = new System.Windows.Forms.Button();
            this.btn8_9 = new System.Windows.Forms.Button();
            this.btn11_12 = new System.Windows.Forms.Button();
            this.btn9_10 = new System.Windows.Forms.Button();
            this.btnShowAvailabletimes = new System.Windows.Forms.Button();
            this.dgvlistdeneme = new System.Windows.Forms.DataGridView();
            this.infoSelectDate = new System.Windows.Forms.TextBox();
            this.dtpChsAppoitmentDate = new System.Windows.Forms.DateTimePicker();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.infoChooseWorkplace = new System.Windows.Forms.TextBox();
            this.cmbxWorkplaceSlc = new System.Windows.Forms.ComboBox();
            this.panel22 = new System.Windows.Forms.Panel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.panel24 = new System.Windows.Forms.Panel();
            this.txtbxAppointmentUsrname = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtAppointmenTime = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.loginAppLogo)).BeginInit();
            this.panel18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGetinfos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvlistdeneme)).BeginInit();
            this.panel19.SuspendLayout();
            this.panel22.SuspendLayout();
            this.SuspendLayout();
            // 
            // loginAppLogo
            // 
            this.loginAppLogo.Image = ((System.Drawing.Image)(resources.GetObject("loginAppLogo.Image")));
            this.loginAppLogo.Location = new System.Drawing.Point(292, 12);
            this.loginAppLogo.Name = "loginAppLogo";
            this.loginAppLogo.Size = new System.Drawing.Size(166, 118);
            this.loginAppLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.loginAppLogo.TabIndex = 7;
            this.loginAppLogo.TabStop = false;
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel18.Controls.Add(this.txtAppointmenTime);
            this.panel18.Controls.Add(this.btnShowAppointment);
            this.panel18.Controls.Add(this.lblinfo);
            this.panel18.Controls.Add(this.dgvGetinfos);
            this.panel18.Controls.Add(this.lblinfoapp);
            this.panel18.Controls.Add(this.btn14_15);
            this.panel18.Controls.Add(this.btn10_11);
            this.panel18.Controls.Add(this.btn13_14);
            this.panel18.Controls.Add(this.btn16_17);
            this.panel18.Controls.Add(this.btn15_16);
            this.panel18.Controls.Add(this.btn8_9);
            this.panel18.Controls.Add(this.btn11_12);
            this.panel18.Controls.Add(this.btn9_10);
            this.panel18.Controls.Add(this.btnShowAvailabletimes);
            this.panel18.Controls.Add(this.dgvlistdeneme);
            this.panel18.Controls.Add(this.infoSelectDate);
            this.panel18.Controls.Add(this.dtpChsAppoitmentDate);
            this.panel18.Controls.Add(this.panel19);
            this.panel18.Controls.Add(this.infoChooseWorkplace);
            this.panel18.Controls.Add(this.cmbxWorkplaceSlc);
            this.panel18.Controls.Add(this.panel22);
            this.panel18.Controls.Add(this.txtbxAppointmentUsrname);
            this.panel18.Location = new System.Drawing.Point(22, 136);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(724, 574);
            this.panel18.TabIndex = 12;
            // 
            // btnShowAppointment
            // 
            this.btnShowAppointment.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnShowAppointment.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnShowAppointment.FlatAppearance.BorderSize = 0;
            this.btnShowAppointment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnShowAppointment.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.btnShowAppointment.ForeColor = System.Drawing.SystemColors.Info;
            this.btnShowAppointment.Location = new System.Drawing.Point(241, 522);
            this.btnShowAppointment.Name = "btnShowAppointment";
            this.btnShowAppointment.Size = new System.Drawing.Size(255, 33);
            this.btnShowAppointment.TabIndex = 33;
            this.btnShowAppointment.Text = "CHECK YOUR APPOINTMENT";
            this.btnShowAppointment.UseVisualStyleBackColor = false;
            this.btnShowAppointment.Click += new System.EventHandler(this.btnShowAppointment_Click);
            // 
            // lblinfo
            // 
            this.lblinfo.AutoSize = true;
            this.lblinfo.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.lblinfo.ForeColor = System.Drawing.Color.Maroon;
            this.lblinfo.Location = new System.Drawing.Point(151, 422);
            this.lblinfo.Name = "lblinfo";
            this.lblinfo.Size = new System.Drawing.Size(465, 23);
            this.lblinfo.TabIndex = 32;
            this.lblinfo.Text = "CLICK THE BUTTON TO CHECK YOUR APPOINTMENT";
            // 
            // dgvGetinfos
            // 
            this.dgvGetinfos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvGetinfos.BackgroundColor = System.Drawing.Color.Azure;
            this.dgvGetinfos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGetinfos.Location = new System.Drawing.Point(77, 465);
            this.dgvGetinfos.Name = "dgvGetinfos";
            this.dgvGetinfos.Size = new System.Drawing.Size(572, 51);
            this.dgvGetinfos.TabIndex = 31;
            // 
            // lblinfoapp
            // 
            this.lblinfoapp.AutoSize = true;
            this.lblinfoapp.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.lblinfoapp.ForeColor = System.Drawing.Color.Maroon;
            this.lblinfoapp.Location = new System.Drawing.Point(73, 333);
            this.lblinfoapp.Name = "lblinfoapp";
            this.lblinfoapp.Size = new System.Drawing.Size(577, 23);
            this.lblinfoapp.TabIndex = 30;
            this.lblinfoapp.Text = "PLEASE SELECT THE TIME YOU WANT TO MAKE AN APPOINTMENT";
            // 
            // btn14_15
            // 
            this.btn14_15.BackColor = System.Drawing.Color.Cornsilk;
            this.btn14_15.Location = new System.Drawing.Point(458, 359);
            this.btn14_15.Name = "btn14_15";
            this.btn14_15.Size = new System.Drawing.Size(89, 35);
            this.btn14_15.TabIndex = 29;
            this.btn14_15.Text = "14_15";
            this.btn14_15.UseVisualStyleBackColor = false;
            this.btn14_15.Click += new System.EventHandler(this.btn14_15_Click);
            // 
            // btn10_11
            // 
            this.btn10_11.BackColor = System.Drawing.Color.Cornsilk;
            this.btn10_11.Location = new System.Drawing.Point(187, 359);
            this.btn10_11.Name = "btn10_11";
            this.btn10_11.Size = new System.Drawing.Size(89, 35);
            this.btn10_11.TabIndex = 28;
            this.btn10_11.Text = "10-11";
            this.btn10_11.UseVisualStyleBackColor = false;
            this.btn10_11.Click += new System.EventHandler(this.btn10_11_Click);
            // 
            // btn13_14
            // 
            this.btn13_14.BackColor = System.Drawing.Color.Cornsilk;
            this.btn13_14.Location = new System.Drawing.Point(368, 360);
            this.btn13_14.Name = "btn13_14";
            this.btn13_14.Size = new System.Drawing.Size(89, 35);
            this.btn13_14.TabIndex = 27;
            this.btn13_14.Text = "13_14";
            this.btn13_14.UseVisualStyleBackColor = false;
            this.btn13_14.Click += new System.EventHandler(this.btn13_14_Click);
            // 
            // btn16_17
            // 
            this.btn16_17.BackColor = System.Drawing.Color.Cornsilk;
            this.btn16_17.Location = new System.Drawing.Point(634, 359);
            this.btn16_17.Name = "btn16_17";
            this.btn16_17.Size = new System.Drawing.Size(89, 35);
            this.btn16_17.TabIndex = 26;
            this.btn16_17.Text = "16_17";
            this.btn16_17.UseVisualStyleBackColor = false;
            this.btn16_17.Click += new System.EventHandler(this.btn16_17_Click);
            // 
            // btn15_16
            // 
            this.btn15_16.BackColor = System.Drawing.Color.Cornsilk;
            this.btn15_16.Location = new System.Drawing.Point(548, 360);
            this.btn15_16.Name = "btn15_16";
            this.btn15_16.Size = new System.Drawing.Size(89, 35);
            this.btn15_16.TabIndex = 25;
            this.btn15_16.Text = "15_16";
            this.btn15_16.UseVisualStyleBackColor = false;
            this.btn15_16.Click += new System.EventHandler(this.btn15_16_Click);
            // 
            // btn8_9
            // 
            this.btn8_9.BackColor = System.Drawing.Color.Cornsilk;
            this.btn8_9.Location = new System.Drawing.Point(3, 359);
            this.btn8_9.Name = "btn8_9";
            this.btn8_9.Size = new System.Drawing.Size(89, 35);
            this.btn8_9.TabIndex = 23;
            this.btn8_9.Text = "8-9";
            this.btn8_9.UseVisualStyleBackColor = false;
            this.btn8_9.Click += new System.EventHandler(this.btn8_9_Click);
            // 
            // btn11_12
            // 
            this.btn11_12.BackColor = System.Drawing.Color.Cornsilk;
            this.btn11_12.Location = new System.Drawing.Point(277, 359);
            this.btn11_12.Name = "btn11_12";
            this.btn11_12.Size = new System.Drawing.Size(89, 35);
            this.btn11_12.TabIndex = 22;
            this.btn11_12.Text = "11-12";
            this.btn11_12.UseVisualStyleBackColor = false;
            this.btn11_12.Click += new System.EventHandler(this.btn11_12_Click);
            // 
            // btn9_10
            // 
            this.btn9_10.BackColor = System.Drawing.Color.Cornsilk;
            this.btn9_10.Location = new System.Drawing.Point(95, 359);
            this.btn9_10.Name = "btn9_10";
            this.btn9_10.Size = new System.Drawing.Size(89, 35);
            this.btn9_10.TabIndex = 21;
            this.btn9_10.Text = "9-10";
            this.btn9_10.UseVisualStyleBackColor = false;
            this.btn9_10.Click += new System.EventHandler(this.btn9_10_Click);
            // 
            // btnShowAvailabletimes
            // 
            this.btnShowAvailabletimes.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnShowAvailabletimes.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnShowAvailabletimes.FlatAppearance.BorderSize = 0;
            this.btnShowAvailabletimes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnShowAvailabletimes.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.btnShowAvailabletimes.ForeColor = System.Drawing.SystemColors.Info;
            this.btnShowAvailabletimes.Location = new System.Drawing.Point(260, 217);
            this.btnShowAvailabletimes.Name = "btnShowAvailabletimes";
            this.btnShowAvailabletimes.Size = new System.Drawing.Size(219, 33);
            this.btnShowAvailabletimes.TabIndex = 20;
            this.btnShowAvailabletimes.Text = "Show Available Times";
            this.btnShowAvailabletimes.UseVisualStyleBackColor = false;
            this.btnShowAvailabletimes.Click += new System.EventHandler(this.button2_Click);
            // 
            // dgvlistdeneme
            // 
            this.dgvlistdeneme.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvlistdeneme.BackgroundColor = System.Drawing.Color.Azure;
            this.dgvlistdeneme.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvlistdeneme.Location = new System.Drawing.Point(6, 285);
            this.dgvlistdeneme.Name = "dgvlistdeneme";
            this.dgvlistdeneme.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dgvlistdeneme.Size = new System.Drawing.Size(717, 45);
            this.dgvlistdeneme.TabIndex = 19;
            this.dgvlistdeneme.TabStop = false;
            // 
            // infoSelectDate
            // 
            this.infoSelectDate.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.infoSelectDate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.infoSelectDate.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.infoSelectDate.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.infoSelectDate.Location = new System.Drawing.Point(207, 146);
            this.infoSelectDate.Name = "infoSelectDate";
            this.infoSelectDate.Size = new System.Drawing.Size(322, 26);
            this.infoSelectDate.TabIndex = 18;
            this.infoSelectDate.Text = "Select Appoitment Date";
            this.infoSelectDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dtpChsAppoitmentDate
            // 
            this.dtpChsAppoitmentDate.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.dtpChsAppoitmentDate.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.dtpChsAppoitmentDate.Location = new System.Drawing.Point(241, 184);
            this.dtpChsAppoitmentDate.MaxDate = new System.DateTime(2022, 6, 30, 0, 0, 0, 0);
            this.dtpChsAppoitmentDate.Name = "dtpChsAppoitmentDate";
            this.dtpChsAppoitmentDate.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dtpChsAppoitmentDate.Size = new System.Drawing.Size(248, 27);
            this.dtpChsAppoitmentDate.TabIndex = 17;
            this.dtpChsAppoitmentDate.Value = new System.DateTime(2021, 1, 15, 0, 0, 0, 0);
            // 
            // panel19
            // 
            this.panel19.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel19.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel19.Controls.Add(this.panel20);
            this.panel19.Controls.Add(this.panel21);
            this.panel19.Location = new System.Drawing.Point(207, 113);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(322, 5);
            this.panel19.TabIndex = 16;
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel20.Location = new System.Drawing.Point(-81, 61);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(277, 5);
            this.panel20.TabIndex = 11;
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel21.Location = new System.Drawing.Point(-81, -61);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(277, 5);
            this.panel21.TabIndex = 9;
            // 
            // infoChooseWorkplace
            // 
            this.infoChooseWorkplace.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.infoChooseWorkplace.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.infoChooseWorkplace.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.infoChooseWorkplace.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.infoChooseWorkplace.Location = new System.Drawing.Point(207, 78);
            this.infoChooseWorkplace.Name = "infoChooseWorkplace";
            this.infoChooseWorkplace.Size = new System.Drawing.Size(322, 26);
            this.infoChooseWorkplace.TabIndex = 15;
            this.infoChooseWorkplace.Text = "Choose Workplace";
            this.infoChooseWorkplace.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // cmbxWorkplaceSlc
            // 
            this.cmbxWorkplaceSlc.FormattingEnabled = true;
            this.cmbxWorkplaceSlc.Location = new System.Drawing.Point(206, 116);
            this.cmbxWorkplaceSlc.Name = "cmbxWorkplaceSlc";
            this.cmbxWorkplaceSlc.Size = new System.Drawing.Size(322, 21);
            this.cmbxWorkplaceSlc.TabIndex = 14;
            // 
            // panel22
            // 
            this.panel22.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel22.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel22.Controls.Add(this.panel23);
            this.panel22.Controls.Add(this.panel24);
            this.panel22.Location = new System.Drawing.Point(206, 57);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(322, 5);
            this.panel22.TabIndex = 13;
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel23.Location = new System.Drawing.Point(-81, 61);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(277, 5);
            this.panel23.TabIndex = 11;
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panel24.Location = new System.Drawing.Point(-81, -61);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(277, 5);
            this.panel24.TabIndex = 9;
            // 
            // txtbxAppointmentUsrname
            // 
            this.txtbxAppointmentUsrname.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtbxAppointmentUsrname.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtbxAppointmentUsrname.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtbxAppointmentUsrname.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.txtbxAppointmentUsrname.Location = new System.Drawing.Point(206, 25);
            this.txtbxAppointmentUsrname.Name = "txtbxAppointmentUsrname";
            this.txtbxAppointmentUsrname.Size = new System.Drawing.Size(322, 26);
            this.txtbxAppointmentUsrname.TabIndex = 11;
            this.txtbxAppointmentUsrname.Text = "Name";
            this.txtbxAppointmentUsrname.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtbxAppointmentUsrname.Click += new System.EventHandler(this.txtbxAppointmentUsrname_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(547, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(219, 45);
            this.label1.TabIndex = 0;
            this.label1.Text = "If you cannot see the appointment\r\n time, it means that the appointment\r\n has not" +
    " been opened by the Workplace";
            // 
            // txtAppointmenTime
            // 
            this.txtAppointmenTime.Location = new System.Drawing.Point(303, 256);
            this.txtAppointmenTime.Name = "txtAppointmenTime";
            this.txtAppointmenTime.Size = new System.Drawing.Size(122, 20);
            this.txtAppointmenTime.TabIndex = 34;
            // 
            // frmGetAppointment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(778, 722);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel18);
            this.Controls.Add(this.loginAppLogo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmGetAppointment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GetAppointment";
            this.Load += new System.EventHandler(this.frmGetAppointment_Load);
            ((System.ComponentModel.ISupportInitialize)(this.loginAppLogo)).EndInit();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGetinfos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvlistdeneme)).EndInit();
            this.panel19.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox loginAppLogo;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.TextBox infoSelectDate;
        private System.Windows.Forms.DateTimePicker dtpChsAppoitmentDate;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.TextBox infoChooseWorkplace;
        private System.Windows.Forms.ComboBox cmbxWorkplaceSlc;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.TextBox txtbxAppointmentUsrname;
        private System.Windows.Forms.DataGridView dgvlistdeneme;
        private System.Windows.Forms.Button btnShowAvailabletimes;
        private System.Windows.Forms.Button btn14_15;
        private System.Windows.Forms.Button btn10_11;
        private System.Windows.Forms.Button btn13_14;
        private System.Windows.Forms.Button btn16_17;
        private System.Windows.Forms.Button btn15_16;
        private System.Windows.Forms.Button btn8_9;
        private System.Windows.Forms.Button btn11_12;
        private System.Windows.Forms.Button btn9_10;
        private System.Windows.Forms.Label lblinfoapp;
        private System.Windows.Forms.Label lblinfo;
        private System.Windows.Forms.DataGridView dgvGetinfos;
        private System.Windows.Forms.Button btnShowAppointment;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtAppointmenTime;
    }
}