﻿
namespace onlineAppointmentSystem
{
    partial class frmQuestionReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvLıstOfQuestions = new System.Windows.Forms.DataGridView();
            this.btnWaiting = new System.Windows.Forms.Button();
            this.btnResponsed = new System.Windows.Forms.Button();
            this.btnAllList = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLıstOfQuestions)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvLıstOfQuestions
            // 
            this.dgvLıstOfQuestions.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvLıstOfQuestions.BackgroundColor = System.Drawing.Color.Azure;
            this.dgvLıstOfQuestions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLıstOfQuestions.Location = new System.Drawing.Point(13, 114);
            this.dgvLıstOfQuestions.Name = "dgvLıstOfQuestions";
            this.dgvLıstOfQuestions.Size = new System.Drawing.Size(775, 324);
            this.dgvLıstOfQuestions.TabIndex = 0;
            // 
            // btnWaiting
            // 
            this.btnWaiting.BackColor = System.Drawing.Color.LightCyan;
            this.btnWaiting.Location = new System.Drawing.Point(527, 29);
            this.btnWaiting.Name = "btnWaiting";
            this.btnWaiting.Size = new System.Drawing.Size(147, 65);
            this.btnWaiting.TabIndex = 6;
            this.btnWaiting.Text = "WAITING QUESTIONS LIST";
            this.btnWaiting.UseVisualStyleBackColor = false;
            this.btnWaiting.Click += new System.EventHandler(this.btnWaiting_Click);
            // 
            // btnResponsed
            // 
            this.btnResponsed.BackColor = System.Drawing.Color.LightCyan;
            this.btnResponsed.Location = new System.Drawing.Point(322, 29);
            this.btnResponsed.Name = "btnResponsed";
            this.btnResponsed.Size = new System.Drawing.Size(147, 65);
            this.btnResponsed.TabIndex = 5;
            this.btnResponsed.Text = "RESPONSED QUESTIONS LIST";
            this.btnResponsed.UseVisualStyleBackColor = false;
            this.btnResponsed.Click += new System.EventHandler(this.btnResponsed_Click);
            // 
            // btnAllList
            // 
            this.btnAllList.BackColor = System.Drawing.Color.LightCyan;
            this.btnAllList.Location = new System.Drawing.Point(112, 29);
            this.btnAllList.Name = "btnAllList";
            this.btnAllList.Size = new System.Drawing.Size(147, 65);
            this.btnAllList.TabIndex = 4;
            this.btnAllList.Text = "ALL LIST";
            this.btnAllList.UseVisualStyleBackColor = false;
            this.btnAllList.Click += new System.EventHandler(this.btnAllList_Click);
            // 
            // frmQuestionReports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnWaiting);
            this.Controls.Add(this.btnResponsed);
            this.Controls.Add(this.btnAllList);
            this.Controls.Add(this.dgvLıstOfQuestions);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmQuestionReports";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmQuestionListForAdmin";
            ((System.ComponentModel.ISupportInitialize)(this.dgvLıstOfQuestions)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvLıstOfQuestions;
        private System.Windows.Forms.Button btnWaiting;
        private System.Windows.Forms.Button btnResponsed;
        private System.Windows.Forms.Button btnAllList;
    }
}