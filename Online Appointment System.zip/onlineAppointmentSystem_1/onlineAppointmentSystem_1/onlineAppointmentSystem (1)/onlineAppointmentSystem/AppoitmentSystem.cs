﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace onlineAppointmentSystem
{
    class AppoitmentSystem
    {
        public string AppointmentName { get; set; }
        public string AppoitmentTime { get; set; }
        public string AppoitmentWorkplaceName { get; set; }
        public ComboBox myComboBoxForAppoint { get; set; }
    }
}
