﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace onlineAppointmentSystem
{
    class DBEntityAppoitmentSystem:DBEntity
    {
        public void ListWorkplaces(AppoitmentSystem ApSystem)
        {
            SqlConnection con = new SqlConnection(ConnStr);
            SqlCommand command = new SqlCommand("Select WorkplaceName From tblWorkPlace", con);
            con.Open();
            SqlDataReader dr = command.ExecuteReader();
            while (dr.Read())
            {
                ApSystem.myComboBoxForAppoint.Items.Add(dr[0]);
            }
            con.Close();
        }
        public void ShowAppointment(AvailableTimesAppointment appoitmentSystem)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Insert into tblWorkplaceAppointmentinfo (AppoitmentDatetime) values (@AppointmentDatetime)", con);
                command.Parameters.AddWithValue("AppointmentDatetime", appoitmentSystem.AppointmentDatetime);
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                throw ex;
            }
            
        }
        public List<AvailableTimesAppointment> appoitmentSystemslist2(string key)
        {
            List<AvailableTimesAppointment> appoitmentSystem = new List<AvailableTimesAppointment>();
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Select * from tblWorkplaceAppointmentinfo  where AppoitmentDatetime=convert(varchar,'"+ key + "',103)", con);
                con.Open();
                using (var reader = command.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            var AppointmentsystemTimes = new AvailableTimesAppointment()
                            {
                                
                                time8_9 = reader.GetString(1),
                                time9_10 = reader.GetString(2),
                                time10_11 = reader.GetString(3),
                                time11_12 = reader.GetString(4),
                                time13_14 = reader.GetString(5),
                                time14_15 = reader.GetString(6),
                                time15_16 = reader.GetString(7),
                                time16_17 = reader.GetString(8),
                                AppointmentDatetime = reader.GetDateTime(9)
                            };
                            appoitmentSystem.Add(AppointmentsystemTimes);
                        }
                    }
                }
                return appoitmentSystem;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public void Update8_9(string Requested,string date)
        {
            SqlConnection con = new SqlConnection(ConnStr);
            SqlCommand command = new SqlCommand("Update tblWorkplaceAppointmentinfo set time8_9 =@time where AppoitmentDatetime=@date ", con);
            command.Parameters.AddWithValue("@time",Requested);
            command.Parameters.AddWithValue("@date",date);
            con.Open();
            command.ExecuteNonQuery();
        }
        public void Update9_10(string Requested, string date)
        {
            SqlConnection con = new SqlConnection(ConnStr);
            SqlCommand command = new SqlCommand("Update tblWorkplaceAppointmentinfo set time9_10 =@time where AppoitmentDatetime=@date ", con);
            command.Parameters.AddWithValue("@time", Requested);
            command.Parameters.AddWithValue("@date", date);
            con.Open();
            command.ExecuteNonQuery();
        }
        public void Update10_11(string Requested, string date)
        {
            SqlConnection con = new SqlConnection(ConnStr);
            SqlCommand command = new SqlCommand("Update tblWorkplaceAppointmentinfo set time10_11 =@time where AppoitmentDatetime=@date ", con);
            command.Parameters.AddWithValue("@time", Requested);
            command.Parameters.AddWithValue("@date", date);
            con.Open();
            command.ExecuteNonQuery();
        }
        public void Update11_12(string Requested, string date)
        {
            SqlConnection con = new SqlConnection(ConnStr);
            SqlCommand command = new SqlCommand("Update tblWorkplaceAppointmentinfo set time11_12 =@time where AppoitmentDatetime=@date ", con);
            command.Parameters.AddWithValue("@time", Requested);
            command.Parameters.AddWithValue("@date", date);
            con.Open();
            command.ExecuteNonQuery();
        }
        public void Update13_14(string Requested, string date)
        {
            SqlConnection con = new SqlConnection(ConnStr);
            SqlCommand command = new SqlCommand("Update tblWorkplaceAppointmentinfo set time13_14 =@time where AppoitmentDatetime=@date ", con);
            command.Parameters.AddWithValue("@time", Requested);
            command.Parameters.AddWithValue("@date", date);
            con.Open();
            command.ExecuteNonQuery();
        }
        public void Update14_15(string Requested, string date)
        {
            SqlConnection con = new SqlConnection(ConnStr);
            SqlCommand command = new SqlCommand("Update tblWorkplaceAppointmentinfo set time14_15 =@time where AppoitmentDatetime=@date ", con);
            command.Parameters.AddWithValue("@time", Requested);
            command.Parameters.AddWithValue("@date", date);
            con.Open();
            command.ExecuteNonQuery();
        }
        public void Update15_16(string Requested, string date)
        {
            SqlConnection con = new SqlConnection(ConnStr);
            SqlCommand command = new SqlCommand("Update tblWorkplaceAppointmentinfo set time15_16 =@time where AppoitmentDatetime=@date ", con);
            command.Parameters.AddWithValue("@time", Requested);
            command.Parameters.AddWithValue("@date", date);
            con.Open();
            command.ExecuteNonQuery();
        }
        public void Update16_17(string Requested, string date)
        {
            SqlConnection con = new SqlConnection(ConnStr);
            SqlCommand command = new SqlCommand("Update tblWorkplaceAppointmentinfo set time16_17 =@time where AppoitmentDatetime=@date ", con);
            command.Parameters.AddWithValue("@time", Requested);
            command.Parameters.AddWithValue("@date", date);
            con.Open();
            command.ExecuteNonQuery();
        }
        public void SaveAppInfo(AppoitmentSystem appoitmentSystem,string date)
        {
            SqlConnection con = new SqlConnection(ConnStr);
            SqlCommand command = new SqlCommand("Insert into tblAppointment (AppointmentTime,AppointmentDate,AppointmentWorkplaceName,AppointmentName) values (@AppointmentTime,@AppointmentDate, @AppointmentWorkplaceName,@AppointmentName)", con);
            command.Parameters.AddWithValue("AppointmentTime",appoitmentSystem.AppoitmentTime);
            command.Parameters.AddWithValue("AppointmentDate", date);
            command.Parameters.AddWithValue("AppointmentWorkplaceName",appoitmentSystem.AppoitmentWorkplaceName);
            command.Parameters.AddWithValue("AppointmentName", appoitmentSystem.AppointmentName);
            con.Open();
            command.ExecuteNonQuery();
        }
        public void ListInfos(DataGridView dataGridView)
        {
            SqlConnection con = new SqlConnection(ConnStr);
            SqlDataAdapter command = new SqlDataAdapter("Select AppointmentTime,AppointmentDate,AppointmentWorkplaceName,AppointmentName From tblAppointment", con);
            con.Open();
            DataSet ds = new DataSet();
            command.Fill(ds);
            dataGridView.DataSource = ds.Tables[0];
        }
        public List<AvailableTimesAppointment> appoitmentSystemslist()
        {
            List<AvailableTimesAppointment> appoitmentSystem = new List<AvailableTimesAppointment>();
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Select * from tblWorkplaceAppointmentinfo", con);
                con.Open();
                using (var reader = command.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            var AppointmentsystemTimes = new AvailableTimesAppointment()
                            {

                                time8_9 = reader.GetString(1),
                                time9_10 = reader.GetString(2),
                                time10_11 = reader.GetString(3),
                                time11_12 = reader.GetString(4),
                                time13_14 = reader.GetString(5),
                                time14_15 = reader.GetString(6),
                                time15_16 = reader.GetString(7),
                                time16_17 = reader.GetString(8),
                                AppointmentDatetime = reader.GetDateTime(9)
                            };
                            appoitmentSystem.Add(AppointmentsystemTimes);
                        }
                    }
                }
                return appoitmentSystem;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public void UpdateDeny8_9(AppSystemApproveorDeny appSystemApproveorDeny,string date)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Update tblWorkplaceAppointmentinfo SET time8_9=@time89 where AppoitmentDatetime=@timeup", con);
                command.Parameters.AddWithValue("@time89", appSystemApproveorDeny.time8_9);
                command.Parameters.AddWithValue("@timeup", date);
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public void UpdateDeny9_10(AppSystemApproveorDeny appSystemApproveorDeny, string date)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Update tblWorkplaceAppointmentinfo SET time9_10=@time910 where AppoitmentDatetime=@timeup", con);
                command.Parameters.AddWithValue("@time910", appSystemApproveorDeny.time9_10);
                command.Parameters.AddWithValue("@timeup", date);
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public void UpdateDeny10_11(AppSystemApproveorDeny appSystemApproveorDeny, string date)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Update tblWorkplaceAppointmentinfo SET time10_11=@time1011 where AppoitmentDatetime=@timeup", con);
                command.Parameters.AddWithValue("@time1011", appSystemApproveorDeny.time10_11);
                command.Parameters.AddWithValue("@timeup", date);
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public void UpdateDeny11_12(AppSystemApproveorDeny appSystemApproveorDeny, string date)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Update tblWorkplaceAppointmentinfo SET time11_12=@time1112 where AppoitmentDatetime=@timeup", con);
                command.Parameters.AddWithValue("@time1112", appSystemApproveorDeny.time11_12);
                command.Parameters.AddWithValue("@timeup", date);
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public void UpdateDeny13_14(AppSystemApproveorDeny appSystemApproveorDeny, string date)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Update tblWorkplaceAppointmentinfo SET time13_14=@time1314 where AppoitmentDatetime=@timeup", con);
                command.Parameters.AddWithValue("@time1314", appSystemApproveorDeny.time13_14);
                command.Parameters.AddWithValue("@timeup", date);
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public void UpdateDeny14_15(AppSystemApproveorDeny appSystemApproveorDeny, string date)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Update tblWorkplaceAppointmentinfo SET time14_15=@time1415 where AppoitmentDatetime=@timeup", con);
                command.Parameters.AddWithValue("@time1415", appSystemApproveorDeny.time14_15);
                command.Parameters.AddWithValue("@timeup", date);
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public void UpdateDeny15_16(AppSystemApproveorDeny appSystemApproveorDeny, string date)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Update tblWorkplaceAppointmentinfo SET time15_16=@time1516 where AppoitmentDatetime=@timeup", con);
                command.Parameters.AddWithValue("@time1516", appSystemApproveorDeny.time15_16);
                command.Parameters.AddWithValue("@timeup", date);
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public void UpdateDeny16_17(AppSystemApproveorDeny appSystemApproveorDeny, string date)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Update tblWorkplaceAppointmentinfo SET time16_17=@time1617 where AppoitmentDatetime=@timeup", con);
                command.Parameters.AddWithValue("@time1617", appSystemApproveorDeny.time16_17);
                command.Parameters.AddWithValue("@timeup", date);
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public void UpdateApprove8_9(AppSystemApproveorDeny appSystemApproveorDeny, string date)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Update tblWorkplaceAppointmentinfo SET time8_9=@time89 where AppoitmentDatetime=@timeup", con);
                command.Parameters.AddWithValue("@time89", appSystemApproveorDeny.time8_9);
                command.Parameters.AddWithValue("@timeup", date);
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public void UpdateApprove9_10(AppSystemApproveorDeny appSystemApproveorDeny, string date)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Update tblWorkplaceAppointmentinfo SET time9_10=@time910 where AppoitmentDatetime=@timeup", con);
                command.Parameters.AddWithValue("@time910", appSystemApproveorDeny.time9_10);
                command.Parameters.AddWithValue("@timeup", date);
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public void UpdateApprove10_11(AppSystemApproveorDeny appSystemApproveorDeny, string date)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Update tblWorkplaceAppointmentinfo SET time10_11=@time1011 where AppoitmentDatetime=@timeup", con);
                command.Parameters.AddWithValue("@time1011", appSystemApproveorDeny.time10_11);
                command.Parameters.AddWithValue("@timeup", date);
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public void UpdateApprove11_12(AppSystemApproveorDeny appSystemApproveorDeny, string date)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Update tblWorkplaceAppointmentinfo SET time11_12=@time1112 where AppoitmentDatetime=@timeup", con);
                command.Parameters.AddWithValue("@time1112", appSystemApproveorDeny.time11_12);
                command.Parameters.AddWithValue("@timeup", date);
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public void UpdateApprove13_14(AppSystemApproveorDeny appSystemApproveorDeny, string date)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Update tblWorkplaceAppointmentinfo SET time13_14=@time1314 where AppoitmentDatetime=@timeup", con);
                command.Parameters.AddWithValue("@time1314", appSystemApproveorDeny.time13_14);
                command.Parameters.AddWithValue("@timeup", date);
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public void UpdateApprove14_15(AppSystemApproveorDeny appSystemApproveorDeny, string date)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Update tblWorkplaceAppointmentinfo SET time14_15=@time1415 where AppoitmentDatetime=@timeup", con);
                command.Parameters.AddWithValue("@time1415", appSystemApproveorDeny.time14_15);
                command.Parameters.AddWithValue("@timeup", date);
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public void UpdateApprove15_16(AppSystemApproveorDeny appSystemApproveorDeny, string date)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Update tblWorkplaceAppointmentinfo SET time15_16=@time1516 where AppoitmentDatetime=@timeup", con);
                command.Parameters.AddWithValue("@time1516", appSystemApproveorDeny.time15_16);
                command.Parameters.AddWithValue("@timeup", date);
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public void UpdateApprove16_17(AppSystemApproveorDeny appSystemApproveorDeny, string date)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Update tblWorkplaceAppointmentinfo SET time16_17=@time1617 where AppoitmentDatetime=@timeup", con);
                command.Parameters.AddWithValue("@time1617", appSystemApproveorDeny.time16_17);
                command.Parameters.AddWithValue("@timeup", date);
                con.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public void RequestedList(DataGridView DgvQuestionList, string RqstList)
        {
            SqlConnection con = new SqlConnection(ConnStr);
            SqlDataAdapter da = new SqlDataAdapter("Select time8_9,time9_10,time10_11,time11_12,time13_14,time14_15,time15_16,time16_17,AppoitmentDatetime from tblWorkplaceAppointmentinfo ", con);//where AppoitmentDatetime LIKE '%'+@SearchKey+'%'
            DataSet ds = new DataSet();
            da.Fill(ds);
            DgvQuestionList.DataSource = ds.Tables[0];
        }
    }
}
