﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace onlineAppointmentSystem
{
    public class NormalUsers
    {
        public string ClientName { get; set; }
        public string ClientSurname { get; set; }
        public string ClientUsername { get; set; }
        public string ClientPhoneNumber { get; set; }
        public string ClientPassword { get; set; }
        public string ClientWhereToWork { get; set; }
        public string ClientEmail { get; set; }
        public string ClientAdress { get; set; }
    }
}