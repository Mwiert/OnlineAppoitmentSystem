﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace onlineAppointmentSystem
{
    class Admin
    {
        public string AdminUsername { get; private set; }
        public string AdminPass { get; private set; }
        public Admin()
        {
            AdminUsername = "admin";
            AdminPass = "admin";
        }
    }
}
