﻿
namespace onlineAppointmentSystem
{
    partial class frmWorkplaceAddRemoveDeleteUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmWorkplaceAddRemoveDeleteUpdate));
            this.btnAra = new System.Windows.Forms.Button();
            this.lblSrcLtr = new System.Windows.Forms.Label();
            this.txtbxSearchonDG = new System.Windows.Forms.TextBox();
            this.dgViewWorkplace = new System.Windows.Forms.DataGridView();
            this.updateLbl = new System.Windows.Forms.Label();
            this.txtbxid = new System.Windows.Forms.TextBox();
            this.btnListele = new System.Windows.Forms.Button();
            this.deleteLbl = new System.Windows.Forms.Label();
            this.deleteTxt = new System.Windows.Forms.TextBox();
            this.addWorkplaceBtn = new System.Windows.Forms.Button();
            this.btnguncelle = new System.Windows.Forms.Button();
            this.lblBsns = new System.Windows.Forms.Label();
            this.workplaceContactLbl = new System.Windows.Forms.Label();
            this.workplaceAddressLbl = new System.Windows.Forms.Label();
            this.workplaceNameLbl = new System.Windows.Forms.Label();
            this.isyeritip = new System.Windows.Forms.TextBox();
            this.isyericom = new System.Windows.Forms.TextBox();
            this.isyeriadres = new System.Windows.Forms.TextBox();
            this.isyeriad = new System.Windows.Forms.TextBox();
            this.btnSil = new System.Windows.Forms.Button();
            this.pnlUpAdd = new System.Windows.Forms.Panel();
            this.txtAddUpp = new System.Windows.Forms.Button();
            this.pnlDelete = new System.Windows.Forms.Panel();
            this.txtDeleteopp = new System.Windows.Forms.Button();
            this.pnlSrcopperatn = new System.Windows.Forms.Panel();
            this.loginAppLogo = new System.Windows.Forms.PictureBox();
            this.pnlBckWaR = new System.Windows.Forms.Panel();
            this.txtSrchOpp = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgViewWorkplace)).BeginInit();
            this.pnlUpAdd.SuspendLayout();
            this.pnlDelete.SuspendLayout();
            this.pnlSrcopperatn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.loginAppLogo)).BeginInit();
            this.pnlBckWaR.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnAra
            // 
            this.btnAra.BackColor = System.Drawing.Color.PaleVioletRed;
            this.btnAra.Location = new System.Drawing.Point(144, 134);
            this.btnAra.Name = "btnAra";
            this.btnAra.Size = new System.Drawing.Size(72, 43);
            this.btnAra.TabIndex = 53;
            this.btnAra.Text = "SEARCH";
            this.btnAra.UseVisualStyleBackColor = false;
            this.btnAra.Click += new System.EventHandler(this.btnAra_Click);
            // 
            // lblSrcLtr
            // 
            this.lblSrcLtr.AutoSize = true;
            this.lblSrcLtr.Location = new System.Drawing.Point(54, 69);
            this.lblSrcLtr.Name = "lblSrcLtr";
            this.lblSrcLtr.Size = new System.Drawing.Size(250, 13);
            this.lblSrcLtr.TabIndex = 52;
            this.lblSrcLtr.Text = "Enter the Name of the Workplace or Hosted Letters";
            // 
            // txtbxSearchonDG
            // 
            this.txtbxSearchonDG.Location = new System.Drawing.Point(65, 105);
            this.txtbxSearchonDG.Name = "txtbxSearchonDG";
            this.txtbxSearchonDG.Size = new System.Drawing.Size(235, 20);
            this.txtbxSearchonDG.TabIndex = 51;
            // 
            // dgViewWorkplace
            // 
            this.dgViewWorkplace.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgViewWorkplace.BackgroundColor = System.Drawing.Color.LavenderBlush;
            this.dgViewWorkplace.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgViewWorkplace.Location = new System.Drawing.Point(23, 517);
            this.dgViewWorkplace.Name = "dgViewWorkplace";
            this.dgViewWorkplace.Size = new System.Drawing.Size(795, 225);
            this.dgViewWorkplace.TabIndex = 50;
            // 
            // updateLbl
            // 
            this.updateLbl.AutoSize = true;
            this.updateLbl.Location = new System.Drawing.Point(34, 77);
            this.updateLbl.Name = "updateLbl";
            this.updateLbl.Size = new System.Drawing.Size(333, 13);
            this.updateLbl.TabIndex = 49;
            this.updateLbl.Text = "If You Want To Update, Write ID And Fill In The Updated Information";
            // 
            // txtbxid
            // 
            this.txtbxid.Location = new System.Drawing.Point(373, 77);
            this.txtbxid.Name = "txtbxid";
            this.txtbxid.Size = new System.Drawing.Size(72, 20);
            this.txtbxid.TabIndex = 48;
            // 
            // btnListele
            // 
            this.btnListele.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnListele.Location = new System.Drawing.Point(853, 602);
            this.btnListele.Name = "btnListele";
            this.btnListele.Size = new System.Drawing.Size(112, 65);
            this.btnListele.TabIndex = 47;
            this.btnListele.Text = "LİST";
            this.btnListele.UseVisualStyleBackColor = false;
            this.btnListele.Click += new System.EventHandler(this.btnListele_Click);
            // 
            // deleteLbl
            // 
            this.deleteLbl.AutoSize = true;
            this.deleteLbl.Location = new System.Drawing.Point(58, 81);
            this.deleteLbl.Name = "deleteLbl";
            this.deleteLbl.Size = new System.Drawing.Size(246, 13);
            this.deleteLbl.TabIndex = 46;
            this.deleteLbl.Text = "Enter the ID of the Workplace You Want to Delete";
            // 
            // deleteTxt
            // 
            this.deleteTxt.Location = new System.Drawing.Point(148, 107);
            this.deleteTxt.Name = "deleteTxt";
            this.deleteTxt.Size = new System.Drawing.Size(72, 20);
            this.deleteTxt.TabIndex = 45;
            // 
            // addWorkplaceBtn
            // 
            this.addWorkplaceBtn.BackColor = System.Drawing.Color.PaleVioletRed;
            this.addWorkplaceBtn.Location = new System.Drawing.Point(373, 153);
            this.addWorkplaceBtn.Name = "addWorkplaceBtn";
            this.addWorkplaceBtn.Size = new System.Drawing.Size(72, 42);
            this.addWorkplaceBtn.TabIndex = 44;
            this.addWorkplaceBtn.Text = "ADD";
            this.addWorkplaceBtn.UseVisualStyleBackColor = false;
            this.addWorkplaceBtn.Click += new System.EventHandler(this.addWorkplaceBtn_Click);
            // 
            // btnguncelle
            // 
            this.btnguncelle.BackColor = System.Drawing.Color.PaleVioletRed;
            this.btnguncelle.Location = new System.Drawing.Point(373, 237);
            this.btnguncelle.Name = "btnguncelle";
            this.btnguncelle.Size = new System.Drawing.Size(72, 42);
            this.btnguncelle.TabIndex = 43;
            this.btnguncelle.Text = "UPDATE";
            this.btnguncelle.UseVisualStyleBackColor = false;
            this.btnguncelle.Click += new System.EventHandler(this.btnguncelle_Click);
            // 
            // lblBsns
            // 
            this.lblBsns.AutoSize = true;
            this.lblBsns.Location = new System.Drawing.Point(79, 278);
            this.lblBsns.Name = "lblBsns";
            this.lblBsns.Size = new System.Drawing.Size(79, 13);
            this.lblBsns.TabIndex = 39;
            this.lblBsns.Text = "Business Type:";
            // 
            // workplaceContactLbl
            // 
            this.workplaceContactLbl.AutoSize = true;
            this.workplaceContactLbl.Location = new System.Drawing.Point(56, 234);
            this.workplaceContactLbl.Name = "workplaceContactLbl";
            this.workplaceContactLbl.Size = new System.Drawing.Size(102, 13);
            this.workplaceContactLbl.TabIndex = 40;
            this.workplaceContactLbl.Text = "Workplace Contact:";
            // 
            // workplaceAddressLbl
            // 
            this.workplaceAddressLbl.AutoSize = true;
            this.workplaceAddressLbl.Location = new System.Drawing.Point(55, 175);
            this.workplaceAddressLbl.Name = "workplaceAddressLbl";
            this.workplaceAddressLbl.Size = new System.Drawing.Size(103, 13);
            this.workplaceAddressLbl.TabIndex = 41;
            this.workplaceAddressLbl.Text = "Workplace Address:";
            // 
            // workplaceNameLbl
            // 
            this.workplaceNameLbl.AutoSize = true;
            this.workplaceNameLbl.Location = new System.Drawing.Point(65, 130);
            this.workplaceNameLbl.Name = "workplaceNameLbl";
            this.workplaceNameLbl.Size = new System.Drawing.Size(93, 13);
            this.workplaceNameLbl.TabIndex = 42;
            this.workplaceNameLbl.Text = "Workplace Name:";
            // 
            // isyeritip
            // 
            this.isyeritip.Location = new System.Drawing.Point(164, 278);
            this.isyeritip.Name = "isyeritip";
            this.isyeritip.Size = new System.Drawing.Size(135, 20);
            this.isyeritip.TabIndex = 38;
            // 
            // isyericom
            // 
            this.isyericom.Location = new System.Drawing.Point(164, 227);
            this.isyericom.Name = "isyericom";
            this.isyericom.Size = new System.Drawing.Size(135, 20);
            this.isyericom.TabIndex = 37;
            // 
            // isyeriadres
            // 
            this.isyeriadres.Location = new System.Drawing.Point(164, 175);
            this.isyeriadres.Name = "isyeriadres";
            this.isyeriadres.Size = new System.Drawing.Size(135, 20);
            this.isyeriadres.TabIndex = 36;
            // 
            // isyeriad
            // 
            this.isyeriad.Location = new System.Drawing.Point(164, 127);
            this.isyeriad.Name = "isyeriad";
            this.isyeriad.Size = new System.Drawing.Size(135, 20);
            this.isyeriad.TabIndex = 35;
            // 
            // btnSil
            // 
            this.btnSil.BackColor = System.Drawing.Color.PaleVioletRed;
            this.btnSil.Location = new System.Drawing.Point(148, 135);
            this.btnSil.Name = "btnSil";
            this.btnSil.Size = new System.Drawing.Size(72, 42);
            this.btnSil.TabIndex = 34;
            this.btnSil.Text = "DELETE";
            this.btnSil.UseVisualStyleBackColor = false;
            this.btnSil.Click += new System.EventHandler(this.btnSil_Click);
            // 
            // pnlUpAdd
            // 
            this.pnlUpAdd.BackColor = System.Drawing.Color.LavenderBlush;
            this.pnlUpAdd.Controls.Add(this.txtAddUpp);
            this.pnlUpAdd.Controls.Add(this.updateLbl);
            this.pnlUpAdd.Controls.Add(this.isyeriad);
            this.pnlUpAdd.Controls.Add(this.isyeriadres);
            this.pnlUpAdd.Controls.Add(this.isyericom);
            this.pnlUpAdd.Controls.Add(this.isyeritip);
            this.pnlUpAdd.Controls.Add(this.workplaceNameLbl);
            this.pnlUpAdd.Controls.Add(this.txtbxid);
            this.pnlUpAdd.Controls.Add(this.workplaceAddressLbl);
            this.pnlUpAdd.Controls.Add(this.workplaceContactLbl);
            this.pnlUpAdd.Controls.Add(this.lblBsns);
            this.pnlUpAdd.Controls.Add(this.btnguncelle);
            this.pnlUpAdd.Controls.Add(this.addWorkplaceBtn);
            this.pnlUpAdd.Location = new System.Drawing.Point(23, 144);
            this.pnlUpAdd.Name = "pnlUpAdd";
            this.pnlUpAdd.Size = new System.Drawing.Size(464, 317);
            this.pnlUpAdd.TabIndex = 54;
            // 
            // txtAddUpp
            // 
            this.txtAddUpp.BackColor = System.Drawing.Color.LavenderBlush;
            this.txtAddUpp.Font = new System.Drawing.Font("Century Gothic", 14F);
            this.txtAddUpp.Location = new System.Drawing.Point(82, 4);
            this.txtAddUpp.Name = "txtAddUpp";
            this.txtAddUpp.Size = new System.Drawing.Size(285, 54);
            this.txtAddUpp.TabIndex = 50;
            this.txtAddUpp.TabStop = false;
            this.txtAddUpp.Text = "ADD AND UPDATE OPERATIONS";
            this.txtAddUpp.UseVisualStyleBackColor = false;
            // 
            // pnlDelete
            // 
            this.pnlDelete.BackColor = System.Drawing.Color.LavenderBlush;
            this.pnlDelete.Controls.Add(this.txtDeleteopp);
            this.pnlDelete.Controls.Add(this.deleteLbl);
            this.pnlDelete.Controls.Add(this.btnSil);
            this.pnlDelete.Controls.Add(this.deleteTxt);
            this.pnlDelete.Location = new System.Drawing.Point(607, 329);
            this.pnlDelete.Name = "pnlDelete";
            this.pnlDelete.Size = new System.Drawing.Size(358, 182);
            this.pnlDelete.TabIndex = 55;
            // 
            // txtDeleteopp
            // 
            this.txtDeleteopp.BackColor = System.Drawing.Color.LavenderBlush;
            this.txtDeleteopp.Font = new System.Drawing.Font("Century Gothic", 14F);
            this.txtDeleteopp.Image = ((System.Drawing.Image)(resources.GetObject("txtDeleteopp.Image")));
            this.txtDeleteopp.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.txtDeleteopp.Location = new System.Drawing.Point(61, 3);
            this.txtDeleteopp.Name = "txtDeleteopp";
            this.txtDeleteopp.Size = new System.Drawing.Size(243, 59);
            this.txtDeleteopp.TabIndex = 51;
            this.txtDeleteopp.TabStop = false;
            this.txtDeleteopp.Text = "DELETE OPERATIONS";
            this.txtDeleteopp.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.txtDeleteopp.UseVisualStyleBackColor = false;
            // 
            // pnlSrcopperatn
            // 
            this.pnlSrcopperatn.BackColor = System.Drawing.Color.LavenderBlush;
            this.pnlSrcopperatn.Controls.Add(this.txtSrchOpp);
            this.pnlSrcopperatn.Controls.Add(this.lblSrcLtr);
            this.pnlSrcopperatn.Controls.Add(this.txtbxSearchonDG);
            this.pnlSrcopperatn.Controls.Add(this.btnAra);
            this.pnlSrcopperatn.Location = new System.Drawing.Point(607, 141);
            this.pnlSrcopperatn.Name = "pnlSrcopperatn";
            this.pnlSrcopperatn.Size = new System.Drawing.Size(358, 182);
            this.pnlSrcopperatn.TabIndex = 56;
            // 
            // loginAppLogo
            // 
            this.loginAppLogo.Image = ((System.Drawing.Image)(resources.GetObject("loginAppLogo.Image")));
            this.loginAppLogo.Location = new System.Drawing.Point(411, 11);
            this.loginAppLogo.Name = "loginAppLogo";
            this.loginAppLogo.Size = new System.Drawing.Size(189, 123);
            this.loginAppLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.loginAppLogo.TabIndex = 57;
            this.loginAppLogo.TabStop = false;
            // 
            // pnlBckWaR
            // 
            this.pnlBckWaR.BackColor = System.Drawing.Color.Azure;
            this.pnlBckWaR.Controls.Add(this.loginAppLogo);
            this.pnlBckWaR.Controls.Add(this.btnListele);
            this.pnlBckWaR.Controls.Add(this.pnlSrcopperatn);
            this.pnlBckWaR.Controls.Add(this.dgViewWorkplace);
            this.pnlBckWaR.Controls.Add(this.pnlDelete);
            this.pnlBckWaR.Controls.Add(this.pnlUpAdd);
            this.pnlBckWaR.Location = new System.Drawing.Point(1, 1);
            this.pnlBckWaR.Name = "pnlBckWaR";
            this.pnlBckWaR.Size = new System.Drawing.Size(981, 761);
            this.pnlBckWaR.TabIndex = 58;
            // 
            // txtSrchOpp
            // 
            this.txtSrchOpp.BackColor = System.Drawing.Color.LavenderBlush;
            this.txtSrchOpp.Font = new System.Drawing.Font("Century Gothic", 14F);
            this.txtSrchOpp.Image = ((System.Drawing.Image)(resources.GetObject("txtSrchOpp.Image")));
            this.txtSrchOpp.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.txtSrchOpp.Location = new System.Drawing.Point(57, 0);
            this.txtSrchOpp.Name = "txtSrchOpp";
            this.txtSrchOpp.Size = new System.Drawing.Size(243, 51);
            this.txtSrchOpp.TabIndex = 51;
            this.txtSrchOpp.TabStop = false;
            this.txtSrchOpp.Text = "DELETE OPERATIONS";
            this.txtSrchOpp.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.txtSrchOpp.UseVisualStyleBackColor = false;
            // 
            // frmWorkplaceAddRemoveDeleteUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(985, 767);
            this.Controls.Add(this.pnlBckWaR);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmWorkplaceAddRemoveDeleteUpdate";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmWorkplaceAddRemoveDeleteUpdate";
            this.Load += new System.EventHandler(this.frmWorkplaceAddRemoveDeleteUpdate_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgViewWorkplace)).EndInit();
            this.pnlUpAdd.ResumeLayout(false);
            this.pnlUpAdd.PerformLayout();
            this.pnlDelete.ResumeLayout(false);
            this.pnlDelete.PerformLayout();
            this.pnlSrcopperatn.ResumeLayout(false);
            this.pnlSrcopperatn.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.loginAppLogo)).EndInit();
            this.pnlBckWaR.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAra;
        private System.Windows.Forms.Label lblSrcLtr;
        private System.Windows.Forms.TextBox txtbxSearchonDG;
        private System.Windows.Forms.DataGridView dgViewWorkplace;
        private System.Windows.Forms.Label updateLbl;
        private System.Windows.Forms.TextBox txtbxid;
        private System.Windows.Forms.Button btnListele;
        private System.Windows.Forms.Label deleteLbl;
        private System.Windows.Forms.TextBox deleteTxt;
        private System.Windows.Forms.Button addWorkplaceBtn;
        private System.Windows.Forms.Button btnguncelle;
        private System.Windows.Forms.Label lblBsns;
        private System.Windows.Forms.Label workplaceContactLbl;
        private System.Windows.Forms.Label workplaceAddressLbl;
        private System.Windows.Forms.Label workplaceNameLbl;
        private System.Windows.Forms.TextBox isyeritip;
        private System.Windows.Forms.TextBox isyericom;
        private System.Windows.Forms.TextBox isyeriadres;
        private System.Windows.Forms.TextBox isyeriad;
        private System.Windows.Forms.Button btnSil;
        private System.Windows.Forms.Panel pnlUpAdd;
        private System.Windows.Forms.Button txtAddUpp;
        private System.Windows.Forms.Panel pnlDelete;
        private System.Windows.Forms.Button txtDeleteopp;
        private System.Windows.Forms.Panel pnlSrcopperatn;
        private System.Windows.Forms.PictureBox loginAppLogo;
        private System.Windows.Forms.Panel pnlBckWaR;
        private System.Windows.Forms.Button txtSrchOpp;
    }
}