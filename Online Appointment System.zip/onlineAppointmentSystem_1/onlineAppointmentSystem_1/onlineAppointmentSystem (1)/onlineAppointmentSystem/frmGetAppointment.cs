﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace onlineAppointmentSystem
{
    public partial class frmGetAppointment : Form
    {
        public frmGetAppointment()
        {
            InitializeComponent();
        }
        private void txtbxAppointmentUsrname_Click(object sender, EventArgs e)
        {
            txtbxAppointmentUsrname.Clear();
        }
        private void frmGetAppointment_Load(object sender, EventArgs e)
        {
            AppoitmentSystem appoitmentSystem = new AppoitmentSystem()
            {
                myComboBoxForAppoint = cmbxWorkplaceSlc
            };
            DBEntityAppoitmentSystem appoitmentSystem1 = new DBEntityAppoitmentSystem();
            appoitmentSystem1.ListWorkplaces(appoitmentSystem);
        }
        private void listInfo()
        {
            DBEntityAppoitmentSystem dBEntityAppoitmentSystem = new DBEntityAppoitmentSystem();
            dBEntityAppoitmentSystem.ListInfos(dgvGetinfos);
            dgvGetinfos.Refresh();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (cmbxWorkplaceSlc.SelectedIndex < 0)
            {
                MessageBox.Show("PLEASE SELECT A WORKPLACE");
            }
            else
            {
                if (dgvlistdeneme.Rows.Count==0)
                {
                    try
                    {
                        ShowAvblTimes();
                    }
                    catch (Exception)
                    {

                        throw;
                    }
                }
                else
                {
                    ShowAvblTimes();
                }
            }
            
        }
        private void ShowAvblTimes()
        {
            DBEntityAppoitmentSystem appoitmentSystem = new DBEntityAppoitmentSystem();
            string date = dtpChsAppoitmentDate.Value.ToString("yyyy-MM-dd");
            dgvlistdeneme.DataSource = appoitmentSystem.appoitmentSystemslist2(date);
            dgvlistdeneme.Refresh();
        }
        private void btn8_9_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are You Sure to Get Appointment At this Time?", "Yes Im Sure", MessageBoxButtons.YesNo);
            string Request = "REQUESTED";
            DBEntityAppoitmentSystem appoitmentSystem = new DBEntityAppoitmentSystem();
            string date = dtpChsAppoitmentDate.Value.ToString("yyyy-MM-dd");
            appoitmentSystem.Update8_9(Request,date);
            txtAppointmenTime.Text = "time8_9";
            ShowAvblTimes();
        }

        private void btn9_10_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are You Sure to Get Appointment At this Time?", "Yes Im Sure", MessageBoxButtons.YesNo);
            string Request = "REQUESTED";
            DBEntityAppoitmentSystem appoitmentSystem = new DBEntityAppoitmentSystem();
            string date = dtpChsAppoitmentDate.Value.ToString("yyyy-MM-dd");
            appoitmentSystem.Update9_10(Request, date);
            txtAppointmenTime.Text = "time9_10";
            ShowAvblTimes();
        }

        private void btn10_11_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are You Sure to Get Appointment At this Time?", "Yes Im Sure", MessageBoxButtons.YesNo);
            string Request = "REQUESTED";
            DBEntityAppoitmentSystem appoitmentSystem = new DBEntityAppoitmentSystem();
            string date = dtpChsAppoitmentDate.Value.ToString("yyyy-MM-dd");
            appoitmentSystem.Update10_11(Request, date);
            txtAppointmenTime.Text = "time10_11";
            ShowAvblTimes();
        }

        private void btn11_12_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are You Sure to Get Appointment At this Time?", "Yes Im Sure", MessageBoxButtons.YesNo);
            string Request = "REQUESTED";
            DBEntityAppoitmentSystem appoitmentSystem = new DBEntityAppoitmentSystem();
            string date = dtpChsAppoitmentDate.Value.ToString("yyyy-MM-dd");
            appoitmentSystem.Update11_12(Request, date);
            txtAppointmenTime.Text = "time11_12";
            ShowAvblTimes();
        }

        private void btn13_14_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are You Sure to Get Appointment At this Time?", "Yes Im Sure", MessageBoxButtons.YesNo);
            string Request = "REQUESTED";
            DBEntityAppoitmentSystem appoitmentSystem = new DBEntityAppoitmentSystem();
            string date = dtpChsAppoitmentDate.Value.ToString("yyyy-MM-dd");
            appoitmentSystem.Update13_14(Request, date);
            txtAppointmenTime.Text = "time13_14";
            ShowAvblTimes();
        }

        private void btn14_15_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are You Sure to Get Appointment At this Time?", "Yes Im Sure", MessageBoxButtons.YesNo);
            string Request = "REQUESTED";
            DBEntityAppoitmentSystem appoitmentSystem = new DBEntityAppoitmentSystem();
            string date = dtpChsAppoitmentDate.Value.ToString("yyyy-MM-dd");
            appoitmentSystem.Update14_15(Request, date);
            txtAppointmenTime.Text = "time14_15";
            ShowAvblTimes();
        }

        private void btn15_16_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are You Sure to Get Appointment At this Time?", "Yes Im Sure", MessageBoxButtons.YesNo);
            string Request = "REQUESTED";
            DBEntityAppoitmentSystem appoitmentSystem = new DBEntityAppoitmentSystem();
            string date = dtpChsAppoitmentDate.Value.ToString("yyyy-MM-dd");
            appoitmentSystem.Update15_16(Request, date);
            txtAppointmenTime.Text = "time15_16";
            ShowAvblTimes();
        }
        private void btn16_17_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are You Sure to Get Appointment At this Time?","Yes Im Sure",MessageBoxButtons.YesNo);
            string Request = "REQUESTED";
            DBEntityAppoitmentSystem appoitmentSystem = new DBEntityAppoitmentSystem();
            string date = dtpChsAppoitmentDate.Value.ToString("yyyy-MM-dd");
            appoitmentSystem.Update16_17(Request, date);
            txtAppointmenTime.Text = "time16_17";
            ShowAvblTimes();
        }
        private void btnShowAppointment_Click(object sender, EventArgs e)
        {
            if (cmbxWorkplaceSlc.SelectedIndex < 0)            ////// daha iyi gösterilebilir
            {
                MessageBox.Show("PLEASE SELECT A WORKPLACE");
            }
            else
            {
                try
                {
                    string date = dtpChsAppoitmentDate.Value.ToString("yyyy-MM-dd");
                    AppoitmentSystem appoitmentSystem = new AppoitmentSystem()
                    {
                        AppointmentName = txtbxAppointmentUsrname.Text,
                        AppoitmentWorkplaceName = cmbxWorkplaceSlc.Text,
                        AppoitmentTime = txtAppointmenTime.Text
                    };
                    DBEntityAppoitmentSystem dBEntityAppoitmentSystem = new DBEntityAppoitmentSystem();
                    dBEntityAppoitmentSystem.SaveAppInfo(appoitmentSystem, date);
                    listInfo();
                    MessageBox.Show("YOUR APPOINTMENT SUCCESFULLY CREATED. TAKE IT DOWN TO CHECK");
                }
                catch (Exception ex)
                {

                    throw ex;
                }
            }
            
        }
    }
}
