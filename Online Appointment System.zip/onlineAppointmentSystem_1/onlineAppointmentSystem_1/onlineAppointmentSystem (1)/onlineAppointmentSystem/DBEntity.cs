﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace onlineAppointmentSystem
{
    public class DBEntity
    {
        public string ConnStr { get; private set; }
        public DBEntity()
        {
            ConnStr = (@"Data Source = MWIERT\SQLEXPRESS01; Initial Catalog = dboDonemOdevi; Integrated Security = True");
        }
    }
}

