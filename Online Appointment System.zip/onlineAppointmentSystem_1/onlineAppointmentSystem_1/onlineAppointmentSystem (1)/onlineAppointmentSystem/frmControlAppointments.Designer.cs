﻿
namespace onlineAppointmentSystem
{
    partial class frmControlAppointments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmControlAppointments));
            this.dgvDenyOrApprove = new System.Windows.Forms.DataGridView();
            this.loginAppLogo = new System.Windows.Forms.PictureBox();
            this.btnDeny = new System.Windows.Forms.Button();
            this.btnApprove = new System.Windows.Forms.Button();
            this.dtpdeneme = new System.Windows.Forms.DateTimePicker();
            this.btnAppDateAdd = new System.Windows.Forms.Button();
            this.dgvAllList = new System.Windows.Forms.DataGridView();
            this.btnListAll = new System.Windows.Forms.Button();
            this.dgvApproveOrDeny = new System.Windows.Forms.DataGridView();
            this.txtGetTime = new System.Windows.Forms.TextBox();
            this.txtSeeDate = new System.Windows.Forms.TextBox();
            this.dtpSelectWhichday = new System.Windows.Forms.DateTimePicker();
            this.btn14_15 = new System.Windows.Forms.Button();
            this.btn10_11 = new System.Windows.Forms.Button();
            this.btn13_14 = new System.Windows.Forms.Button();
            this.btn16_17 = new System.Windows.Forms.Button();
            this.btn15_16 = new System.Windows.Forms.Button();
            this.btn8_9 = new System.Windows.Forms.Button();
            this.btn11_12 = new System.Windows.Forms.Button();
            this.btn9_10 = new System.Windows.Forms.Button();
            this.lblinfo = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDenyOrApprove)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginAppLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAllList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvApproveOrDeny)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvDenyOrApprove
            // 
            this.dgvDenyOrApprove.BackgroundColor = System.Drawing.Color.LavenderBlush;
            this.dgvDenyOrApprove.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvDenyOrApprove.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDenyOrApprove.Location = new System.Drawing.Point(538, 173);
            this.dgvDenyOrApprove.Name = "dgvDenyOrApprove";
            this.dgvDenyOrApprove.Size = new System.Drawing.Size(509, 204);
            this.dgvDenyOrApprove.TabIndex = 0;
            // 
            // loginAppLogo
            // 
            this.loginAppLogo.Image = ((System.Drawing.Image)(resources.GetObject("loginAppLogo.Image")));
            this.loginAppLogo.Location = new System.Drawing.Point(443, 12);
            this.loginAppLogo.Name = "loginAppLogo";
            this.loginAppLogo.Size = new System.Drawing.Size(166, 118);
            this.loginAppLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.loginAppLogo.TabIndex = 8;
            this.loginAppLogo.TabStop = false;
            // 
            // btnDeny
            // 
            this.btnDeny.BackColor = System.Drawing.Color.LightCyan;
            this.btnDeny.Location = new System.Drawing.Point(71, 108);
            this.btnDeny.Name = "btnDeny";
            this.btnDeny.Size = new System.Drawing.Size(138, 59);
            this.btnDeny.TabIndex = 9;
            this.btnDeny.Text = "DENY REQUEST";
            this.btnDeny.UseVisualStyleBackColor = false;
            this.btnDeny.Click += new System.EventHandler(this.btnDeny_Click);
            // 
            // btnApprove
            // 
            this.btnApprove.BackColor = System.Drawing.Color.LightCyan;
            this.btnApprove.Location = new System.Drawing.Point(299, 108);
            this.btnApprove.Name = "btnApprove";
            this.btnApprove.Size = new System.Drawing.Size(138, 59);
            this.btnApprove.TabIndex = 10;
            this.btnApprove.Text = "APPROVE REQUEST";
            this.btnApprove.UseVisualStyleBackColor = false;
            this.btnApprove.Click += new System.EventHandler(this.btnApprove_Click);
            // 
            // dtpdeneme
            // 
            this.dtpdeneme.Location = new System.Drawing.Point(723, 50);
            this.dtpdeneme.Name = "dtpdeneme";
            this.dtpdeneme.Size = new System.Drawing.Size(200, 20);
            this.dtpdeneme.TabIndex = 11;
            // 
            // btnAppDateAdd
            // 
            this.btnAppDateAdd.BackColor = System.Drawing.Color.LightCyan;
            this.btnAppDateAdd.Location = new System.Drawing.Point(743, 93);
            this.btnAppDateAdd.Name = "btnAppDateAdd";
            this.btnAppDateAdd.Size = new System.Drawing.Size(138, 74);
            this.btnAppDateAdd.TabIndex = 12;
            this.btnAppDateAdd.Text = "ADD APPOINTMENT DAY";
            this.btnAppDateAdd.UseVisualStyleBackColor = false;
            this.btnAppDateAdd.Click += new System.EventHandler(this.btnAppDateAdd_Click);
            // 
            // dgvAllList
            // 
            this.dgvAllList.BackgroundColor = System.Drawing.Color.LavenderBlush;
            this.dgvAllList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvAllList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAllList.Location = new System.Drawing.Point(538, 468);
            this.dgvAllList.Name = "dgvAllList";
            this.dgvAllList.Size = new System.Drawing.Size(509, 156);
            this.dgvAllList.TabIndex = 13;
            // 
            // btnListAll
            // 
            this.btnListAll.BackColor = System.Drawing.Color.LightCyan;
            this.btnListAll.Location = new System.Drawing.Point(743, 388);
            this.btnListAll.Name = "btnListAll";
            this.btnListAll.Size = new System.Drawing.Size(138, 74);
            this.btnListAll.TabIndex = 14;
            this.btnListAll.Text = "LIST";
            this.btnListAll.UseVisualStyleBackColor = false;
            this.btnListAll.Click += new System.EventHandler(this.btnListAll_Click);
            // 
            // dgvApproveOrDeny
            // 
            this.dgvApproveOrDeny.BackgroundColor = System.Drawing.Color.LavenderBlush;
            this.dgvApproveOrDeny.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvApproveOrDeny.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvApproveOrDeny.Location = new System.Drawing.Point(12, 329);
            this.dgvApproveOrDeny.Name = "dgvApproveOrDeny";
            this.dgvApproveOrDeny.Size = new System.Drawing.Size(509, 295);
            this.dgvApproveOrDeny.TabIndex = 15;
            // 
            // txtGetTime
            // 
            this.txtGetTime.Location = new System.Drawing.Point(80, 191);
            this.txtGetTime.Name = "txtGetTime";
            this.txtGetTime.Size = new System.Drawing.Size(100, 20);
            this.txtGetTime.TabIndex = 16;
            this.txtGetTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtSeeDate
            // 
            this.txtSeeDate.Location = new System.Drawing.Point(252, 191);
            this.txtSeeDate.Name = "txtSeeDate";
            this.txtSeeDate.Size = new System.Drawing.Size(100, 20);
            this.txtSeeDate.TabIndex = 17;
            // 
            // dtpSelectWhichday
            // 
            this.dtpSelectWhichday.Location = new System.Drawing.Point(358, 191);
            this.dtpSelectWhichday.Name = "dtpSelectWhichday";
            this.dtpSelectWhichday.Size = new System.Drawing.Size(108, 20);
            this.dtpSelectWhichday.TabIndex = 18;
            this.dtpSelectWhichday.CloseUp += new System.EventHandler(this.dtpSelectWhichday_CloseUp);
            // 
            // btn14_15
            // 
            this.btn14_15.BackColor = System.Drawing.Color.Cornsilk;
            this.btn14_15.Location = new System.Drawing.Point(139, 278);
            this.btn14_15.Name = "btn14_15";
            this.btn14_15.Size = new System.Drawing.Size(89, 35);
            this.btn14_15.TabIndex = 37;
            this.btn14_15.Text = "14_15";
            this.btn14_15.UseVisualStyleBackColor = false;
            this.btn14_15.Click += new System.EventHandler(this.btn14_15_Click);
            // 
            // btn10_11
            // 
            this.btn10_11.BackColor = System.Drawing.Color.Cornsilk;
            this.btn10_11.Location = new System.Drawing.Point(263, 217);
            this.btn10_11.Name = "btn10_11";
            this.btn10_11.Size = new System.Drawing.Size(89, 35);
            this.btn10_11.TabIndex = 36;
            this.btn10_11.Text = "10-11";
            this.btn10_11.UseVisualStyleBackColor = false;
            this.btn10_11.Click += new System.EventHandler(this.btn10_11_Click);
            // 
            // btn13_14
            // 
            this.btn13_14.BackColor = System.Drawing.Color.Cornsilk;
            this.btn13_14.Location = new System.Drawing.Point(12, 277);
            this.btn13_14.Name = "btn13_14";
            this.btn13_14.Size = new System.Drawing.Size(89, 35);
            this.btn13_14.TabIndex = 35;
            this.btn13_14.Text = "13_14";
            this.btn13_14.UseVisualStyleBackColor = false;
            this.btn13_14.Click += new System.EventHandler(this.btn13_14_Click);
            // 
            // btn16_17
            // 
            this.btn16_17.BackColor = System.Drawing.Color.Cornsilk;
            this.btn16_17.Location = new System.Drawing.Point(377, 277);
            this.btn16_17.Name = "btn16_17";
            this.btn16_17.Size = new System.Drawing.Size(89, 35);
            this.btn16_17.TabIndex = 34;
            this.btn16_17.Text = "16_17";
            this.btn16_17.UseVisualStyleBackColor = false;
            this.btn16_17.Click += new System.EventHandler(this.btn16_17_Click);
            // 
            // btn15_16
            // 
            this.btn15_16.BackColor = System.Drawing.Color.Cornsilk;
            this.btn15_16.Location = new System.Drawing.Point(263, 277);
            this.btn15_16.Name = "btn15_16";
            this.btn15_16.Size = new System.Drawing.Size(89, 35);
            this.btn15_16.TabIndex = 33;
            this.btn15_16.Text = "15_16";
            this.btn15_16.UseVisualStyleBackColor = false;
            this.btn15_16.Click += new System.EventHandler(this.btn15_16_Click);
            // 
            // btn8_9
            // 
            this.btn8_9.BackColor = System.Drawing.Color.Cornsilk;
            this.btn8_9.Location = new System.Drawing.Point(12, 217);
            this.btn8_9.Name = "btn8_9";
            this.btn8_9.Size = new System.Drawing.Size(89, 35);
            this.btn8_9.TabIndex = 32;
            this.btn8_9.Text = "8-9";
            this.btn8_9.UseVisualStyleBackColor = false;
            this.btn8_9.Click += new System.EventHandler(this.btn8_9_Click);
            // 
            // btn11_12
            // 
            this.btn11_12.BackColor = System.Drawing.Color.Cornsilk;
            this.btn11_12.Location = new System.Drawing.Point(377, 217);
            this.btn11_12.Name = "btn11_12";
            this.btn11_12.Size = new System.Drawing.Size(89, 35);
            this.btn11_12.TabIndex = 31;
            this.btn11_12.Text = "11-12";
            this.btn11_12.UseVisualStyleBackColor = false;
            this.btn11_12.Click += new System.EventHandler(this.btn11_12_Click);
            // 
            // btn9_10
            // 
            this.btn9_10.BackColor = System.Drawing.Color.Cornsilk;
            this.btn9_10.Location = new System.Drawing.Point(139, 217);
            this.btn9_10.Name = "btn9_10";
            this.btn9_10.Size = new System.Drawing.Size(89, 35);
            this.btn9_10.TabIndex = 30;
            this.btn9_10.Text = "9-10";
            this.btn9_10.UseVisualStyleBackColor = false;
            this.btn9_10.Click += new System.EventHandler(this.btn9_10_Click);
            // 
            // lblinfo
            // 
            this.lblinfo.AutoSize = true;
            this.lblinfo.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.lblinfo.ForeColor = System.Drawing.Color.Maroon;
            this.lblinfo.Location = new System.Drawing.Point(76, 62);
            this.lblinfo.Name = "lblinfo";
            this.lblinfo.Size = new System.Drawing.Size(353, 23);
            this.lblinfo.TabIndex = 38;
            this.lblinfo.Text = "First, Select The Date You Will Change";
            // 
            // frmControlAppointments
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(1059, 636);
            this.Controls.Add(this.lblinfo);
            this.Controls.Add(this.btn14_15);
            this.Controls.Add(this.btn10_11);
            this.Controls.Add(this.btn13_14);
            this.Controls.Add(this.btn16_17);
            this.Controls.Add(this.btn15_16);
            this.Controls.Add(this.btn8_9);
            this.Controls.Add(this.btn11_12);
            this.Controls.Add(this.btn9_10);
            this.Controls.Add(this.dtpSelectWhichday);
            this.Controls.Add(this.txtSeeDate);
            this.Controls.Add(this.txtGetTime);
            this.Controls.Add(this.dgvApproveOrDeny);
            this.Controls.Add(this.btnListAll);
            this.Controls.Add(this.dgvAllList);
            this.Controls.Add(this.btnAppDateAdd);
            this.Controls.Add(this.dtpdeneme);
            this.Controls.Add(this.btnApprove);
            this.Controls.Add(this.btnDeny);
            this.Controls.Add(this.loginAppLogo);
            this.Controls.Add(this.dgvDenyOrApprove);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "frmControlAppointments";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmControlAppointments";
            this.Load += new System.EventHandler(this.frmControlAppointments_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDenyOrApprove)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginAppLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAllList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvApproveOrDeny)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvDenyOrApprove;
        private System.Windows.Forms.PictureBox loginAppLogo;
        private System.Windows.Forms.Button btnDeny;
        private System.Windows.Forms.Button btnApprove;
        private System.Windows.Forms.DateTimePicker dtpdeneme;
        private System.Windows.Forms.Button btnAppDateAdd;
        private System.Windows.Forms.DataGridView dgvAllList;
        private System.Windows.Forms.Button btnListAll;
        private System.Windows.Forms.DataGridView dgvApproveOrDeny;
        private System.Windows.Forms.TextBox txtGetTime;
        private System.Windows.Forms.TextBox txtSeeDate;
        private System.Windows.Forms.DateTimePicker dtpSelectWhichday;
        private System.Windows.Forms.Button btn14_15;
        private System.Windows.Forms.Button btn10_11;
        private System.Windows.Forms.Button btn13_14;
        private System.Windows.Forms.Button btn16_17;
        private System.Windows.Forms.Button btn15_16;
        private System.Windows.Forms.Button btn8_9;
        private System.Windows.Forms.Button btn11_12;
        private System.Windows.Forms.Button btn9_10;
        private System.Windows.Forms.Label lblinfo;
    }
}