﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace onlineAppointmentSystem
{
    public partial class frmAdmin : Form
    {
        public frmAdmin()
        {
            InitializeComponent();
        }

        private void addRemoveDeleteUpdateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.MdiChildren.Count()==0)
            {
                frmWorkplaceAddRemoveDeleteUpdate frmWorkplaceAddRemoveDeleteUpdate = new frmWorkplaceAddRemoveDeleteUpdate();
                frmWorkplaceAddRemoveDeleteUpdate.MdiParent = this;
                frmWorkplaceAddRemoveDeleteUpdate.Show();
            }
            else
            {
                MessageBox.Show("YOU CAN ONLY OPEN 1 PAGE AT THE SAME TIME");
            }
            
        }

        private void identifyingAWorkplaceAuthorityToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.MdiChildren.Count() == 0)
            {
                frmIdentifyingWorkplaceAuthority frmIdentifyingWorkplaceAuthority = new frmIdentifyingWorkplaceAuthority();
                frmIdentifyingWorkplaceAuthority.MdiParent = this;
                frmIdentifyingWorkplaceAuthority.Show();
            }
            else
            {
                MessageBox.Show("YOU CAN ONLY OPEN 1 PAGE AT THE SAME TIME");
            }
            
        }
        private void WorkplaceAuthorsMenu_Click(object sender, EventArgs e)
        {
            if (this.MdiChildren.Count() == 0)
            {
                frmAdminRaporlar frmAdminRaporlar = new frmAdminRaporlar();
                frmAdminRaporlar.MdiParent = this;
                frmAdminRaporlar.Show();
            }
            else
            {
                MessageBox.Show("YOU CAN ONLY OPEN 1 PAGE AT THE SAME TIME");
            }
           
        }

        private void normalUsersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.MdiChildren.Count() == 0)
            {
                frmNormalUsersReports frmNormalUsersList = new frmNormalUsersReports();
                frmNormalUsersList.MdiParent = this;
                frmNormalUsersList.Show();
            }
            else
            {
                MessageBox.Show("YOU CAN ONLY OPEN 1 PAGE AT THE SAME TIME");
            }
            
        }

        private void qUESTIONLISTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.MdiChildren.Count() == 0)
            {
                frmQuestionReports frmQuestionListForAdmin = new frmQuestionReports();
                frmQuestionListForAdmin.MdiParent = this;
                frmQuestionListForAdmin.Show();
            }
            else
            {
                MessageBox.Show("YOU CAN ONLY OPEN 1 PAGE AT THE SAME TIME");
            }
            
        }
    }
}
