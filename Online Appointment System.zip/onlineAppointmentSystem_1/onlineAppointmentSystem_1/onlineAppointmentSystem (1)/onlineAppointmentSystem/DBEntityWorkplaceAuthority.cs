﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace onlineAppointmentSystem
{
    class DBEntityWorkplaceAuthority : DBEntity
    {
        public void AuthorAdd(WorkplaceAuthority author)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Insert Into tblAuthorize (AuthorizedName,AuthorizedSurname,AuthorizedUsername,AuthorizedPhoneNumber,AuthorizedPassword,AuthorizedWhereToWork,AuthorizedEmail,AuthorizedDate,AuthorizedAdress,Authorizedidentity) " +
                    "values (@AuthorizedName,@AuthorizedSurname,@AuthorizedUsername,@AuthorizedPhoneNumber,@AuthorizedPassword,@AuthorizedWhereToWork,@AuthorizedEmail,@AuthorizedDate,@AuthorizedAdress,@Authorizedidentity)", con);
                command.Parameters.AddWithValue("AuthorizedName",author.AuthorizedName);
                command.Parameters.AddWithValue("AuthorizedSurname", author.AuthorizedSurname);
                command.Parameters.AddWithValue("AuthorizedPhoneNumber", author.AuthorizedPhoneNumber);
                command.Parameters.AddWithValue("AuthorizedPassword", author.AuthorizedPassword);
                command.Parameters.AddWithValue("AuthorizedWhereToWork",author.AuthorizedWhereToWork);
                command.Parameters.AddWithValue("AuthorizedEmail", author.AuthorizedEmail);
                command.Parameters.AddWithValue("AuthorizedUsername", author.AuthorizedUsername);
                command.Parameters.AddWithValue("AuthorizedDate",author.AuthorizedDate);
                command.Parameters.AddWithValue("AuthorizedAdress",author.AuthorizedAdress);
                command.Parameters.AddWithValue("Authorizedidentity",author.Authorizedidentity);
                con.Open();
                command.ExecuteNonQuery();

            }
            catch (Exception ex )
            {

                throw ex;
            }
        }
        public DataTable AuthorNonVerify(string AuthorNoVerfy)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand command = new SqlCommand("Select * from TblAuthorize where AuthorizedVerify LIKE '%'+@SearchKey+'%' ", con);
                command.Parameters.AddWithValue("@SearchKey", AuthorNoVerfy);
                SqlDataAdapter adp = new SqlDataAdapter(command);
                DataTable srcTable = new DataTable();
                adp.Fill(srcTable);
                return srcTable;
            }
            catch { return null; }
        }
        public void AuthorStatusUpdate(WorkplaceAuthority statusUpdate)
        {
            SqlConnection con = new SqlConnection(ConnStr);
            SqlCommand command = new SqlCommand("Update TblAuthorize SET AuthorizedVerify = @upStatus where Authorizedid=@wpidup", con);
            command.Parameters.AddWithValue("@upStatus",statusUpdate.AuthorizedVerify);
            command.Parameters.AddWithValue("@wpidup", statusUpdate.Authorizedid);
            con.Open();
            command.ExecuteNonQuery();
        }
        public bool LoginCheck(WorkplaceAuthority workplaceAuthority)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConnStr);
                SqlCommand cmd = new SqlCommand("SELECT AuthorizedUsername, AuthorizedPassword FROM TblAuthorize WHERE AuthorizedUsername = '" + workplaceAuthority.AuthorizedUsername +
                    "' AND AuthorizedPassword = '" + workplaceAuthority.AuthorizedUsername + "'", con);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public void ListWorkplaces(WorkplaceAuthority ApSystem)
        {
            SqlConnection con = new SqlConnection(ConnStr);
            SqlCommand command = new SqlCommand("Select WorkplaceName From tblWorkPlace", con);
            con.Open();
            SqlDataReader dr = command.ExecuteReader();
            while (dr.Read())
            {
                ApSystem.ComboBoxForRegisterWorkplace.Items.Add(dr[0]);
            }
            con.Close();
        }
        public void ListDatesForReports(DataGridView dgvCurrentDateslist)
        {
            SqlConnection con = new SqlConnection(ConnStr);
            SqlDataAdapter da = new SqlDataAdapter("Select AppointmentDate,AppointmentWorkplaceName from tblAppointment", con);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dgvCurrentDateslist.DataSource = ds.Tables[0];
        }
    }
}
